<?php
/* Options for ThemeStek Blogbox */
$serviceCatList = array();
if( taxonomy_exists('themestek-service-category') ){
	$serviceCatList_data = get_terms( 'themestek-service-category', array( 'hide_empty' => false ) );
	$serviceCatList      = array();
	foreach($serviceCatList_data as $cat){
		$serviceCatList[ esc_html($cat->name) . ' (' . esc_html($cat->count) . ')' ] = esc_html($cat->slug);
	}
}
// Getting Options
$moversco_theme_options   = get_option('moversco_theme_options');
$service_type_title          = ( !empty($moversco_theme_options['service_type_title']) ) ? $moversco_theme_options['service_type_title'] : 'Service' ;
$service_type_title_singular = ( !empty($moversco_theme_options['service_type_title_singular']) ) ? $moversco_theme_options['service_type_title_singular'] : 'Service' ;
$service_cat_title           = ( !empty($moversco_theme_options['service_cat_title']) ) ? $moversco_theme_options['service_cat_title'] : 'Service Categories' ;
$service_cat_title_singular  = ( !empty($moversco_theme_options['service_cat_title_singular']) ) ? $moversco_theme_options['service_cat_title_singular'] : 'Service Category' ;
/**
 * Heading Element
 */
$heading_element = vc_map_integrate_shortcode( 'themestek-heading', '', esc_html__('Headings','moversco'),
	array(
		'exclude' => array(
			'el_class',
			'css',
			'css_animation'
		),
	)
);
/**
 * Boxes Appearance options
 */
$boxParams = themestek_box_params();
$allParams = array_merge(
		$heading_element,
		array(
			array(
				'type'			=> 'themestek_imgselector',
				'heading'		=> esc_html__( 'Box View Style', 'moversco' ),
				'description'	=> esc_html__( 'Select box view style.', 'moversco' ),
				'param_name'	=> 'boxstyle',
				'std'			=> 'style-3',
				'value'			=> themestek_global_template_list('service', false),
				'group'		  => esc_html__( 'Box Style', 'moversco' ),
			),
			array(
				"type"        => "dropdown",
				"heading"     => esc_html__("Box Spacing", "moversco"),
				"param_name"  => "box_spacing",
				"description" => esc_html__("Spacing between each box.", "moversco"),
				"value"       => array(
					esc_html__("Default", "moversco")                        => "",
					esc_html__("0 pixel spacing (joint boxes)", "moversco")  => "0px",
					esc_html__("5 pixel spacing", "moversco")                => "5px",
					esc_html__("10 pixel spacing", "moversco")               => "10px",
				),
				"std"  => "",
				'group'		  => esc_html__( 'Box Style', 'moversco' ),
			)
		),
		array( 
			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_html__("Show Sortable Category Links",'moversco'),
				"description" => sprintf( esc_html__("Show sortable category links above %s items so user can sort by just single click.",'moversco'), $service_type_title_singular ),
				"param_name"  => "sortable",
				"value"       => array(
					esc_html__('No','moversco')  => 'no',
					esc_html__('Yes','moversco') => 'yes',
				),
				"std"         => "no",
				'dependency'  => array(
					'element'            => 'boxview',
					'value_not_equal_to' => array( 'carousel' ),
				),
				'group'		  => esc_html__( 'Box Options', 'moversco' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Replace ALL word', 'moversco' ),
				'param_name'  => 'allword',
				'description' => esc_html__( 'Replace ALL word in sortable category links. Default is ALL word.', 'moversco' ),
				"std"         => "All",
				'dependency'  => array(
					'element'   => 'sortable',
					'value'     => array( 'yes' ),
				),
				'group'		  => esc_html__( 'Box Options', 'moversco' ),
			),
			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_html__("Show Pagination",'moversco'),
				"description" => sprintf( esc_html__("Show pagination links below %s boxes.",'moversco'), $service_type_title ),
				"param_name"  => "pagination",
				"value"       => array(
					esc_html__('No','moversco')  => 'no',
					esc_html__('Yes','moversco') => 'yes',
				),
				"std"         => "no",
				'dependency'  => array(
					'element'    => 'sortable',
					'value_not_equal_to' => array( 'yes' ),
				),
				'group'		  => esc_html__( 'Box Options', 'moversco' ),
			),
			array(
				"type"        => "checkbox",
				"heading"     => sprintf( esc_html__("From %s", "moversco"), $service_cat_title_singular ),
				"description" => sprintf( esc_html__('If you like to show %1$s from selected %2$s than select the category here.', 'moversco'), $service_type_title, $service_cat_title ),
				"param_name"  => "category",
				"value"       => $serviceCatList,
				'group'		  => esc_html__( 'Box Options', 'moversco' ),
			),
			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_html__("Order by",'moversco'),
				"description" => esc_html__("Sort retrieved service by parameter.",'moversco'),
				"param_name"  => "orderby",
				"value"       => array(
					esc_html__('No order (none)','moversco')           => 'none',
					esc_html__('Order by post id (ID)','moversco')     => 'ID',
					esc_html__('Order by author (author)','moversco')  => 'author',
					esc_html__('Order by title (title)','moversco')    => 'title',
					esc_html__('Order by slug (name)','moversco')      => 'name',
					esc_html__('Order by date (date)','moversco')      => 'date',
					esc_html__('Order by last modified date (modified)','moversco') => 'modified',
					esc_html__('Random order (rand)','moversco')       => 'rand',
					esc_html__('Order by number of comments (comment_count)','moversco') => 'comment_count',
				),
				'edit_field_class' => 'vc_col-sm-6 vc_column',
				"std"              => "date",
				'group'		  => esc_html__( 'Box Options', 'moversco' ),
			),
			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_html__("Order",'moversco'),
				"description" => esc_html__("Designates the ascending or descending order of the 'orderby' parameter.",'moversco'),
				"param_name"  => "order",
				"value"       => array(
					esc_html__('Ascending (1, 2, 3; a, b, c)','moversco')  => 'ASC',
					esc_html__('Descending (3, 2, 1; c, b, a)','moversco') => 'DESC',
				),
				'edit_field_class' => 'vc_col-sm-6 vc_column',
				"std"              => "DESC",
				'group'		  => esc_html__( 'Box Options', 'moversco' ),
			),
			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_html__("Show",'moversco'),
				"description" => sprintf( esc_html__("How many %s item you want to show.", "moversco"), $service_type_title ),
				"param_name"  => "show",
				"value"       => array(
					esc_html__("All", "moversco") => "-1",
					esc_html__('1', "moversco")   => "1",
					esc_html__('2', "moversco")   => "2",
					esc_html__('3','moversco')    =>'3',
					esc_html__('4','moversco')    =>'4',
					esc_html__('5','moversco')    =>'5',
					esc_html__('6','moversco')    =>'6',
					esc_html__('7','moversco')    =>'7',
					esc_html__('8','moversco')    =>'8',
					esc_html__('9','moversco')    =>'9',
					esc_html__('10','moversco')   =>'10',
					esc_html__('11','moversco')   =>'11',
					esc_html__('12','moversco')   =>'12',
					esc_html__('13','moversco')   =>'13',
					esc_html__('14','moversco')   =>'14',
					esc_html__('15','moversco')   =>'15',
					esc_html__('16','moversco')   =>'16',
					esc_html__('17','moversco')   =>'17',
					esc_html__('18','moversco')   =>'18',
					esc_html__('19','moversco')   =>'19',
					esc_html__('20','moversco')   =>'20',
					esc_html__('21','moversco')   =>'21',
					esc_html__('22','moversco')   =>'22',
					esc_html__('23','moversco')   =>'23',
					esc_html__('24','moversco')   =>'24',
				),
				"std"  => "3",
				'group'		  => esc_html__( 'Box Options', 'moversco' ),
			),
		),
		$boxParams,
		array(
			themestek_vc_ele_css_editor_option(),
		)
	);
$params = $allParams;
// Changing default values
$i = 0;
foreach( $params as $param ){
	$param_name = (isset($param['param_name'])) ? $param['param_name'] : '' ;
	if( $param_name == 'h2' ){
		$params[$i]['std'] = 'Our Work';
	} else if( $param_name == 'h2_use_theme_fonts' ){
		$params[$i]['std'] = 'yes';
	} else if( $param_name == 'h4_use_theme_fonts' ){
		$params[$i]['std'] = 'yes';
	} else if( $param_name == 'txt_align' ){
		$params[$i]['std'] = 'center';
	}
	$i++;
}
global $themestek_sc_params_servicebox;
$themestek_sc_params_servicebox = $params;
vc_map( array(
	"name"     => sprintf( esc_html__("ThemeStek %s Box",'moversco'), $service_type_title_singular ),
	"base"     => "themestek-servicebox",
	"class"    => "",
	'category' => esc_html__( 'THEMESTEK', 'moversco' ),
	"icon"     => "icon-themestek-vc",
	"params"   => $params,
) );
