<?php
/* Options for ThemeStek Button */
global $themestek_pixel_icons;
$icons_params = vc_map_integrate_shortcode( 'themestek-icon', 'i_', '',
	array(
		'include_only_regex' => '/^(type|icon_\w*)/',
		// we need only type, icon_fontawesome, icon_blabla..., NOT color and etc
	), array(
		'element' => 'add_icon',
		'value' => 'true',
	)
);
// populate integrated themestek-icons params.
if ( is_array( $icons_params ) && ! empty( $icons_params ) ) {
	foreach ( $icons_params as $key => $param ) {
		if ( is_array( $param ) && ! empty( $param ) ) {
			if ( 'i_type' === $param['param_name'] ) {
				// Do nothing
			}
			if ( isset( $param['admin_label'] ) ) {
				// remove admin label
				unset( $icons_params[ $key ]['admin_label'] );
			}
		}
	}
}
$params = array_merge(
	array(
		array(
			'type'       => 'textfield',
			'heading'    => esc_html__( 'Text', 'moversco' ),
			'param_name' => 'title',
			'value'      => esc_html__( 'Text on the button', 'moversco' ),
		),
		array(
			'type' => 'vc_link',
			'heading' => esc_html__( 'URL (Link)', 'moversco' ),
			'param_name' => 'link',
			'description' => esc_html__( 'Add link to button.', 'moversco' ),
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Style', 'moversco' ),
			'description' => esc_html__( 'Select button display style.', 'moversco' ),
			'param_name' => 'style',
			'std'		 => 'flat',
			'value' => array(
				esc_html__( 'Flat', 'moversco' ) => 'flat',
				esc_html__( 'Modern', 'moversco' ) => 'modern',
				esc_html__( 'Classic', 'moversco' ) => 'classic',
				esc_html__( 'Outline', 'moversco' ) => 'outline',
				esc_html__( '3d', 'moversco' ) => '3d',
				esc_html__( 'Simple Text', 'moversco' ) => 'text',
				esc_html__( 'Custom', 'moversco' ) => 'custom',
				esc_html__( 'Outline custom', 'moversco' ) => 'outline-custom',
				esc_html__( 'Gradient', 'moversco' ) => 'gradient',
				esc_html__( 'Gradient Custom', 'moversco' ) => 'gradient-custom',
			),
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Gradient Color 1', 'moversco' ),
			'param_name' => 'gradient_color_1',
			'description' => esc_html__( 'Select first color for gradient.', 'moversco' ),
			'param_holder_class' => 'themestek_vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => getVcShared( 'colors-dashed' ),
			'std' => 'turquoise',
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'gradient' ),
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column',
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Gradient Color 2', 'moversco' ),
			'param_name' => 'gradient_color_2',
			'description' => esc_html__( 'Select second color for gradient.', 'moversco' ),
			'param_holder_class' => 'themestek_vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => getVcShared( 'colors-dashed' ),
			'std' => 'blue',
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'gradient' ),
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Gradient Color 1', 'moversco' ),
			'param_name' => 'gradient_custom_color_1',
			'description' => esc_html__( 'Select first color for gradient.', 'moversco' ),
			'param_holder_class' => 'themestek_vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => '#dd3333',
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'gradient-custom' ),
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Gradient Color 2', 'moversco' ),
			'param_name' => 'gradient_custom_color_2',
			'description' => esc_html__( 'Select second color for gradient.', 'moversco' ),
			'param_holder_class' => 'themestek_vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => '#eeee22',
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'gradient-custom' ),
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Button Text Color', 'moversco' ),
			'param_name' => 'gradient_text_color',
			'description' => esc_html__( 'Select button text color.', 'moversco' ),
			'param_holder_class' => 'themestek_vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => '#ffffff',
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'gradient-custom' ),
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Background', 'moversco' ),
			'param_name' => 'custom_background',
			'description' => esc_html__( 'Select custom background color for your element.', 'moversco' ),
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'custom' )
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column',
			'std' => '#ededed',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Text', 'moversco' ),
			'param_name' => 'custom_text',
			'description' => esc_html__( 'Select custom text color for your element.', 'moversco' ),
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'custom' )
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column',
			'std' => '#666',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Outline and Text', 'moversco' ),
			'param_name' => 'outline_custom_color',
			'description' => esc_html__( 'Select outline and text color for your element.', 'moversco' ),
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'outline-custom' )
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
			'std' => '#666',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Hover background', 'moversco' ),
			'param_name' => 'outline_custom_hover_background',
			'description' => esc_html__( 'Select hover background color for your element.', 'moversco' ),
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'outline-custom' )
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
			'std' => '#666',
		),
		array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Hover text', 'moversco' ),
			'param_name' => 'outline_custom_hover_text',
			'description' => esc_html__( 'Select hover text color for your element.', 'moversco' ),
			'dependency' => array(
				'element' => 'style',
				'value' => array( 'outline-custom' )
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
			'std' => '#fff',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Shape', 'moversco' ),
			'description' => esc_html__( 'Select button shape.', 'moversco' ),
			'param_name'  => 'shape',
			'std'		  => 'rounded',
			'value'       => array(
				esc_html__( 'Square', 'moversco' ) => 'square',
				esc_html__( 'Rounded', 'moversco' ) => 'rounded',
				esc_html__( 'Round', 'moversco' ) => 'round',
			),
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Color', 'moversco' ),
			'param_name' => 'color',
			'description' => esc_html__( 'Select button color.', 'moversco' ),
			'param_holder_class' => 'themestek_vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => array(
							esc_html__( '[Skin Color]', 'moversco' ) => 'skincolor',
							esc_html__( 'Classic Grey', 'moversco' ) => 'default',
							esc_html__( 'Classic Blue', 'moversco' ) => 'primary',
							esc_html__( 'Classic Turquoise', 'moversco' ) => 'info',
							esc_html__( 'Classic Green', 'moversco' ) => 'success',
							esc_html__( 'Classic Orange', 'moversco' ) => 'warning',
							esc_html__( 'Classic Red', 'moversco' ) => 'danger',
							esc_html__( 'Classic Black', 'moversco' ) => 'inverse'
					   ) + themestek_getVcShared( 'colors-dashed' ),
			'std' => 'skincolor',
			'dependency' => array(
				'element' => 'style',
				'value_not_equal_to' => array( 'custom', 'outline-custom' )
			),
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Button Size', 'moversco' ),
			'param_name' => 'size',
			'description' => esc_html__( 'Select button display size.', 'moversco' ),
			'std' => 'md',
			'value' => themestek_getVcShared( 'sizes' ),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Button Text Bold?', 'moversco' ),
			'param_name'  => 'font_weight',
			'description' => esc_html__( 'Select YES if you like to bold the font text.', 'moversco' ),
			'std'         => 'yes',
			'value'       => array(
				esc_html__( 'Yes', 'moversco' ) => 'yes',
				esc_html__( 'No', 'moversco' )  => 'no',
			),
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Alignment', 'moversco' ),
			'param_name' => 'align',
			'description' => esc_html__( 'Select button alignment.', 'moversco' ),
			'value' => array(
				esc_html__( 'Inline', 'moversco' ) => 'inline',
				esc_html__( 'Left', 'moversco' ) => 'left',
				esc_html__( 'Right', 'moversco' ) => 'right',
				esc_html__( 'Center', 'moversco' ) => 'center'
			),
		),
		array(
			'type'       => 'dropdown',
			'heading'    => esc_html__( 'Set full width button?', 'moversco' ),
			'param_name' => 'button_block',
			'dependency' => array(
				'element'            => 'align',
				'value_not_equal_to' => 'inline',
			),
			'value'      => array(
				esc_html__( 'No', 'moversco' )  => 'false',
				esc_html__( 'Yes', 'moversco' ) => 'true',
			),
		),
		array(
			'type'       => 'dropdown',
			'heading'    => esc_html__( 'Add icon?', 'moversco' ),
			'param_name' => 'add_icon',
			'value'      => array(
				esc_html__( 'No',  'moversco' ) => '',
				esc_html__( 'Yes', 'moversco' ) => 'true',
			),
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Icon Alignment', 'moversco' ),
			'description' => esc_html__( 'Select icon alignment.', 'moversco' ),
			'param_name' => 'i_align',
			'value' => array(
				esc_html__( 'Left', 'moversco' ) => 'left',
				// default as well
				esc_html__( 'Right', 'moversco' ) => 'right',
			),
			'dependency' => array(
				'element' => 'add_icon',
				'value' => 'true',
			),
		),
	),
	$icons_params,
	array(
		vc_map_add_css_animation(),
		themestek_vc_ele_extra_class_option(),
		themestek_vc_ele_css_editor_option(),
	)
);
// Changing modifying, adding extra options
$i = 0;
foreach( $params as $param ){
	$param_name = (isset($param['param_name'])) ? $param['param_name'] : '' ;
	// Button Icon
	if( $param_name == 'i_align' ){
		$params[$i]['std'] = 'right';
	} else if( $param_name == 'i_type' ){
		$params[$i]['std'] = 'themify';
	} else if( $param_name == 'i_icon_themify' ){
		$params[$i]['std']   = 'themifyicon ti-arrow-right';
		$params[$i]['value'] = 'themifyicon ti-arrow-right';
	}
	$i++;
} // Foreach
global $themestek_sc_params_btn;
$themestek_sc_params_btn = $params;
vc_map( array(
	'name'     => esc_html__( 'ThemeStek Button', 'moversco' ),
	'base'     => 'themestek-btn',
	'icon'     => 'icon-themestek-vc',
	'category' => array( esc_html__( 'THEMESTEK', 'moversco' ) ),
	'params'   => $params,
	'js_view'  => 'VcButton3View',
	'custom_markup' => '{{title}}<div class="vc_btn3-container"><button class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-{{ params.shape }} vc_btn3-style-{{ params.style }} vc_btn3-color-{{ params.color }}">{{{ params.title }}}</button></div>',
) );
