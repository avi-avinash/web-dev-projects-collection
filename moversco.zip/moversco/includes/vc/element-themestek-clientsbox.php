<?php
/* Options */
$clientsGroupList = array();
if( taxonomy_exists('themestek-client-group') ){
	$clientsGroupList_data = get_terms( 'themestek-client-group', array( 'hide_empty' => false ) );
	$clientsGroupList      = array();
	foreach($clientsGroupList_data as $cat){
		$clientsGroupList[ esc_html($cat->name) . ' (' . esc_html($cat->count) . ')' ] = esc_html($cat->slug);
	}
}
/**
 * Heading Element
 */
$heading_element = vc_map_integrate_shortcode( 'themestek-heading', '', esc_html__('Main Heading','moversco'),
	array(
		'exclude' => array(
			'el_class',
			'css',
			'css_animation'
		),
	)
);
/**
 * Boxes Appearance options
 */
$boxParams = themestek_box_params();
$allParams = array_merge(
	$heading_element,
	array(
		array(
			'type'			=> 'themestek_imgselector',
			'heading'		=> esc_html__( 'Box View Style', 'moversco' ),
			'description'	=> esc_html__( 'Select box view style.', 'moversco' ),
			'param_name'	=> 'boxstyle',
			'std'			=> 'style-1',
			'value'			=> themestek_global_template_list('clients', false),
			'group'		  => esc_html__( 'Box Style', 'moversco' ),
		),
		array(
			"type"        => "dropdown",
			"heading"     => esc_html__("Show HOVER image?",'moversco'),
			"description" => esc_html__("Show HOVER image too. This will work only if you set hover image for each client logo.",'moversco'),
			"param_name"  => "show_hover",
			"value"       => array(
				esc_html__('Yes','moversco') => 'yes',
				esc_html__('No','moversco')  => 'no',
			),
			"std"         => "yes",
			'dependency'  => array(
				'element'		=> 'boxstyle',
				'value'			=> array( 'style1' ),
			),
			'group'		  => esc_html__( 'Box Style', 'moversco' ),
			'edit_field_class' => 'vc_col-sm-8 vc_column',
		),
	),
	array(
		array(
			"type"        => "dropdown",
			"holder"      => "div",
			"class"       => "",
			"heading"     => esc_html__("Show Sortable GROUP Links",'moversco'),
			"description" => esc_html__("Show sortable GROUP links above logos so user can sort by just single click.",'moversco'),
			"param_name"  => "sortable",
			"value"       => array(
				esc_html__('No','moversco')  => 'no',
				esc_html__('Yes','moversco') => 'yes',
			),
			"std"         => "no",
			'dependency'  => array(
				'element'            => 'boxview',
				'value_not_equal_to' => array( 'carousel' ),
			),
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Replace ALL word', 'moversco' ),
			'param_name'  => 'allword',
			'description' => esc_html__( 'Replace ALL word in sortable category links. Default is ALL word.', 'moversco' ),
			"std"         => "All",
			'dependency'  => array(
				'element'   => 'sortable',
				'value'     => array( 'yes' ),
			),
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			"type"        => "dropdown",
			"holder"      => "div",
			"class"       => "",
			"heading"     => esc_html__("Show Pagination",'moversco'),
			"description" => esc_html__("Show pagination links below each logo boxes.",'moversco'),
			"param_name"  => "pagination",
			"value"       => array(
				esc_html__('No','moversco')  => 'no',
				esc_html__('Yes','moversco') => 'yes',
			),
			"std"         => "no",
			'dependency'  => array(
				'element'    => 'sortable',
				'value_not_equal_to' => array( 'yes' ),
			),
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			"type"        => "checkbox",
			"heading"     => esc_html__("From Group", "moversco"),
			"param_name"  => "category",
			"description" => esc_html__("Select group so it will show client logo from selected group only.", "moversco"),
			"value"       => $clientsGroupList,
			"std"         => "",
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			"type"        => "dropdown",
			"holder"      => "div",
			"class"       => "",
			"heading"     => esc_html__("Order by",'moversco'),
			"description" => esc_html__("Sort retrieved portfolio by parameter.",'moversco'),
			"param_name"  => "orderby",
			"value"       => array(
				esc_html__('No order (none)','moversco')           => 'none',
				esc_html__('Order by post id (ID)','moversco')     => 'ID',
				esc_html__('Order by author (author)','moversco')  => 'author',
				esc_html__('Order by title (title)','moversco')    => 'title',
				esc_html__('Order by slug (name)','moversco')      => 'name',
				esc_html__('Order by date (date)','moversco')      => 'date',
				esc_html__('Order by last modified date (modified)','moversco') => 'modified',
				esc_html__('Random order (rand)','moversco')       => 'rand',
				esc_html__('Order by number of comments (comment_count)','moversco') => 'comment_count',
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column',
			"std"              => "date",
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			"type"        => "dropdown",
			"holder"      => "div",
			"class"       => "",
			"heading"     => esc_html__("Order",'moversco'),
			"description" => esc_html__("Designates the ascending or descending order of the 'orderby' parameter.",'moversco'),
			"param_name"  => "order",
			"value"       => array(
				esc_html__('Ascending (1, 2, 3; a, b, c)','moversco')  => 'ASC',
				esc_html__('Descending (3, 2, 1; c, b, a)','moversco') => 'DESC',
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column',
			"std"              => "DESC",
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			"type"        => "dropdown",
			"heading"     => esc_html__("Show", "moversco"),
			"param_name"  => "show",
			"description" => esc_html__("Total Clients Logos you want to show.", "moversco"),
			"value"       => array(
				esc_html__("All", "moversco") => "-1",
				esc_html__("1", "moversco")  => "1",
				esc_html__("2", "moversco") => "2",
				esc_html__("3", "moversco") => "3",
				esc_html__("4", "moversco") => "4",
				esc_html__("5", "moversco") => "5",
				esc_html__("6", "moversco") => "6",
				esc_html__("7", "moversco") => "7",
				esc_html__("8", "moversco") => "8",
				esc_html__("9", "moversco") => "9",
				esc_html__("10", "moversco") => "10",
				esc_html__("11", "moversco") => "11",
				esc_html__("12", "moversco") => "12",
				esc_html__("13", "moversco") => "13",
				esc_html__("14", "moversco") => "14",
				esc_html__("15", "moversco") => "15",
				esc_html__("16", "moversco") => "16",
				esc_html__("17", "moversco") => "17",
				esc_html__("18", "moversco") => "18",
				esc_html__("19", "moversco") => "19",
				esc_html__("20", "moversco") => "20",
			),
			"std"  => "10",
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			"type"        => "dropdown",
			"holder"      => "div",
			"class"       => "",
			"heading"     => esc_html__("Show Tooltip on Logo?",'moversco'),
			"description" => esc_html__("Select YES to show Tooltip on the logo.",'moversco'),
			"param_name"  => "show_tooltip",
			"value"       => array(
				esc_html__("Yes", "moversco") => "yes",
				esc_html__("No", "moversco")  => "no",
			),
			"std"         => "yes",
			'edit_field_class' => 'vc_col-sm-6 vc_column',
			'group'		  => esc_html__('Box Options','moversco'),
		),
		array(
			"type"        => "dropdown",
			"holder"      => "div",
			"class"       => "",
			"heading"     => esc_html__("Add link to all logos?",'moversco'),
			"description" => esc_html__("Select YES to add link to all logos. Please note that link should be added to each client logo. If no link found than the logo will appear without link.",'moversco'),
			"param_name"  => "add_link",
			"value"       => array(
				esc_html__("Yes", "moversco") => "yes",
				esc_html__("No", "moversco")  => "no",
			),
			"std"         => "yes",
			'edit_field_class' => 'vc_col-sm-6 vc_column',
			'group'		  => esc_html__('Box Options','moversco'),
		),
	),
	$boxParams,
	array(
		themestek_vc_ele_css_editor_option(),
	)
);
$params = $allParams;
// Changing default values
$i = 0;
foreach( $params as $param ){
	$param_name = (isset($param['param_name'])) ? $param['param_name'] : '' ;
	if( $param_name == 'h2' ){
		$params[$i]['std'] = 'Our Clients';
	} else if( $param_name == 'column' ){
		$params[$i]['std'] = 'five';
	} else if( $param_name == 'boxview' ){
		$params[$i]['std'] = 'carousel';
	} else if( $param_name == 'content' ){
		$params[$i]['std'] = '';
	} else if( $param_name == 'carousel_loop' ){
		$params[$i]['std'] = '1';
	} else if( $param_name == 'carousel_dots' ){
		$params[$i]['std'] = 'true';
	} else if( $param_name == 'carousel_nav' ){
		$params[$i]['std'] = '0';
	} else if( $param_name == 'h2_use_theme_fonts' ){
		$params[$i]['std'] = 'yes';
	} else if( $param_name == 'h4_use_theme_fonts' ){
		$params[$i]['std'] = 'yes';
	} else if( $param_name == 'txt_align' ){
		$params[$i]['std'] = 'center';
	}
	$i++;
}
global $themestek_sc_params_clients;
$themestek_sc_params_clients = $params;
vc_map( array(
	"name"     => esc_html__("ThemeStek Client Logo Box", "moversco"),
	"base"     => "themestek-clientsbox",
	"icon"     => "icon-themestek-vc",
	'category' => esc_html__( 'THEMESTEK', 'moversco' ),
	"params"   => $params,
) );
