<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
$params = array(
	array(
		'type'			=> 'textfield',
		'heading'		=> esc_html__( 'Widget title', 'moversco' ),
		'param_name'	=> 'title',
		'description'	=> esc_html__( 'Enter text used as widget title (Note: located above content element).', 'moversco' ),
	),
	array(
		'type'			=> 'themestek_attach_image',
		'heading'		=> esc_html__( 'Image', 'moversco' ),
		'param_name'	=> 'image',
		'value'			=> '',
		'description'	=> esc_html__( 'Select image from media library.', 'moversco' ),
		'admin_label'	=> true,
	),
	array(
		'type' => 'dropdown',
		'heading' => esc_html__( 'Image alignment', 'moversco' ),
		'param_name' => 'alignment',
		'value' => array(
			esc_html__( 'Left', 'moversco' ) => 'left',
			esc_html__( 'Right', 'moversco' ) => 'right',
			esc_html__( 'Center', 'moversco' ) => 'center',
		),
		'description' => esc_html__( 'Select image alignment.', 'moversco' ),
	),
	array(
		'type' => 'textfield',
		'heading' => esc_html__( 'Extra class name', 'moversco' ),
		'param_name' => 'el_class',
		'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'moversco' ),
	),
	array(
		'type' => 'css_editor',
		'heading' => esc_html__( 'CSS box', 'moversco' ),
		'param_name' => 'css',
		'group' => esc_html__( 'Design Options', 'moversco' ),
	),
);
global $themestek_sc_params_single_image;
$themestek_sc_params_single_image = $params;
vc_map( array(
	'name'		=> esc_html__( 'ThemeStek Single Image', 'moversco' ),
	'base'		=> 'themestek-single-image',
	'icon'		=> 'icon-themestek-vc',
	'category'	=> array( esc_html__( 'THEMESTEK', 'moversco' ) ),
	'params'	=> $params,
) );
