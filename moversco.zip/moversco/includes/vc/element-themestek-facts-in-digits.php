<?php
/* Options */
$icons_params = vc_map_integrate_shortcode( 'themestek-icon', 'i_', esc_html__('Icon','moversco'), array(
	'include_only_regex' => '/^(type|icon_\w*)/',
	// we need only type, icon_fontawesome, icon_blabla..., NOT color and etc
), array(
	'element' => 'boxstyle',
	'value' => array( 'style-3', 'style-4', 'style-5','style-8' ),
) );
$icons_params_new = array();
/* Adding class for two column */
foreach( $icons_params as $param ){
	$icons_params_new[] = $param;
}
$allParams = array(
	array(
		'type'			=> 'themestek_imgselector',
		'heading'		=> esc_html__( 'Fact In Digits box Style', 'moversco' ),
		'description'	=> esc_html__( 'Select box style for Facts in Digits box. This will show rotating number with icon and heading.', 'moversco' ),
		'param_name'	=> 'boxstyle',
		'std'			=> 'style-1',
		'value'			=> themestek_global_template_list('fidbox', false),
		'group'  	    => esc_html__( 'Box Style', 'moversco' ),
	),
	array(
		'type'			=> 'textfield',
		'holder'		=> 'div',
		'class'			=> '',
		'heading'		=> esc_html__('Heading Text', 'moversco'),
		'param_name'	=> 'title',
		'std'			=> esc_html__('Title Text', 'moversco'),
		'description'	=> esc_html__('Enter text for the title. Leave blank if no title is needed.', 'moversco'),
		'group'		    => esc_html__( 'Content', 'moversco' ),
	),
	array(
		'type'			=> 'textfield',
		'holder'		=> 'div',
		'class'			=> '',
		'heading'		=> esc_html__('Small Description Text', 'moversco'),
		'param_name'	=> 'desc',
		'std'			=> esc_html__('Small Description Text', 'moversco'),
		'description'	=> esc_html__('Enter text for small desciption. Leave blank if no desciption is needed.', 'moversco'),
		'group'		    => esc_html__( 'Content', 'moversco' ),
		'dependency'	=> array(
			'element'		=> 'boxstyle',
			'value'			=> array( 'style-1' ),
		),
	),
	array(
		'type'				=> 'textfield',
		'holder'			=> 'div',
		'class'				=> '',
		'heading'			=> esc_html__('Rotating Number', 'moversco'),
		'param_name'		=> 'digit',
		'std'				=> '85',
		'description'		=> esc_html__('Enter rotating number digit here.', 'moversco'),
		'group'		    => esc_html__( 'Content', 'moversco' ),
	),
	array(
		'type'				=> 'textfield',
		'holder'			=> 'div',
		'heading'			=> esc_html__('Text Before Number', 'moversco'),
		'param_name'		=> 'before',
		'description'		=> esc_html__('Enter text which appear just before the rotating numbers.', 'moversco'),
		'edit_field_class'	=> 'vc_col-sm-6 vc_column',
		'group'		    => esc_html__( 'Content', 'moversco' ),
	),
	array(
		"type"			=> "dropdown",
		"holder"		=> "div",
		"heading"		=> esc_html__("Text Style",'moversco'),
		"param_name"	=> "beforetextstyle",
		"description"	=> esc_html__('Select text style for the text.', 'moversco') . '<br>' . esc_html__('Superscript text appears half a character above the normal line, and is rendered in a smaller font.','moversco') . '<br>' . esc_html__('Subscript text appears half a character below the normal line, and is sometimes rendered in a smaller font.','moversco'),
		'value' => array(
			esc_html__( 'Superscript', 'moversco' ) => 'sup',
			esc_html__( 'Subscript', 'moversco' )   => 'sub',
			esc_html__( 'Normal', 'moversco' )      => 'span',
		),
		'std' => 'sup',
		'edit_field_class'	=> 'vc_col-sm-6 vc_column',
		'group'		    => esc_html__( 'Content', 'moversco' ),
	),
	array(
		'type'				=> 'textfield',
		'holder'			=> 'div',
		'class'				=> '',
		'heading'			=> esc_html__('Text After Number', 'moversco'),
		'param_name'		=> 'after',
		'description'		=> esc_html__('Enter text which appear just after the rotating numbers.', 'moversco'),
		'edit_field_class'	=> 'vc_col-sm-6 vc_column',
		'group'		    => esc_html__( 'Content', 'moversco' ),
	),
	array(
		"type"			=> "dropdown",
		"holder"		=> "div",
		"class"			=> "",
		"heading"		=> esc_html__("Text Style",'moversco'),
		"param_name"	=> "aftertextstyle",
		"description"	=> esc_html__('Select text style for the text.', 'moversco') . '<br>' . esc_html__('Superscript text appears half a character above the normal line, and is rendered in a smaller font.','moversco') . '<br>' . esc_html__('Subscript text appears half a character below the normal line, and is sometimes rendered in a smaller font.','moversco'),
		'value' => array(
			esc_html__( 'Superscript', 'moversco' ) => 'sup',
			esc_html__( 'Subscript', 'moversco' )   => 'sub',
			esc_html__( 'Normal', 'moversco' )      => 'span',
		),
		'std' => 'sub',
		'edit_field_class'	=> 'vc_col-sm-6 vc_column',
		'group'		    => esc_html__( 'Content', 'moversco' ),
	),
	array(
		'type'			=> 'textfield',
		'holder'		=> 'div',
		'class'			=> '',
		'heading'		=> esc_html__('Rotating digit Interval', 'moversco'),
		'param_name'	=> 'interval',
		'std'			=> '5',
		'description'	=> esc_html__('Enter rotating interval number here.', 'moversco'),
		'group'		    => esc_html__( 'Content', 'moversco' ),
	)
);
$extra_class = themestek_vc_ele_extra_class_option();
$extra_class['group'] = esc_html__( 'Content', 'moversco' );
$css_animation = vc_map_add_css_animation();
$css_animation['group'] = esc_html__( 'Content', 'moversco' );
// merging all options
$params = array_merge( $allParams, $icons_params_new );
// merging extra options like css animation, css options etc
$params = array_merge(
	$params,
	array( $css_animation ),
	array( $extra_class ),
	array( themestek_vc_ele_css_editor_option() )
);
global $themestek_sc_params_facts_in_digits;
$themestek_sc_params_facts_in_digits = $params;
vc_map( array(
	'name'		=> esc_html__( 'ThemeStek Facts in digits', 'moversco' ),
	'base'		=> 'themestek-facts-in-digits',
	'class'		=> '',
	'icon'		=> 'icon-themestek-vc',
	'category'	=> esc_html__( 'THEMESTEK', 'moversco' ),
	'params'	=> $params
) );
