<?php
/**
 *  ThemeStek: Schedule Box
 */
	$params = array_merge(
		themestek_vc_heading_params(),
		array(
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Extra class name', 'moversco' ),
				'param_name'  => 'el_class',
				'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'moversco' ),
			),
			array(
			'type'			=> 'param_group',
			'heading'		=> esc_html__( 'Timelist', 'moversco' ),
			'param_name'	=> 'pricelist',
			'group'			=> esc_html__( 'Timelist', 'moversco' ),
			'description'	=> esc_html__( 'Set Service price', 'moversco' ),
			'value'			=> urlencode( json_encode( array(
				array(
					'service_name' => esc_html__( 'Monday - Friday', 'moversco' ),
					'price'        => esc_html__('8:00am - 7:00pm', 'moversco' ),
				),
			))),
			'params' => array(
				array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Week Days', 'moversco' ),
						'param_name'  => 'service_name',
						'description' => esc_html__( 'Fill Service information here', 'moversco' ),
						// 'value'       => '',
						'group'       => esc_html__( 'Timelist', 'moversco' ),
						'admin_label' => true,
						'edit_field_class' => 'vc_col-sm-6 vc_column',
				),
				array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Timing', 'moversco' ),
						'param_name'  => 'price',
						// 'value'       => '',
						'description' => esc_html__( 'Fill Price details here eg: $30', 'moversco' ),
						'group'       => esc_html__( 'Timelist', 'moversco' ),
						'admin_label' => true,
						'edit_field_class' => 'vc_col-sm-6 vc_column',
				),
			),
		),
		)
	);
	global $themestek_vc_custom_element_pricelistbox;
	$themestek_vc_custom_element_pricelistbox = $params;
	vc_map( array(
		'name'        => esc_html__( 'ThemeStek Timelist Box', 'moversco' ),
		'base'        => 'themestek-pricelistbox',
		"class"    => "",
		"icon"        => "icon-themestek-vc",
		'category'    => esc_html__( 'THEMESTEK', 'moversco' ),
		'params'      => $params,
	) );
