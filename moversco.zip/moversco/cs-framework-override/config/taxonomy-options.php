<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
$moversco_theme_options		   = get_option('moversco_theme_options');
$pf_cat_title_singular     = ( !empty($moversco_theme_options['pf_cat_title_singular']) ) ? esc_html($moversco_theme_options['pf_cat_title_singular']) : esc_html__('Portfolio Category', 'moversco') ;
$service_cat_title_singular     = ( !empty($moversco_theme_options['service_cat_title_singular']) ) ? esc_html($moversco_theme_options['service_cat_title_singular']) : esc_html__('Service Category', 'moversco') ;
$team_group_title_singular = ( !empty($moversco_theme_options['team_group_title_singular']) ) ? esc_html($moversco_theme_options['team_group_title_singular']) : esc_html__('Team Group', 'moversco') ;
// Taxonomy Options
$themestek_taxonomy_options     = array();
// For Portfolio Category
$themestek_taxonomy_options[]   = array(
	'id'       => 'themestek_taxonomy_options',
	'taxonomy' => 'themestek-portfolio-category', // category, post_tag or your custom taxonomy name
	'fields'   => array(
		array(
			'id'            => 'tax_featured_image',
			'type'          => 'upload',
			'title' => esc_html__('Featured Image URL', 'moversco'),
			'after' => '<p>' . sprintf( esc_html__('Select featured image for this %s. Please upload the image first from media section.', 'moversco'), $pf_cat_title_singular ) . '</p>',
			'settings'      => array(
				'upload_type'  => 'image',
				'button_title' => esc_html__('Upload', 'moversco'),
				'frame_title'  => esc_html__('Select an image', 'moversco'),
				'insert_title' => esc_html__('Use this image', 'moversco'),
			),
		),
		array(
			'id'            => 'tax_titlebar_image',
			'type'          => 'upload',
			'title' => esc_html__('Titlebar Bakground Image URL', 'moversco'),
			'after' => '<p>' . sprintf( esc_html__('Select Titlebar background image for this %s. Please upload the image first from media section.', 'moversco'), $pf_cat_title_singular ) . '</p>',
			'settings'      => array(
				'upload_type'  => 'image',
				'button_title' => esc_html__('Upload', 'moversco'),
				'frame_title'  => esc_html__('Select an image', 'moversco'),
				'insert_title' => esc_html__('Use this image', 'moversco'),
			),
		),
	),
);
// For Service Category
$themestek_taxonomy_options[]   = array(
	'id'       => 'themestek_taxonomy_options',
	'taxonomy' => 'themestek-service-category', // category, post_tag or your custom taxonomy name
	'fields'   => array(
		array(
			'id'            => 'tax_featured_image',
			'type'          => 'upload',
			'title' => esc_html__('Featured Image URL', 'moversco'),
			'after' => '<p>' . sprintf( esc_html__('Select featured image for this %s. Please upload the image first from media section.', 'moversco'), $service_cat_title_singular ) . '</p>',
			'settings'      => array(
				'upload_type'  => 'image',
				'button_title' => esc_html__('Upload', 'moversco'),
				'frame_title'  => esc_html__('Select an image', 'moversco'),
				'insert_title' => esc_html__('Use this image', 'moversco'),
			),
		),
		array(
			'id'            => 'tax_titlebar_image',
			'type'          => 'upload',
			'title' => esc_html__('Titlebar Bakground Image URL', 'moversco'),
			'after' => '<p>' . sprintf( esc_html__('Select Titlebar background image for this %s. Please upload the image first from media section.', 'moversco'), $service_cat_title_singular ) . '</p>',
			'settings'      => array(
				'upload_type'  => 'image',
				'button_title' => esc_html__('Upload', 'moversco'),
				'frame_title'  => esc_html__('Select an image', 'moversco'),
				'insert_title' => esc_html__('Use this image', 'moversco'),
			),
		),
	),
);
// For Team Group
$themestek_taxonomy_options[]   = array(
	'id'       => 'themestek_taxonomy_options',
	'taxonomy' => 'themestek-team-group', // category, post_tag or your custom taxonomy name
	'fields'   => array(
		array(
			'id'            => 'tax_featured_image',
			'type'          => 'upload',
			'title' => esc_html__('Featured Image URL', 'moversco'),
			'after' => '<p>' . sprintf( esc_html__('Select featured image for this %s. Please upload the image first from media section.', 'moversco'), $team_group_title_singular ) . '</p>',
			'settings'      => array(
				'upload_type'  => 'image',
				'button_title' => esc_html__('Upload', 'moversco'),
				'frame_title'  => esc_html__('Select an image', 'moversco'),
				'insert_title' => esc_html__('Use this image', 'moversco'),
			),
		),
		array(
			'id'            => 'tax_titlebar_image',
			'type'          => 'upload',
			'title' => esc_html__('Titlebar Bakground Image URL', 'moversco'),
			'after' => '<p>' . sprintf( esc_html__('Select Titlebar background image for this %s. Please upload the image first from media section.', 'moversco'), $team_group_title_singular ) . '</p>',
			'settings'      => array(
				'upload_type'  => 'image',
				'button_title' => esc_html__('Upload', 'moversco'),
				'frame_title'  => esc_html__('Select an image', 'moversco'),
				'insert_title' => esc_html__('Use this image', 'moversco'),
			),
		),
	),
);
