<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// SHORTCODE GENERATOR OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options       = array();
// -----------------------------------------
// Basic Shortcode Examples                -
// -----------------------------------------
$options[]     = array(
  'title'      => 'ThemeStek Special Shortcodes',
  'shortcodes' => array(
	//Site Tagline
	array(
		'name'      => 'themestek-site-tagline',
		'title'     => esc_html__('Site Tagline', 'moversco'),
		'fields'    => array(
			array(
				'type'    => 'content',
				'content' => esc_html__('This shortcode will show the Site Tagline. There are no options for this shortcode. So just click Insert Shortcode button below to add this shortcode. ', 'moversco'),
			),
      ),
    ),
	// Site Title
	array(
		'name'      => 'themestek-site-title',
		'title'     => esc_html__('Site Title', 'moversco'),
		'fields'    => array(
			array(
				'type'    => 'content',
				'content' => esc_html__('This shortcode will show the Site Title. There are no options for this shortcode. So just click Insert Shortcode button below to add this shortcode.', 'moversco'),
			),
      ),
    ),
	// Site URL
	array(
		'name'      => 'themestek-site-url',
		'title'     => esc_html__('Site URL', 'moversco'),
		'fields'    => array(
			array(
				'type'    => 'content',
				'content' => esc_html__('This shortcode will show the Site URL. There are no options for this shortcode. So just click Insert Shortcode button below to add this shortcode.', 'moversco'),
			),
      ),
    ),
	// Site LOGO
	array(
		'name'      => 'themestek-logo',
		'title'     => esc_html__('Site Logo', 'moversco'),
		'fields'    => array(
			array(
				'type'    => 'content',
				'content' => esc_html__('This shortcode will show the Site Logo. There are no options for this shortcode. So just click Insert Shortcode button below to add this shortcode.', 'moversco'),
			),
      ),
    ),
	// Current Year
	array(
		'name'      => 'themestek-current-year',
		'title'     => esc_html__('Current Year', 'moversco'),
		'fields'    => array(
			array(
				'type'    => 'content',
				'content' => esc_html__('This shortcode will show the Current Year. There are no options for this shortcode. So just click Insert Shortcode button below to add this shortcode.', 'moversco'),
			),
      ),
    ),
	// Footer Menu
	array(
		'name'      => 'themestek-footermenu',
		'title'     => esc_html__('Footer Menu', 'moversco'),
		'fields'    => array(
			array(
				'type'    => 'content',
				'content' => esc_html__('This shortcode will show the Footer Menu. There are no options for this shortcode. So just click Insert Shortcode button below to add this shortcode.', 'moversco'),
			),
      ),
    ),
	// Skin Color
	array(
		'name'      => 'themestek-skincolor',
		'title'     => esc_html__('Skin Color', 'moversco'),
		'fields'    => array(
			array(
				'type'   	 => 'content',
				'content'	 => esc_html__('This shortcode will show the Text in Skin Color', 'moversco'),
			),
			 array(
				'id'         => 'content',
				'type'       => 'text',
				'title'      => esc_html__('Skin Color Text', 'moversco'),
				'after'   	 => '<div class="cs-text-muted"><br>'.esc_html__('The content is this box will be shown in Skin Color', 'moversco').'</div>', 
			),
      ),
    ),
	// Dropcaps
	array(
		'name'      => 'themestek-dropcap',
		'title'     => esc_html__('Dropcap', 'moversco'),
		'fields'    => array(
			array(
				'type'   	 => 'content',
				'content'	 => esc_html__('This will show text in dropcap style.', 'moversco'),
			),
			array(
				'id'        	=> 'style',
				'title'     	=> esc_html__('Style', 'moversco'),
				'type'      	=> 'image_select',
				'options'    	=> array(
									''        => get_template_directory_uri() .'/includes/images/dropcap1.png',
									'square'  => get_template_directory_uri() .'/includes/images/dropcap2.png',
									'rounded' => get_template_directory_uri() .'/includes/images/dropcap3.png',
									'round'   => get_template_directory_uri() .'/includes/images/dropcap4.png',
								),
				'default'     	=> ''
			),
			array(
				'id'         	=> 'bgcolor',
				'type'       	=> 'select',
				'title'     	=> esc_html__('Background Color', 'moversco'),
				'options'    	=> array(
									'white' 	    => esc_html__('White', 'moversco'),
									'skincolor'     => esc_html__('Skin Color', 'moversco'),
									'grey' 			=> esc_html__('Grey', 'moversco'),
									'dark' 		    => esc_html__('Dark', 'moversco'),
								),
				'class'         => 'chosen',
				'default'     	=> 'skincolor'
			),
			array(
				'id'         	=> 'color',
				'type'       	=> 'select',
				'title'     	=> esc_html__('Color', 'moversco'),
				'options'    	=> array(
									'skincolor'     => esc_html__('Skin Color', 'moversco'),
									'white' 	    => esc_html__('White', 'moversco'),
									'grey' 			=> esc_html__('Grey', 'moversco'),
									'dark' 		    => esc_html__('Dark', 'moversco'),
								),
				'class'         => 'chosen',
				'default'     	=> 'skincolor'
			),
			 array(
				'id'         	=> 'content',
				'type'      	=> 'text',
				'title'     	=> esc_html__('Text', 'moversco'),
				'after'   	 	=> '<div class="cs-text-muted"><br>'.esc_html__('The Letter in this box will be shown Dropcapped', 'moversco').'</div>', 
			),
      ),
    ),
  ),
);
CSFramework_Shortcode_Manager::instance( $options );
