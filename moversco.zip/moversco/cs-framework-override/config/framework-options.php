<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// Get current theme name and vesion
$themestek_theme = wp_get_theme();
$themestek_theme_name = $themestek_theme->get( 'Name' );
$themestek_theme_ver  = $themestek_theme->get( 'Version' );
// Getting all theme options again if variable is not defined
global $moversco_theme_options;
if( empty($moversco_theme_options) || !is_array($moversco_theme_options) ){
	if( function_exists('themestek_load_default_theme_options') ){
		themestek_load_default_theme_options();
	} else {
		$moversco_theme_options = get_option('moversco_theme_options');
	}
}
// variables
$team_member_title          = ( !empty($moversco_theme_options['team_type_title']) ) ? esc_html($moversco_theme_options['team_type_title']) : esc_html__('Team Members', 'moversco') ;
$team_member_title_singular = ( !empty($moversco_theme_options['team_type_title_singular']) ) ? esc_html($moversco_theme_options['team_type_title_singular']) : esc_html__('Team Member', 'moversco') ;
$team_group_title           = ( !empty($moversco_theme_options['team_group_title']) ) ? esc_html($moversco_theme_options['team_group_title']) : esc_html__('Team Groups', 'moversco') ;
$team_group_title_singular  = ( !empty($moversco_theme_options['team_group_title_singular']) ) ? esc_html($moversco_theme_options['team_group_title_singular']) : esc_html__('Team Group', 'moversco') ;
$pf_title               = ( !empty($moversco_theme_options['pf_type_title']) ) ? esc_html($moversco_theme_options['pf_type_title']) : esc_html__('Project', 'moversco') ;
$pf_title_singular      = ( !empty($moversco_theme_options['pf_type_title_singular']) ) ? esc_html($moversco_theme_options['pf_type_title_singular']) : esc_html__('Project', 'moversco') ;
$pf_cat_title           = ( !empty($moversco_theme_options['pf_cat_title']) ) ? esc_html($moversco_theme_options['pf_cat_title']) : esc_html__('Project Categories', 'moversco') ;
$pf_cat_title_singular  = ( !empty($moversco_theme_options['pf_cat_title_singular']) ) ? esc_html($moversco_theme_options['pf_cat_title_singular']) : esc_html__('Project Category', 'moversco') ;
$service_title               = ( !empty($moversco_theme_options['service_type_title']) ) ? esc_html($moversco_theme_options['service_type_title']) : esc_html__('Service', 'moversco') ;
$service_title_singular      = ( !empty($moversco_theme_options['service_type_title_singular']) ) ? esc_html($moversco_theme_options['service_type_title_singular']) : esc_html__('Service', 'moversco') ;
$service_cat_title           = ( !empty($moversco_theme_options['service_cat_title']) ) ? esc_html($moversco_theme_options['service_cat_title']) : esc_html__('Service Categories', 'moversco') ;
$service_cat_title_singular  = ( !empty($moversco_theme_options['service_cat_title_singular']) ) ? esc_html($moversco_theme_options['service_cat_title_singular']) : esc_html__('Service Category', 'moversco') ;
/**
 *  Blogbox Styles
 */
$blog_styles = array_merge( array( 'classic' => get_template_directory_uri() . '/includes/images/blogbox-style-classic.jpg' ), themestek_global_template_list('blog', true) );
/**
 *  FRAMEWORK SETTINGS
 */
$themestek_framework_settings = array(
	'menu_title' 	  => esc_html__('MoversCO Options', 'moversco'),
	'menu_type'  	  => 'menu',
	'menu_slug'  	  => 'themestek-theme-options',
	'ajax_save'  	  => true,
	'show_reset_all'  => false,
	'framework_title' => esc_html($themestek_theme_name).'  <small>'.esc_html($themestek_theme_ver).'</small>',
	'menu_position'   => 2, // See below comment for proper number
);
/**
 *  FRAMEWORK OPTIONS
 */
$themestek_framework_options = array();
// Layout Settings
$themestek_framework_options[] = array(
	'name'   => 'layout_settings', // like ID
	'title'  => esc_html__('Layout Settings', 'moversco'),
	'icon'   => 'fa fa-gear',
	'sections' => array(
		// Layout Settings - General Settings
		array(
			'name'   => 'general_settings', // like ID
			'icon'   => 'fa fa-gear',
			'title'  => esc_html__('General Settings', 'moversco'),
			'fields' => array( // begin: fields
				array(
					'type'    	=> 'heading',
					'content'	=> esc_html__('General settings like logo, header, skincolor etc.', 'moversco'),
				),
				array(
					'id'    => 'themestek_one_click_demo_setup',
					'type'  => 'themestek_one_click_demo_import',
					'title' => esc_html__('Demo Content Importer', 'moversco'),
					'after' => '<br><div class="cs-text-muted cs-text-desc">'.esc_html__('Demo content setup. This will add demo data same as our demo site (excluding images because they are copyright)', 'moversco').'</div>',
				),
				array(
					'id'      => 'skincolor',
					'type'    => 'themestek_skin_color',
					'title'   => esc_html__( 'Select Skin Color', 'moversco' ),
					'after'   	=> '<br><div class="cs-text-muted cs-text-desc">'.esc_html__('Select the main color. This color will be used globally.', 'moversco').'</div>',
					'default' => '#e32222',
					'options' => array(
						'Rio Grande'		=> '#e32222', /* Default skin color */
						'Science Blue'		=> '#0073cc',
						'Red Orange'		=> '#ff4229',
						'Vivid Violet'		=> '#af33bb',
						'Tan Hide'			=> '#f9a861',
						'Selective Yellow'	=> '#ffb901',
						'Red'				=> '#ff0b09',
						'Purple Heart'		=> '#6c33bb',
						'Azure Radiance'	=> '#0095eb',
						'Mountain Meadow'	=> '#18c47c',
					),
					'rgba'    => false,
				),
				array(
					'id'     		 => 'skincolor_dark',
					'type'   		 => 'color_picker',
					'title'  		 => esc_attr__('Dark Grey Color', 'labtechco' ),
					'default'		 => '#313437',
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_attr__('Select Dark Grey Color', 'labtechco').'</div>',
				),
				array(
					'id'     		 => 'skincolor_light',
					'type'   		 => 'color_picker',
					'title'  		 => esc_attr__('Grey Color', 'labtechco' ),
					'default'		 => '#f3f3f3',
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_attr__('Select Grey color', 'labtechco').'</div>',
				),
				array(
					'id'		=> 'layout',
					'type'		=> 'image_select',//themestek_pre_color_packages
					'title'		=> esc_html__('Pages Layout', 'moversco'),
					'options'	=> array(
						'wide'		=> get_template_directory_uri() . '/includes/images/layout-wide.png',
						'boxed'		=> get_template_directory_uri() . '/includes/images/layout-box.png',
						'framed'	=> get_template_directory_uri() . '/includes/images/layout-frame.png',
						'rounded'	=> get_template_directory_uri() . '/includes/images/layout-rounded.png',
						'fullwide'	=> get_template_directory_uri() . '/includes/images/layout-fullwide.png',
					),
					'default'	=> 'wide',
					'after'		=> '<br><div class="cs-text-muted cs-text-desc">'.esc_html__('Specify the layout for the pages', 'moversco').'</div>',
					'radio'		=> true,
				),
				array(
					'id'        => 'full_wide_elements',
					'type'      => 'checkbox',
					'title'     => esc_html__('Select Elements for Full Wide View (in above option)', 'moversco'),
					'options'   => array(
						'floatingbar' => esc_html__('Floatbar', 'moversco'),
						'topbar'      => esc_html__('Pre Header', 'moversco'),
						'header'      => esc_html__('Header', 'moversco'),
						'content'     => esc_html__('Content Area', 'moversco'),
						'footer'      => esc_html__('Footer', 'moversco'),
					),
					'default'    => array( 'header', 'footer' ),
					'after'    	 => '<small>'.esc_html__('Select elements that you want to show in full-wide view', 'moversco').'</small>',
					'dependency' => array( 'layout_fullwide', '==', 'true' ),
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Logo', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Select or upload your logo. You can also show text logo from here.', 'moversco').'<br /> <span class="themestek-toptions-head-highlight">'.esc_html__('You can go to "Header Settings" tab from the left menu for more options.', 'moversco') . '</span></small>',
				),
				array(
				  'id'      	 	 => 'logotype',
				  'type'     		 => 'radio',
				  'title'    		 => esc_html__('Logo type', 'moversco'),
				  'options' 		 => array(
						'text'			=> esc_html__('Logo as Text', 'moversco'),
						'image'			=> esc_html__('Logo as Image', 'moversco')
					),
				  'default'  		 => 'image',
				  'after'  			 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Specify the type of logo. It can Text or Image', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'logotext',
					'type'    		 => 'text',
					'title'   		 => esc_html__('Logo Text', 'moversco'),
					'default' 		 => esc_html('MoversCO'),
					'dependency'  	 => array( 'logotype_text', '==', 'true' ),
					'after'  			 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Enter the text to be used instead of the logo image', 'moversco').'</div>',
				),
				array(
					'id'             => 'logo_font',
					'type'           => 'themestek_typography',
					'title'          => esc_html__('Logo Font', 'moversco'),
					'chosen'         => false,
					'text-align'     => false,
					'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
					'font-backup'    => true, // Select a backup non-google font in addition to a google font
					'subsets'        => false, // Only appears if google is true and subsets not set to false
					'line-height'    => true,
					'text-transform' => true,
					'word-spacing'   => false, // Defaults to false
					'letter-spacing' => true, // Defaults to false
					'color'          => true,
					'all-varients'   => false,
					'output'         => '.headerlogo a.home-link', // An array of CSS selectors to apply this font style to dynamically
					'default'        => array(
						'family' => 'Nunito Sans',
						'backup-family' => 'Arial, Helvetica, sans-serif',
						'variant' => '700',
						'text-transform' => '',
						'font-size' => '26',
						'line-height' => '27',
						'letter-spacing' => '0',
						'color' => '#202020',
						'font' => 'google',
					),
					'dependency'  	=> array( 'logotype_text', '==', 'true' ),
					'after'  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This will be applied to logo text only. Select Logo font-style and size', 'moversco').'</div>',
				),
				array(
					'id'       		 => 'logoimg',
					'type'     		 => 'themestek_image',
					'title'    		 => esc_html__('Logo Image', 'moversco'),
					'dependency'  	 => array( 'logotype_image', '==', 'true' ),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Upload image that will be used as logo for the site ', 'moversco') . sprintf(esc_html__('%1$sNOTE:%2$s Upload image that will be used as logo for the site', 'moversco'),'<strong>', '</strong>').'</div>',
					'add_title'		 => esc_html__('Upload Site Logo','moversco'),
					'default'		 => array(
						'thumb-url'	=> get_template_directory_uri() . '/images/logo.png',
						'full-url'	=> get_template_directory_uri() . '/images/logo.png',
					),
				),
				array(
					'id'       		 => 'logoimg_crossover',
					'type'     		 => 'themestek_image',
					'title'    		 => esc_html__('Logo Image (on cross effect and classic header style only)', 'moversco'),
					'dependency'  	 => array( 'logotype_image', '==', 'true' ),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Upload image that will be used as logo for the site ', 'moversco') . sprintf(esc_html__('%1$sNOTE:%2$s Upload image that will be used as logo for the site only when crossing effect is available', 'moversco'),'<strong>', '</strong>').'</div>',
					'add_title'		 => esc_html__('Upload Site Logo for crossing effect header','moversco'),
					'default'		 => array(
						'thumb-url'	=> get_template_directory_uri() . '/images/logo-white-dark.png',
						'full-url'	=> get_template_directory_uri() . '/images/logo-white-dark.png',
					),
				),
				array(
					'id'       		 => 'logoimg_sticky',
					'type'     		 => 'themestek_image',
					'title'    		 => esc_html__('Logo Image for Sticky Header (optional)', 'moversco'),
					'dependency'  	 => array( 'sticky_header|logotype_image', '==|==', 'true|true' ),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('This logo will appear only on sticky header only.', 'moversco') . '</div>',
					'add_title'		 => esc_html__('Upload Sticky Logo','moversco'),
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Header Style', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options to change header style.', 'moversco'). '<br /> <span class="themestek-toptions-head-highlight">'.esc_html__('You can go to "Header Settings" tab from the left menu for more options.', 'moversco') . '</span></small>',
				),
				array(
					'id'			=> 'headerstyle',
					'type' 			=> 'image_select',
					'title'			=> esc_html__('Select Header Style', 'moversco'),
					'desc'     		=> esc_html__('Please select header style', 'moversco'),
					'wrap_class'    => 'themestek-header-style',
					'options'      	=> array(
						'classic'			=> get_template_directory_uri() . '/includes/images/header-classic.png',
						'infostack'			=> get_template_directory_uri() . '/includes/images/header-infostack.png', // demo1
						'classic-overlay'	=> get_template_directory_uri() . '/includes/images/header-classic-overlay.png', // demo2
						'4'	=> get_template_directory_uri() . '/includes/images/header-style4.png', // demo3
						'5'	=> get_template_directory_uri() . '/includes/images/header-style5.png', // demo4
						'6'	=> get_template_directory_uri() . '/includes/images/header-style6.png', // demo5
					),
					'default'		=> 'classic',
					'attributes' 	=> array(
						'data-depend-id' => 'header_style'
					),
					'radio' 		=> true,
				),
				// Options for selected header
				array(
					'type'    		=> 'heading',
					'content'		=> esc_html__('Options for selected header', 'moversco'),
					'dependency'	=> array( 'header_style', 'any', 'classic,classic-overlay,infostack' ),
					'after'  	  	 => '<small>'.esc_html__('These options will appear for selected header style only.', 'moversco').'</small>',
				),
				// Button
				// Group
				array(
					'id'		=> 'header_btn',
					'type'		=> 'fieldset',
					'title'		=> esc_html__('Header Button', 'moversco'),
					'fields'	=> array(
						array(
							'id'     		=> 'header_btn_text',
							'type'    		=> 'text',
							'title'   		=> esc_html__('Header Button Text', 'moversco'),
							'default' 		=> esc_html__('REQUEST A QUOTE', 'moversco'),
							'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('Header Button text', 'moversco') . '</div>',
						),
						array(
							'id'     		=> 'header_btn_link',
							'type'    		=> 'text',
							'title'   		=> esc_html__('Header Button Link', 'moversco'),
							'default' 		=> esc_html('#'),
							'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('Header Button link', 'moversco') . '</div>',
						),
					),
					'dependency'	=> array( 'header_style', 'any', 'infostack,4' ),
				),
				array(
					'id'     		=> 'header_phone',
					'type'    		=> 'text',
					'title'   		=> esc_html__('Header Phone Number', 'moversco'),
					'default' 		=> esc_html__('888 999 0000', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('Header Phone number', 'moversco') . '</div>',
					'dependency'	=> array( 'header_style', 'any', 'classic-overlay' ),
				),
				array(
					'id'            => 'header_menu_position',
					'type'          => 'select',
					'title'         =>  esc_html__('Header Menu Position', 'moversco'),
					'options'  		=> array(
						'left'			=> esc_html__('Left Align', 'moversco'),
						'right'			=> esc_html__('Right Align', 'moversco'),
						'center'		=> esc_html__('Center Align', 'moversco'),
					),
					'default'       => 'right',
					'dependency'  	=> array( 'header_style', 'any', 'classic,classic-overlay' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select Menu Position. This option will work for currently selected header style only ', 'moversco').'</div>',
				),
				array(
					'id'     		=> 'header_show_social',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Show Social Links', 'moversco'),
					'default' 		=> true,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">' . esc_html__('Show or hide social links in header.', 'moversco') . '</div>',
				),
				array(
					'id'       		 => 'infostack_left_text',
					'type'     		 => 'textarea',
					'title'    		 =>  esc_html__('InfoStack First Box Content', 'moversco'),
					'shortcode'		 => true,
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This content will appear on Left side of logo', 'moversco').'</div>',
					'default'        => themestek_wp_kses('<div class="media-left"><div class="icon"> <i class="themestek-moversco-icon-phone-call"></i></div></div><div class="media-right"><h6>Telephone </h6><h3>+123456789 </h3> </div>'),
					'dependency'  	 => array( 'header_style', 'any', 'infostack' ),
				),
				array(
					'id'       		 => 'infostack_right_text',
					'type'     		 => 'textarea',
					'title'    		 =>  esc_html__('InfoStack Second Box Content', 'moversco'),
					'shortcode'		 => true,
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This content will appear on Right side of logo', 'moversco').'</div>',
					'default'        => themestek_wp_kses('<div class="media-left"><div class="icon"> <i class="themestek-moversco-icon-envelope"></i></div></div><div class="media-right"><h6>Email Address </h6><h3>info@moversco.com </h3> </div>'),
					'dependency'  	 => array( 'header_style', 'any', 'infostack' ),
				),
				array(
					'id'     		 => 'header_menuarea_height',
					'type'    		 => 'number',
					'title'   		 => esc_html__('Menu area height', 'moversco'),
					'default' 		 => '70',
					'after'          => esc_html(' px'),
					'attributes'     => array(
						'min'       	 => 40,
					),
					'subtitle'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Height for menu area only', 'moversco').'</div>',
					'dependency'     => array( 'header_style', 'any', 'infostack' ),
				),
				array(
					'id'            => 'header_menu_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Header Menu Background Color', 'moversco'),
					'options'  		=> array(
						'darkgrey'		=> esc_html__('Dark grey', 'moversco'),
						'grey'			=> esc_html__('Grey', 'moversco'),
						'white'			=> esc_html__('White', 'moversco'),
						'skincolor'		=> esc_html__('Skincolor', 'moversco'),
						'custom'		=> esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'skincolor',
					'dependency'	=> array( 'header_style', 'any', 'infostack' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined background color for Menu area in header', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'header_menu_bg_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Header Menu Background Custom Background Color', 'moversco' ),
					'default'		 => 'rgba(0,0,0,0.31)',
					'dependency'  	 => array( 'header_menu_bg_color|header_style', '==|any', 'custom|infostack' ),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom background color for Header Menu area', 'moversco').'</div>',
				),
				array(
					'id'            => 'sticky_header_menu_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Sticky Header Menu Background Color', 'moversco'),
					'options'  		=> array(
						'darkgrey'   => esc_html__('Dark grey', 'moversco'),
						'grey'       => esc_html__('Grey', 'moversco'),
						'white'      => esc_html__('White', 'moversco'),
						'skincolor'  => esc_html__('Skincolor', 'moversco'),
						'custom'     => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'darkgrey',
					'dependency'	=> array( 'header_style', 'any', 'infostack' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined background color for Menu area in header when header is sticky', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'sticky_header_menu_bg_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Sticky Header Menu Background Custom Background Color', 'moversco' ),
					'default'		 => '#ffffff',
					'dependency'  	 => array( 'sticky_header_menu_bg_color|header_style', '==|any', 'custom|infostack' ),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom background color for Header Menu area when header is sticky', 'moversco').'</div>',
				),
				array(
					'type'      	=> 'heading',
					'content'     	=> esc_html__('Background Settings', 'moversco'),
					'after'  		=> '<small>'.esc_html__('Set below background options. Background settings will be applied to Boxed layout only', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'global_background',
					'type'   		=> 'themestek_background',
					'title' 		=> esc_html__('Body Background Properties', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set background for main body. This is for main outer body background. For "Boxed" layout only.', 'moversco').'</div>',
					'default'		=> array(
						'color'			=> '#ffffff',
					),
					'output'        => 'body',
				),
				array(
					'id'     		=> 'inner_background',
					'type'    		=> 'themestek_background',
					'title'  		=> esc_html__('Content Area Background Properties', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set background for content area', 'moversco').'</div>',
					'default' 	=> array(),
					'output'        => 'body #main',
				),
				array(
					'type'		=> 'heading',
					'content'	=> esc_html__('Pre-loader Image', 'moversco'),
					'after'		=> '<small>'.esc_html__('Select pre-loader image for the site. This will work on desktop, mobile and tablet devices', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'preloader_show',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Show Pre-loader animation', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">' . esc_html__('Show or hide pre-loader animation.', 'moversco') . '</div>',
				),
				array(
					'id'		=> 'loaderimg',
					'type'		=> 'image_select',
					'title'		=> esc_html__('Pre-loader Image', 'moversco'),
					'options'	=> array(
						'1'   		=> get_template_directory_uri() . '/images/loader1.svg',
						'2'   		=> get_template_directory_uri() . '/images/loader2.svg',
						'3'   		=> get_template_directory_uri() . '/images/loader3.svg',
						'4'   		=> get_template_directory_uri() . '/images/loader4.svg',
						'5'   		=> get_template_directory_uri() . '/images/loader5.svg',
						'6'   		=> get_template_directory_uri() . '/images/loader6.svg',
						'7'   		=> get_template_directory_uri() . '/images/loader7.svg',
						'8'   		=> get_template_directory_uri() . '/images/loader8.svg',
						'9'   		=> get_template_directory_uri() . '/images/loader9.svg',
						'10'   		=> get_template_directory_uri() . '/images/loader10.svg',
						'custom'	=> get_template_directory_uri() . '/images/loader-custom.gif',
					),
					'radio'		=> true,
					'default'	=> '1',
					'after'		=> '<div class="cs-text-muted cs-text-desc">' . esc_html__('Please select pre-loader image.', 'moversco') . '</div>',
					'dependency' => array( 'preloader_show', '==', 'true' ),
				),
				array(
					'id'       		=> 'loaderimage_custom',
					'type'      	=> 'image',
					'title'    		=> esc_html__('Upload Page-loader Image', 'moversco'),
					'add_title' 	=> 'Select/Upload Page-loader image',
					'after'  		=> '<div class="cs-text-muted cs-text-desc">' . esc_html__('Custom page-loader image that you want to show. You can create animated GIF image from your logo from Animizer website.', 'moversco') . ' <a href="'. esc_url('http://animizer.net/en/animate-static-image') .'" target="_blank">' . esc_html__('Click here to go to Anmizer website.', 'moversco') . '</a></div>',
					'dependency'    => array( 'loaderimg_custom|preloader_show', '==|==', 'true|true' ),
				),
				array(
					'type'		=> 'heading',
					'content'	=> esc_html__('Totop Button', 'moversco'),
					'after'		=> '<small>'.esc_html__('Show or hide Totop Button', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'hide_totop_button',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Hide Totop Button', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">' . esc_html__('Show or hide Totop Button.', 'moversco') . '</div>',
				),
			),
		),
		// Layout Settings - Floatbar Settings
		array(
			'name'   => 'floatingbar_settings', // like ID
			'title'  => esc_html__('Floatbar Settings', 'moversco'),
			'icon'   => 'fa fa-gear',
			'fields' => array( // begin: fields
				array(
					'type'    		=> 'heading',
					'content'		=> esc_html__('Floatbar Settings', 'moversco'),
				),
				array(
					'id'     		=> 'fbar_show',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Show Floatbar', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Show or hide Floatbar', 'moversco').'</div>',
				),
				array(
					'id'      => 'fbar-position',
					'type'    => 'radio',
					'title'   => esc_html__('Floating bar position', 'moversco'),
					'options' => array(
						'default' => esc_html__('Top','moversco'),
						'right'   => esc_html__('Right', 'moversco'),
					),
					'default'    => 'right',
					'after'      => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Position for Floating bar', 'moversco').'</div>',
					'dependency' => array( 'fbar_show', '==', 'true' ),
				),
				array(
					'id'            => 'fbar_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Floatbar Background Color', 'moversco'),
					'options'  		=> array(
						'darkgrey'    => esc_html__('Dark grey', 'moversco'),
						'grey'        => esc_html__('Grey', 'moversco'),
						'white'       => esc_html__('White', 'moversco'),
						'skincolor'   => esc_html__('Skincolor', 'moversco'),
						'custom'      => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'skincolor',
					'dependency' 	=> array( 'fbar_show', '==', 'true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Floatbar background color', 'moversco').'</div>',
				),
				array(
					'id'      		=> 'fbar_background',
					'type'    		=> 'themestek_background',
					'title'  		=> esc_html__('Floatbar Background Properties', 'moversco' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set background for Floating bar. You can set color or image and also set other background related properties', 'moversco').'</div>',
					'color'			=> true,
					'dependency' 	=> array( 'fbar_show', '==', 'true' ),
					'default'		=> array(
						'size'				=> 'cover',
						'color'				=> '#e32222',
					),
					'output' 	        => '.themestek-fbar-box-w',
					'output_bglayer'    => true,  // apply color to bglayer class div inside this , default: true
					'color_dropdown_id' => 'fbar_bg_color',   // color dropdown to decide which color
				),
				array(
					'id'            => 'fbar_text_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Floatbar Text Color', 'moversco'),
					'options' 		=> array(
						'white'			=> esc_html__('White', 'moversco'),
						'darkgrey'		=> esc_html__('Dark', 'moversco'),
						'custom'		=> esc_html__('Custom color', 'moversco'),
									),
					'default'		=> 'white',
					'dependency' 	=> array( 'fbar_show', '==', 'true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'fbar_text_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Floatbar Custom Color for text', 'moversco' ),
					'default'		 => '#dd3333',
					'dependency'  	 => array( 'fbar_show|fbar_text_color', '==|==', 'true|custom' ),//Multiple dependency
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom background color for Floatbar', 'moversco').'</div>',
				),
				array(
					'type'    	 => 'heading',
					'content'	 => esc_html__('Floatbar Open/Close Button Settings', 'moversco'),
					'after'		 => '<small>' . esc_html__('Settings for Floatbar Open/Close Button', 'moversco') . '</small>',
					'dependency' => array( 'fbar_show', '==', 'true' ),
				),
				array(
					'id'      => 'fbar_handler_icon',
					'type'    => 'themestek_iconpicker',
					'title'   => esc_html__('Open Link Icon', 'moversco' ),
					'default' => array(
						'library'				=> 'themify',
						'library_fontawesome'	=> 'fa fa-arrow-down',
						'library_linecons'		=> 'vc_li vc_li-bubble',
						'library_themify'		=> 'themifyicon ti-menu',
					),
					'dependency' => array( 'fbar_show', '==', 'true' ),
				),
				array(
					'id'      => 'fbar_handler_icon_close',
					'type'    => 'themestek_iconpicker',
					'title'   => esc_html__('Close Link Icon', 'moversco' ),
					'default' => array(
						'library'				=> 'themify',
						'library_fontawesome'	=> 'fa fa-arrow-up',
						'library_linecons'		=> 'vc_li vc_li-bubble',
						'library_themify'		=> 'themifyicon ti-close',
					),
					'dependency' => array( 'fbar_show', '==', 'true' ),
				),
				array(
					'id'            => 'fbar_icon_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Floatbar Open Icon Color', 'moversco'),
					'options' 		=> array(
							'dark'       => esc_html__('Dark grey', 'moversco'),
							'grey'       => esc_html__('Grey', 'moversco'),
							'white'      => esc_html__('White', 'moversco'),
							'skincolor'  => esc_html__('Skincolor', 'moversco'),
					),
					'default'		=> 'white',
					'dependency' 	=> array( 'fbar_show', '==', 'true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option.', 'moversco').'</div>',
				),
				array(
					'id'            => 'fbar_icon_color_close',
					'type'          => 'select',
					'title'         =>  esc_html__('Floatbar Close Icon Color', 'moversco'),
					'options' 		=> array(
							'dark'       => esc_html__('Dark grey', 'moversco'),
							'grey'       => esc_html__('Grey', 'moversco'),
							'white'      => esc_html__('White', 'moversco'),
							'skincolor'  => esc_html__('Skincolor', 'moversco'),
					),
					'default'		=> 'dark',
					'dependency' 	=> array( 'fbar_show', '==', 'true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option.', 'moversco').'</div>',
				),
				array(
					'type'    	 => 'heading',
					'content'	 => esc_html__('Floatbar Widget Settings', 'moversco'),
					'after'		 => '<small>' . esc_html__('Settings for Floatbar Widgets', 'moversco') . '</small>',
					'dependency' => array( 'fbar_show|fbar-position_default', '==|==', 'true|true' ),
				),
				array(
					'id'			=> 'fbar_widget_column_layout',
					'type' 			=> 'image_select',//themestek_pre_color_packages
					'title'			=> esc_html__('Floatbar Widget Columns', 'moversco'),
					'options'      	=> array(
							'12'      => get_template_directory_uri() . '/includes/images/footer_col_12.png',
							'6_6'     => get_template_directory_uri() . '/includes/images/footer_col_6_6.png',
							'4_4_4'   => get_template_directory_uri() . '/includes/images/footer_col_4_4_4.png',
							'3_3_3_3' => get_template_directory_uri() . '/includes/images/footer_col_3_3_3_3.png',
							'8_4'     => get_template_directory_uri() . '/includes/images/footer_col_8_4.png',
							'4_8'     => get_template_directory_uri() . '/includes/images/footer_col_4_8.png',
							'6_3_3'   => get_template_directory_uri() . '/includes/images/footer_col_6_3_3.png',
							'3_3_6'   => get_template_directory_uri() . '/includes/images/footer_col_3_3_6.png',
							'8_2_2'   => get_template_directory_uri() . '/includes/images/footer_col_8_2_2.png',
							'2_2_8'   => get_template_directory_uri() . '/includes/images/footer_col_2_2_8.png',
							'6_2_2_2' => get_template_directory_uri() . '/includes/images/footer_col_6_2_2_2.png',
							'2_2_2_6' => get_template_directory_uri() . '/includes/images/footer_col_2_2_2_6.png',
					),
					'default'		=> '3_3_3_3',
					'dependency' 	=> array( 'fbar_show|fbar-position_default', '==|==', 'true|true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select Floatbar Column layout View for widgets.', 'moversco').'</div>',
					'radio'      	=> true,
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Hide Floatbar in Small Devices', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Hide Floatbar in small devices like mobile, tablet etc.', 'moversco').'</small>',
					'dependency'     => array('fbar_show','==','true'),
				),
				array(
					'id'       => 'floatingbar-breakpoint',
					'type'     => 'radio',
					'title'    => esc_html__('Show/Hide Floatbar in Responsive Mode', 'moversco'),
					'subtitle' => esc_html__('Change options for responsive behaviour of Floatbar.', 'moversco'),
					'options'  => array(
						'all'      => esc_html__('Show in all devices','moversco'),
						'1200'     => esc_html__('Show only on large devices','moversco').' <small>'.esc_html__('show only on desktops (>1200px)', 'moversco').'</small>',
						'992'      => esc_html__('Show only on medium and large devices','moversco').' <small>'.esc_html__('show only on desktops and Tablets (>992px)', 'moversco').'</small>',
						'768'      => esc_html__('Show on some small, medium and large devices','moversco').' <small>'.esc_html__('show only on mobile and Tablets (>768px)', 'moversco').'</small>',
						'custom'   => esc_html__('Custom (select pixel below)', 'moversco'),
					),
					'dependency' => array('fbar_show','==','true'),
					'default'    => '1200'
				),
				array(
					'id'            => 'floatingbar-breakpoint-custom',
					'type'          => 'number',
					'title'         => esc_html__( 'Custom screen size to hide Floatbar (in pixel)', 'moversco' ),
					'subtitle'      => esc_html__( 'Select after how many pixels the Floatbar will be hidden.', 'moversco' ),
					'after'         => ' '.esc_html('px'),
					'default'       => '1200',
					'dependency' 	=> array( 'fbar_show|floatingbar-breakpoint_custom', '==|==', 'true|true' ),
				),
			)
		),
		// Layout Settings - Pre Header Settings
		array(
			'name'   => 'preheader_settings', // like ID
			'title'  => esc_html__('Pre Header Settings', 'moversco'),
			'icon'   => 'fa fa-gear',
			'fields' => array( // begin: fields
				array(
					'type'    		=> 'heading',
					'content'		=> esc_html__('Pre Header settings', 'moversco'),
				),
				array(
					'id'     		=> 'show_topbar',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Show Pre Header', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Show or hide Pre Header', 'moversco').'</div>',
				),
				array(
					'id'            => 'topbar_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Pre Header Background Color', 'moversco'),
					'options'  		=> array(
						'transparent' => esc_html__('Transparent', 'moversco'),
						'darkgrey'    => esc_html__('Dark grey', 'moversco'),
						'grey'        => esc_html__('Grey', 'moversco'),
						'white'       => esc_html__('White', 'moversco'),
						'skincolor'   => esc_html__('Skincolor', 'moversco'),
						'custom'      => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'darkgrey',
					'dependency' 	=> array( 'show_topbar', '==', 'true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Pre Header background color', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'topbar_bg_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Pre Header Custom Background Color', 'moversco' ),
					'default'		 => '#ffffff',
					'dependency'  	 => array( 'show_topbar|topbar_bg_color', '==|==', 'true|custom' ),//Multiple dependency
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom background color for Pre Header', 'moversco').'</div>',
				),
				array(
					'id'            => 'topbar_text_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Pre Header Text Color', 'moversco'),
					'options'  		=> array(
						'white'     	=> esc_html__('White', 'moversco'),
						'dark'      	=> esc_html__('Dark', 'moversco'),
						'skincolor' 	=> esc_html__('Skin Color', 'moversco'),
						'custom'   		=> esc_html__('Custom color', 'moversco'),
					),
					'default'       => 'white',
					'dependency' 	=> array( 'show_topbar', '==', 'true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'topbar_text_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Pre Header Custom Color for text', 'moversco' ),
					'default'		 => '#000000',
					'dependency'  	 => array( 'show_topbar|topbar_text_color', '==|==', 'true|custom' ),//Multiple dependency
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom color for Pre Header Text', 'moversco').'</div>',
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Pre Header Content Options', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Content for Pre Header', 'moversco').'</small>',
					'dependency' 	 => array( 'show_topbar', '==', 'true' ),
				),
				array(
					'id'       		 => 'topbar_left_text',
					'type'     		 => 'textarea',
					'title'    		 =>  esc_html__('Pre Header Left Content', 'moversco'),
					'shortcode'		 => true,
					'dependency' 	 => array( 'show_topbar', '==', 'true' ),
					'desc'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This content will appear on Left side of Pre Header area', 'moversco').'</div>',
					'default'        => themestek_wp_kses('<ul class="top-contact">
<li><i class="themestek-moversco-icon-phone"></i>Telphone : 123456789</li>
<li><i class="themestek-moversco-icon-mail-alt"></i><a href="#">Info@Alphabet.com</a></li>
</ul>'),
				),
				array(
					'id'       		 => 'topbar_right_text',
					'type'     		 => 'textarea',
					'title'    		 =>  esc_html__('Pre Header Right Content', 'moversco'),
					'shortcode'		 => true,
					'dependency' 	 => array( 'show_topbar', '==', 'true' ),
					'desc'  	 	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This content will appear on Right side of Pre Header area', 'moversco').'</div>',
					'after'  	 	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('html tags and shortcodes are allowed', 'moversco') . sprintf( esc_html__('%1$s Click here to know more %2$s about shortcode description','moversco') , '<a href="'. esc_url('http://moversco.themestekthemes.com/documentation/shortcodes.html') .'" target="_blank">' , '</a>'  ).'</div>',
					'default'		=> themestek_wp_kses('<div class="themestek-last-sep-none">[themestek-social-links]</div>'),
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Hide Pre Header Bar in Small Devices', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Hide Pre Header Bar in small devices like mobile, tablet etc.', 'moversco').'</small>',
					'dependency'     => array('show_topbar','==','true'),
				),
				array(
					'id'       => 'topbar-breakpoint',
					'type'     => 'radio',
					'title'    => esc_html__('Show/Hide Pre Header Bar in Responsive Mode', 'moversco'),
					'subtitle' => esc_html__('Change options for responsive behaviour of Pre Header Bar.', 'moversco'),
					'options'  => array(
						'all'      => esc_html__('Show in all devices','moversco'),
						'1200'     => esc_html__('Show only on large devices','moversco').' <small>'.esc_html__('show only on desktops (>1200px)', 'moversco').'</small>',
						'992'      => esc_html__('Show only on medium and large devices','moversco').' <small>'.esc_html__('show only on desktops and Tablets (>992px)', 'moversco').'</small>',
						'767'      => esc_html__('Show on some small, medium and large devices','moversco').' <small>'.esc_html__('show only on mobile and Tablets (>768px)', 'moversco').'</small>',
						'custom'   => esc_html__('Custom (select pixel below)', 'moversco'),
					),
					'dependency' => array('show_topbar','==','true'),
					'default'    => '1200'
				),
				array(
					'id'            => 'topbar-breakpoint-custom',
					'type'          => 'number',
					'title'         => esc_html__( 'Custom screen size to hide Pre Header (in pixel)', 'moversco' ),
					'subtitle'      => esc_html__( 'Select after how many pixels the Pre Header will be hidden.', 'moversco' ),
					'after'         => esc_html(' px'),
					'default'       => '1200',
					'dependency' 	=> array( 'show_topbar|topbar-breakpoint_custom', '==|==', 'true|true' ),
				),
			)
		),
		// Layout Settings - Header Settings
		array(
			'name'   => 'header_settings', // like ID
			'title'  => esc_html__('Header Settings', 'moversco'),
			'icon'   => 'fa fa-gear',
			'fields' => array( // begin: fields
				array(
					'type'    		=> 'heading',
					'content'		=> esc_html__('Header Settings', 'moversco'),
				),
				array(
					'id'     		 => 'header_height',
					'type'   		 => 'number',
					'title'          => esc_html__('Header Height (in pixel)', 'moversco' ),
					'after'  	  	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('You can set height of header area from here', 'moversco').'</div>',
					'default'		 => '105',
				),
				array(
					'id'            => 'header_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Header Background Color', 'moversco'),
					'options'		=> array(
						'transparent'	=> esc_html__('Transparent', 'moversco'),
						'darkgrey'		=> esc_html__('Dark grey', 'moversco'),
						'grey'			=> esc_html__('Grey', 'moversco'),
						'white'			=> esc_html__('White', 'moversco'),
						'skincolor'		=> esc_html__('Skincolor', 'moversco'),
						'custom'		=> esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'transparent',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Header background color', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'header_bg_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Header Custom Background Color', 'moversco' ),
					'default'		 => 'rgba(0,0,0,0)',
					'dependency'  	 => array( 'header_bg_color', '==', 'custom' ),//Multiple dependency
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom background color for Header', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'responsive_header_bg_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Responsive Header Custom Background Color', 'moversco' ),
					'default'		 => 'rgba(21,21,21,0.96)',
					'dependency'  	 => array( 'header_bg_color|header_style', '==|any', 'custom|classic-overlay,centerlogo-overlay,toplogo-overlay,classic-box-overlay,classic-box-overlay-rtl,classic-overlay-rtl,infostack-overlay,infostack-overlay-rtl' ),//Multiple dependency
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom background color for Header in responsive mode only. Like Mobile, tablet etc small screen devices.', 'moversco').'</div>',
				),
				array(
					'id'            => 'header_responsive_icon_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Header Responsive Icon Color', 'moversco'),
					'options'		=> array(
						'dark'			=> esc_html__('Dark', 'moversco'),
						'white'			=> esc_html__('White', 'moversco'),
					),
					'default'       => 'dark',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select color for responsive menu icon, cart icon, search icon. This is becuase PHP code cannot understand if you selected dark or light color as background. Will work in responsive only.', 'moversco').'</div>',
					'dependency'    => array( 'header_bg_color', '==', 'custom' ),//Multiple dependency
				),
				array(
					'id'     		 => 'logo_max_height',
					'type'   		 => 'number',
					'title'          => esc_html__('Logo Max Height', 'moversco' ),
					'after'  	  	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('If you feel your logo looks small than increase this and adjust it', 'moversco').'</div>',
					'default'		 => '40',
					'dependency'  	 => array( 'logotype_image', '==', 'true' ),
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Sticky Header', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options for sticky header', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'sticky_header',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Enable Sticky Header', 'moversco'),
					'default' 		=> true,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Select ON if you want the sticky header on page scroll', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'header_height_sticky',
					'type'   		 => 'number',
					'title'          => esc_html__('Sticky Header Height (in pixel)', 'moversco' ),
					'after'  	  	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('You can set height of header area when it becomes sticky', 'moversco').'</div>',
					'default'		 => '90',
					'dependency'     => array( 'sticky_header', '==', 'true' ),
				),
				array(
					'id'            => 'sticky_header_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Sticky Header Background Color', 'moversco'),
					'options'		=> array(
						'darkgrey'		=> esc_html__('Dark grey', 'moversco'),
						'grey'			=> esc_html__('Grey', 'moversco'),
						'white'			=> esc_html__('White', 'moversco'),
						'skincolor'		=> esc_html__('Skincolor', 'moversco'),
						'custom'		=> esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'white',
					'dependency'    => array( 'sticky_header', '==', 'true' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Sticky Header background color', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'sticky_header_bg_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Sticky Header Custom Background Color', 'moversco' ),
					'default'		 => '#ffffff',
					'dependency'  	 => array( 'sticky_header_bg_color|sticky_header', '==|==', 'custom|true' ),//Multiple dependency
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom background color for Sticky Header', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'logo_max_height_sticky',
					'type'   		 => 'number',
					'title'          => esc_html__('Logo Max Height when Sticky Header', 'moversco' ),
					'after'  	  	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set logo when the header is sticky', 'moversco').'</div>',
					'default'		 => '40',
					'dependency'     => array( 'sticky_header', '==', 'true' ),
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Search Button in Header', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Option to show or hide search button in header area', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'header_search',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Show Search Button', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Set this option "ON" to show search button in header. The icon will be at the right side (after menu)', 'moversco').'</div>',
				),
				array(
					'id'			=> 'search_input',
					'type'			=> 'text',
					'title'			=> esc_html__('Search Form Input Word', 'moversco'),
					'default'		=> esc_html__('Type Word Then Press Enter', 'moversco'),
					'after'			=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Write the search form input word here. <br> Default: "WRITE SEARCH WORD..."', 'moversco').'</div>',
					'dependency'	=> array( 'header_search', '==', 'true' ),
				),
				array(
					'id'     		 => 'searchform_title',
					'type'    		 => 'text',
					'title'   		 => esc_html__('Search Form Title', 'moversco'),
					'default' 		 => '',
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Write the title for search form. Default: "Hi, How Can We Help You?"', 'moversco').'</div>',
					'dependency'     => array( 'header_search', '==', 'true' ),
				),
				array(
					'id'       		 => 'logoimg_search',
					'type'     		 => 'themestek_image',
					'title'    		 => esc_html__('Logo on search form', 'moversco'),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Upload logo image that will be shown above the search form.', 'moversco').'</div>',
					'add_title'		 => esc_html__('Upload Logo','moversco'),
					'default'		 => array(
						'thumb-url'	=> get_template_directory_uri() . '/images/logo-white.png',
						'full-url'	=> get_template_directory_uri() . '/images/logo-white.png',
					),
					'dependency'	=> array( 'header_search', '==', 'true' ),
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Logo SEO', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options for Logo SEO', 'moversco').'</small>',
				),
				array(
					'id'      		=> 'logoseo',
					'type'   		=> 'radio',
					'title'   		=> esc_html__('Logo Tag for SEO', 'moversco'),
					'options' 		=> array(
						'h1homeonly' => esc_html__('H1 for home, SPAN on other pages', 'moversco'),
						'allh1'      => esc_html__('H1 tag everywhere', 'moversco'),
					),
					'default'		=> 'h1homeonly',
					'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select logo tag for SEO purpose', 'moversco').'</div>',
				),
			)
		),
		// Layout Settings - Menu Settings
		array(
			'name'   => 'menu_settings', // like ID
			'title'  => esc_html__('Menu Settings', 'moversco'),
			'icon'   => 'fa fa-gear',
			'fields' => array( // begin: fields
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Menu Settings', 'moversco'),
					'after'  	  	=> '<small>'.esc_html__('Responsive Menu Breakpoint: Change Options for responsive menu.', 'moversco').'</small>',
				),
				array(
					'id'      		=> 'menu_breakpoint',
					'type'   		=> 'radio',
					'title'   		=> esc_html__('Responsive Menu Breakpoint', 'moversco'),
					'options'  		=> array(
						'1200'   => esc_html__('Large devices','moversco').' <small>'.esc_html__('Desktops (>1200px)', 'moversco').'</small>',
						'992'    => esc_html__('Medium devices','moversco').' <small>'.esc_html__('Desktops and Tablets (>992px)', 'moversco').'</small>',
						'768'    => esc_html__('Small devices','moversco').' <small>'.esc_html__('Mobile and Tablets (>768px)', 'moversco').'</small>',
						'custom' => esc_html__('Custom (select pixel below)', 'moversco'),
					),
					'default'		=> '1200',
					'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Change options for responsive menu breakpoint', 'moversco').'</div>',
				),
				array(
					'id'     		=> 'megamenu-override',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Override Max Mega Menu Style', 'moversco'),
					'default' 		=> true,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('We need to override some of the Max mega Menu plugin\'s settings to match with our theme. If you like to use the default vanilla look of Max Mega Menu than turn this option off.', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'menu_breakpoint-custom',
					'type'   		 => 'number',
					'title'          => esc_html__('Custom Breakpoint for Menu (in pixel)', 'moversco' ),
					'dependency'  	 => array( 'menu_breakpoint_custom', '==', 'true' ),
					'default'		 => '1200',
					'after'  	  	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select after how many pixels the menu will become responsive', 'moversco').'</div>',
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Main Menu Options', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options for main menu in header', 'moversco').'</small>',
				),
				array(
					'id'             => 'mainmenufont',
					'type'           => 'themestek_typography',
					'title'          => esc_html__('Main Menu Font', 'moversco'),
					'chosen'         => false,
					'text-align'     => false,
					'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
					'font-backup'    => true, // Select a backup non-google font in addition to a google font
					'subsets'        => false, // Only appears if google is true and subsets not set to false
					'line-height'    => true,
					'text-transform' => true,
					'word-spacing'   => false, // Defaults to false
					'letter-spacing' => true, // Defaults to false
					'color'          => true,
					'all-varients'   => false,
					'output'         => '#site-header-menu #site-navigation div.nav-menu > ul > li > a, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal > li.mega-menu-item > a', // An array of CSS selectors to apply this font style to dynamically
					'units'          => 'px', // Defaults to px
					'default'        => array(
						'family' => 'Nunito Sans',
						'backup-family' => 'Arial, Helvetica, sans-serif',
						'variant' => '700',
						'text-transform' => '',
						'font-size' => '14',
						'line-height' => '16',
						'letter-spacing' => '0',
						'color' => '#313437',
						'font' => 'google',
					),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select main menu font, color and size', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'stickymainmenufontcolor',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Main Menu Font Color for Sticky Header', 'moversco' ),
					'default'		 => '#313437',
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Main menu font color when the header becomes sticky', 'moversco').'</div>',
				),
				array(
					'id'           	=> 'mainmenu_active_link_color',
					'type'         	=> 'select',
					'title'        	=>  esc_html__('Main Menu Active Link Color', 'moversco'),
					'options'  		=> array(
						'skin'			=> esc_html__('Skin color (default)', 'moversco'),
						'custom'		=> esc_html__('Custom color (select below)', 'moversco'),
					),
					'default'      	=> 'skin',
					'after'  		=> themestek_wp_kses('<div class="cs-text-muted cs-text-desc"><br>
											<strong>' . esc_html__('Tips:', 'moversco') . '</strong>
											<ul>
												<li>' . esc_html__('"Skin color (default):" Skin color for active link color.', 'moversco') . '</li>
												<li>' . esc_html__('"Custom color:" Custom color for active link color. Useful if you like to use any color for active link color.', 'moversco') . '</li>
											</ul>
										</div>'),
				),
				array(
					'id'     		 => 'mainmenu_active_link_custom_color',
					'type'   		 => 'color_picker',
					'title'  		 => esc_html__('Main Menu Active Link Custom Color', 'moversco' ),
					'default'		 => '#313437',
					'dependency'  	 => array( 'mainmenu_active_link_color', '==', 'custom' ),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom color for main menu active active link', 'moversco').'</div>',
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Drop Down Menu Options', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options for drop down menu in header', 'moversco').'</small>',
				),
				array(
					'id'             => 'dropdownmenufont',
					'type'           => 'themestek_typography',
					'title'          => esc_html__('Dropdown Menu Font', 'moversco'),
					'chosen'         => false,
					'text-align'     => false,
					'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
					'font-backup'    => true, // Select a backup non-google font in addition to a google font
					'subsets'        => false, // Only appears if google is true and subsets not set to false
					'line-height'    => true,
					'text-transform' => true,
					'word-spacing'   => false, // Defaults to false
					'letter-spacing' => true, // Defaults to false
					'color'          => true,
					'all-varients'   => false,
					'output'         => 'ul.nav-menu li ul li a, div.nav-menu > ul li ul li a, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu a, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu a:hover, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu a:focus, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu a.mega-menu-link, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu a.mega-menu-link:hover, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu a.mega-menu-link:focus, .themestek-mmmenu-override-yes #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu > li.mega-menu-item-type-widget', // An array of CSS selectors to apply this font style to dynamically
					'units'          => 'px', // Defaults to px
					'default'        => array(
						'family' => 'Roboto',
						'backup-family' => 'Arial, Helvetica, sans-serif',
						'variant' => '500',
						'text-transform' => 'uppercase',
						'font-size' => '12',
						'line-height' => '16',
						'letter-spacing' => '0.5',
						'color' => '#ffffff',
						'font' => 'google',
					),
					'after'  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select dropdown menu font, color and size', 'moversco').'</div>',
				),
				array(
					'id'           	=> 'dropmenu_active_link_color',
					'type'         	=> 'select',
					'title'        	=>  esc_html__('Dropdown Menu Active Link Color', 'moversco'),
					'options'  		=> array(
						'skin'			=> esc_html__('Skin color (default)', 'moversco'),
						'custom'		=> esc_html__('Custom color (select below)', 'moversco'),
					),
					'default'      	=> 'skin',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . '<strong>' . esc_html__('Tips:', 'moversco') . '</strong>' . '<ul><li>' . esc_html__('"Skin color (default):" Skin color for active link color.', 'moversco') . '</li><li>' . esc_html__('"Custom color:" Custom color for active link color. Useful if you like to use any color for active link color.', 'moversco') . '</li></ul></div>',
				),
				array(
					'id'     		=> 'dropmenu_active_link_custom_color',
					'type'   		=> 'color_picker',
					'title'  		=> esc_html__('Dropdown Menu Active Link Custom Color', 'moversco' ),
					'default'		=> '#3368c6',
					'dependency'  	=> array( 'dropmenu_active_link_color', '==', 'custom' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Custom color for dropdown menu active menu text', 'moversco').'</div>',
				),
				array(
					'id'      		=> 'dropmenu_background',
					'type'    		=> 'themestek_background',
					'title'  		=> esc_html__('Dropdown Menu Background Properties (for all dropdown menus)', 'moversco' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set background for dropdown menu. This will be applied to all dropdown menus. You can set common style here.', 'moversco').'</div>',
					'default'		=> array(
						'image'			=> '',
						'repeat'		=> 'no-repeat',
						'position'		=> 'center top',
						'size'			=> 'cover',
						'color'			=> '#313437',
					),
					'output' 	    => '.themestek-mmmenu-override-yes #site-header-menu #site-navigation div.mega-menu-wrap ul.mega-menu.mega-menu-horizontal li.mega-menu-item ul.mega-sub-menu, #site-header-menu #site-navigation div.nav-menu > ul > li ul',
				),
			)
		),
		// Layout Settings - Titlebar Settings
		array(
			'name'   => 'titlebar_settings', // like ID
			'title'  => esc_html__('Titlebar Settings', 'moversco'),
			'icon'   => 'fa fa-gear',
			'fields' => array( // begin: fields
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Titlebar Background Options', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Background options for Titlebar area', 'moversco').'</small>',
				),
				array(
					'id'            => 'titlebar_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Titlebar Background Color', 'moversco'),
					'options'  => array(
						'transparent' => esc_html__('Transparent', 'moversco'),
						'darkgrey'    => esc_html__('Dark grey', 'moversco'),
						'grey'        => esc_html__('Grey', 'moversco'),
						'white'       => esc_html__('White', 'moversco'),
						'skincolor'   => esc_html__('Skincolor', 'moversco'),
						'custom'      => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'custom',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Titlebar background color', 'moversco').'</div>',
				),
				array(
					'id'      		=> 'titlebar_background',
					'type'    		=> 'themestek_background',
					'title'  		=> esc_html__('Titlebar Background Image', 'moversco' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set background for Title bar. You can set color or image and also set other background related properties', 'moversco').'</div>',
					'color'			=> true,
					'default'		=> array(
						'repeat'		=> 'no-repeat',
						'position'		=> 'center center',
						'size'			=> 'cover',
						'color'			=> '#efefef',
					),
					'output' 	    => 'div.themestek-titlebar-wrapper',
					'output_bglayer'    => true,  // apply color to bglayer class div inside this , default: true
					'color_dropdown_id' => 'titlebar_bg_color',   // color dropdown to decide which color
				),
				array(
					'id'        => 'titlebar_bg_featured_img',
					'type'      => 'checkbox',
					'title'     => esc_html__('Featured Image as Titlebar Background', 'moversco'),
					'options'   => array(
						'post'				=> sprintf( esc_html__('For %1$s', 'moversco') , '<strong>Post</strong>' ),
						'page'				=> sprintf( esc_html__('For %1$s', 'moversco') , '<strong>Page</strong>' ),
						'themestek-portfolio'		=> sprintf( esc_html__('For %1$s', 'moversco') , '<strong>'.$pf_title_singular.'</strong>' ),
						'themestek-team'	=> sprintf( esc_html__('For %1$s', 'moversco') , '<strong>'.$team_member_title_singular.'</strong>' ),
					),
					'default'    => array(),
					'after'    	 => '<div class="cs-text-muted cs-text-desc">'.esc_html__('Select which section (CPT) will show featured image as background image in Titlebar.', 'moversco'). '<br>' . esc_html__('NOTE: This will work for Single view only.', 'moversco').'</div>',
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Titlebar Font Settings', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Font Settings for different elements in Titlebar area', 'moversco').'</small>',
				),
				array(
					'id'            => 'titlebar_text_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Titlebar Text Color', 'moversco'),
					'options'  => array(
						'white'  => esc_html__('White', 'moversco'),
						'dark'   => esc_html__('Dark', 'moversco'),
						'custom' => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'dark',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option', 'moversco').'</div>',
				),
				array(
					'id'             => 'titlebar_heading_font',
					'type'           => 'themestek_typography',
					'title'          => esc_html__('Heading Font', 'moversco'),
					'chosen'         => false,
					'text-align'     => false,
					'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
					'font-backup'    => true, // Select a backup non-google font in addition to a google font
					'subsets'        => false, // Only appears if google is true and subsets not set to false
					'line-height'    => true,
					'text-transform' => true,
					'word-spacing'   => false, // Defaults to false
					'letter-spacing' => true, // Defaults to false
					'color'          => true,
					'all-varients'   => true,
					'output'         => '.themestek-titlebar h1.entry-title, .themestek-titlebar-textcolor-custom .themestek-titlebar-main .entry-title', // An array of CSS selectors to apply this font style to dynamically
					'units'          => 'px', // Defaults to px
					'default'        => array(
						'family' => 'Biryani',
						'backup-family' => 'Arial, Helvetica, sans-serif',
						'variant' => '700',
						'text-transform' => '',
						'font-size' => '36',
						'line-height' => '40',
						'letter-spacing' => '0',
						'color' => '#dd9933',
						'all-varients' => 'on',
						'font' => 'google',
					),
					'after'			=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for heading in Titlebar', 'moversco').'</div>',
				),
				array(
					'id'             => 'titlebar_subheading_font',
					'type'           => 'themestek_typography',
					'title'          => esc_html__('Sub-heading Font', 'moversco'),
					'chosen'         => false,
					'text-align'     => false,
					'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
					'font-backup'    => true, // Select a backup non-google font in addition to a google font
					'subsets'        => false, // Only appears if google is true and subsets not set to false
					'line-height'    => true,
					'text-transform' => true,
					'word-spacing'   => false, // Defaults to false
					'letter-spacing' => true, // Defaults to false
					'color'          => true,
					'all-varients'   => true,
					'output'         => '.themestek-titlebar .entry-subtitle, .themestek-titlebar-textcolor-custom .themestek-titlebar-main .entry-subtitle', // An array of CSS selectors to apply this font style to dynamically
					'units'			 => 'px', // Defaults to px
					'default'        => array(
						'family' => 'Nunito Sans',
						'backup-family' => 'Arial, Helvetica, sans-serif',
						'variant' => '700',
						'text-transform' => '',
						'font-size' => '19',
						'line-height' => '22',
						'letter-spacing' => '1',
						'color' => '#dd9933',
						'all-varients' => 'on',
						'font' => 'google',
					),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for sub-heading in Titlebar', 'moversco').'</div>',
				),
				array(
					'id'             => 'titlebar_breadcrumb_font',
					'type'           => 'themestek_typography',
					'title'          => esc_html__('Breadcrumb Font', 'moversco'),
					'chosen'         => false,
					'text-align'     => false,
					'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
					'font-backup'    => true, // Select a backup non-google font in addition to a google font
					'subsets'        => false, // Only appears if google is true and subsets not set to false
					'line-height'    => true,
					'text-transform' => true,
					'word-spacing'   => false, // Defaults to false
					'letter-spacing' => true, // Defaults to false
					'color'          => true,
					'all-varients'   => false,
					'output'         => '.themestek-titlebar .breadcrumb-wrapper, .themestek-titlebar .breadcrumb-wrapper a', // An array of CSS selectors to apply this font style to dynamically
					'units'          => 'px', // Defaults to px
					'default'        => array(
						'family' => 'Roboto',
						'backup-family' => 'Arial, Helvetica, sans-serif',
						'variant' => '500',
						'text-transform' => '',
						'font-size' => '14',
						'line-height' => '24',
						'letter-spacing' => '0',
						'color' => '#eeee22',
						'font' => 'google',
					),
					'after'  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for breadcrumbs in Titlebar', 'moversco').'</div>',
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Titlebar Content Options', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Content options for Titlebar area', 'moversco').'</small>',
				),
				array(
					'id'            => 'titlebar_view',
					'type'          => 'select',
					'title'         =>  esc_html__('Titlebar Text Align', 'moversco'),
					'options'       => array(
						'default'  => esc_html__('All Center (default)', 'moversco'),
						'left'     => esc_html__('Title Left / Breadcrumb Right', 'moversco'),
						'right'    => esc_html__('Title Right / Breadcrumb Left', 'moversco'),
						'allleft'  => esc_html__('All Left', 'moversco'),
						'allright' => esc_html__('All Right', 'moversco'),
					),
					'default'       => 'default',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select text align in Titlebar', 'moversco').'</div>',
				),
				array(
					'id'     		 => 'titlebar_height',
					'type'   		 => 'number',
					'title'          => esc_html__( 'Titlebar Height', 'moversco' ),
					'after'  	  	 => ' px<br><div class="cs-text-muted cs-text-desc">'.esc_html__('Set height of the Titlebar. In pixel only', 'moversco').'</div>',
					'default'		 => '350',
				),
				array(
					'id'        	=> 'breadcrumb_on_bottom',
					'type'      	=> 'checkbox',
					'title'     	=> esc_html__('Show Breadcrumb on bottom of Titlebar area', 'moversco'),
					'label'     	=> esc_html__('YES', 'moversco'),
					'default'   	=> false,
					'dependency'  	=> array( 'titlebar_view', 'any', 'default,allleft,allright' ),//Multiple dependency
					'after'    		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select this option if you like to show breadcrumbs on bottom of Titlebar area. This option will only work when Titlebar Text Align option above is set to (All Center, All Left or All Right)', 'moversco').'</div>',
				),
				array(
					'id'            => 'titlebar_hide_breadcrumb',
					'type'          => 'select',
					'title'         =>  esc_html__('Hide Breadcrumb', 'moversco'),
					'options' 		=> array(
						'no'			=> esc_html__('NO, show the breadcrumb', 'moversco'),
						'yes'			=> esc_html__('YES, Hide the Breadcrumb', 'moversco'),
					),
					'default'       => 'no',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('You can show or hide the breadcrumb', 'moversco').'</div>',
				),
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Titlebar Extra Options', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Change settings for some extra options in Titlebar', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'titlebar_single_title',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Show post title instead of "Blog" on single post?', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Set this option "ON" to enable sticky footer on scrolling at bottom', 'moversco').'</div>',
				),
				array(
					'id'      => 'adv_tbar_catarc',
					'type'    => 'text',
					'title'   => esc_html__('Post Category "Category Archives:" Label Text', 'moversco'),
					'default' => esc_html__('Category Archives: ', 'moversco'),
				),
				array(
					'id'      => 'adv_tbar_tagarc',
					'type'    => 'text',
					'title'   => esc_html__('Post Tag "Tag Archives:" Label Text', 'moversco'),
					'default' => esc_html__('Tag Archives: ', 'moversco'),
				),
				array(
					'id'      => 'adv_tbar_postclassified',
					'type'    => 'text',
					'title'   => esc_html__('Post Taxonomy "Posts classified under:" Label Text', 'moversco'),
					'default' => esc_html__('Posts classified under: ', 'moversco'),
				),
				array(
					'id'      => 'adv_tbar_authorarc',
					'type'    => 'text',
					'title'   => esc_html__('Post Author "Author Archives:" Label Text', 'moversco'),
					'default' => esc_html__('Author Archives: ', 'moversco'),
				),
			)
		),
		// Layout Settings - Footer Settings
		array(
			'name'   => 'footer_settings', // like ID
			'title'  => esc_html__('Footer Settings', 'moversco'),
			'icon'   => 'fa fa-gear',
			'fields' => array( // begin: fields
				array(
					'type'			=> 'heading',
					'content'    	=> esc_html__('Sticky Footer', 'moversco'),
					'after'  	  	=> '<small>'.esc_html__('Make footer sticky and visible on scrolling at bottom', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'stickyfooter',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Sticky Footer', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Set this option "ON" to enable sticky footer on scrolling at bottom', 'moversco').'</div>',
				),
				// Footer common background
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Footer Background (full footer elements)', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('This background property will apply to full footer area. You can add', 'moversco').'</small>',
				),
				array(
					'id'            => 'full_footer_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Footer Background Color (all area)', 'moversco'),
					'options'		=> array(
						'transparent' => esc_html__('Transparent', 'moversco'),
						'darkgrey'    => esc_html__('Dark grey', 'moversco'),
						'grey'        => esc_html__('Grey', 'moversco'),
						'white'       => esc_html__('White', 'moversco'),
						'skincolor'   => esc_html__('Skincolor', 'moversco'),
						'custom'      => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'darkgrey',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Footer background color', 'moversco').'</div>',
				),
				array(
					'id'      		 => 'full_footer_bg_all',
					'type'    		 => 'themestek_background',
					'title'  		 => esc_html__('Footer Background (all area)', 'moversco' ),
					'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Footer background image', 'moversco').'</div>',
					'default'		 => array(
						'repeat'		=> 'no-repeat',
						'position'		=> 'center center',
						'attachment'	=> 'fixed',
						'size'			=> 'cover',
						'color'			=> 'rgba(30,115,190,0.9)',
					),
					'output' 	     => '.footer',
					'output_bglayer' => true,  // apply color to bglayer class div inside this , default: true
					'color_dropdown_id' => 'full_footer_bg_color',   // color dropdown to decide which color
				),
				// Footer CTA
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Footer Call-To-Action Area', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Modify elements like title, icon, button link, button title etc in footer Call-To-Action area.', 'moversco').'</small>',
				),
				array(
					'id'     		=> 'footer_cta',
					'type'   		=> 'switcher',
					'title'   		=> esc_html__('Show Footer CTA', 'moversco'),
					'default' 		=> false,
					'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Set this option "ON" to enable sticky footer on scrolling at bottom', 'moversco').'</div>',
				),
				array(
					'id'      => 'footer_cta_icon',
					'type'    => 'themestek_iconpicker',
					'title'   => esc_html__('Open Link Icon', 'moversco' ),
					'default' => array(
						'library'				=> 'fontawesome',
						'library_fontawesome'	=> 'fa fa-arrow-down',
						'library_themify'		=> 'themifyicon ti-menu',
						'library_sgicon'		=> 'sgicon sgicon-WorldWide',
						'library_vc_linecons'	=> 'li_star',
						'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
					),
					'dependency' 	=> array( 'footer_cta', '==', 'true' ),
				),
				array(
					'id'     		=> 'footer_cta_title',
					'type'    		=> 'textarea',
					'title'   		=> esc_html__('Footer CTA Title', 'moversco'),
					'default' 		=> esc_html__('WE ARE AVAILABLE FOR YOU', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('Title for the Footer CTA area', 'moversco') . '</div>',
					'dependency' 	=> array( 'footer_cta', '==', 'true' ),
				),
				array(
					'id'     		=> 'footer_cta_subtitle',
					'type'    		=> 'textarea',
					'title'   		=> esc_html__('Footer CTA Sub-title', 'moversco'),
					'default' 		=> '',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('Sub-title for the Footer CTA area', 'moversco') . '</div>',
					'dependency' 	=> array( 'footer_cta', '==', 'true' ),
				),
				array(
					'id'     		=> 'footer_cta_button_text',
					'type'    		=> 'text',
					'title'   		=> esc_html__('Footer CTA Button Text', 'moversco'),
					'default' 		=> esc_html__('CONTACT US', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('Button text for the Footer CTA', 'moversco') . '</div>',
					'dependency' 	=> array( 'footer_cta', '==', 'true' ),
				),
				array(
					'id'     		=> 'footer_cta_button_link',
					'type'    		=> 'text',
					'title'   		=> esc_html__('Footer CTA Button Link', 'moversco'),
					'default' 		=> esc_html__('#', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_html__('Button link for the Footer CTA', 'moversco') . '</div>',
					'dependency' 	=> array( 'footer_cta', '==', 'true' ),
				),
				// First Footer Widget Area
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('First Footer Widget Area', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options to change settings for footer widget area', 'moversco').'</small>',
				),
				array(
					'id'			=> 'first_footer_column_layout',
					'type' 			=> 'image_select',//themestek_pre_color_packages
					'title'			=> esc_html__('Footer Widget Columns', 'moversco'),
					'options'      	=> array(
						'12'      => get_template_directory_uri() . '/includes/images/footer_col_12.png',
						'6_6'     => get_template_directory_uri() . '/includes/images/footer_col_6_6.png',
						'4_4_4'   => get_template_directory_uri() . '/includes/images/footer_col_4_4_4.png',
						'3_3_3_3' => get_template_directory_uri() . '/includes/images/footer_col_3_3_3_3.png',
						'8_4'     => get_template_directory_uri() . '/includes/images/footer_col_8_4.png',
						'4_8'     => get_template_directory_uri() . '/includes/images/footer_col_4_8.png',
						'6_3_3'   => get_template_directory_uri() . '/includes/images/footer_col_6_3_3.png',
						'3_3_6'   => get_template_directory_uri() . '/includes/images/footer_col_3_3_6.png',
						'8_2_2'   => get_template_directory_uri() . '/includes/images/footer_col_8_2_2.png',
						'2_2_8'   => get_template_directory_uri() . '/includes/images/footer_col_2_2_8.png',
						'6_2_2_2' => get_template_directory_uri() . '/includes/images/footer_col_6_2_2_2.png',
						'2_2_2_6' => get_template_directory_uri() . '/includes/images/footer_col_2_2_2_6.png',
					),
					'default'		=> '4_4_4',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select Footer Column layout View for widgets.', 'moversco').'</div>',
					'radio'      	=> true,
				),
				array(
					'id'            => 'first_footer_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Footer Background Color', 'moversco'),
					'options'  => array(
						'transparent' => esc_html__('Transparent', 'moversco'),
						'darkgrey'    => esc_html__('Dark grey', 'moversco'),
						'grey'        => esc_html__('Grey', 'moversco'),
						'white'       => esc_html__('White', 'moversco'),
						'skincolor'   => esc_html__('Skincolor', 'moversco'),
						'custom'      => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'transparent',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Footer background color', 'moversco').'</div>',
				),
				array(
					'id'      			=> 'first_footer_bg_all',
					'type'    			=> 'themestek_background',
					'title'  			=> esc_html__('Footer Background', 'moversco' ),
					'after'  			=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Footer background image', 'moversco').'</div>',
					'default'			=> array(
						'repeat'			=> 'no-repeat',
						'attachment'		=> 'fixed',
						'color'				=> '#1f1f1f',
					),
					'output'			=> '.first-footer',
					'output_bglayer'    => true,  // apply color to bglayer class div inside this , default: true
					'color_dropdown_id' => 'first_footer_bg_color',   // color dropdown to decide which color
				),
				array(
					'id'           	=> 'first_footer_text_color',
					'type'         	=> 'select',
					'title'        	=>  esc_html__('Text Color', 'moversco'),
					'options'  		=> array(
						'white'			=> esc_html__('White', 'moversco'),
						'dark'			=> esc_html__('Dark', 'moversco'),
					),
					'default'      	=> 'white',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option', 'moversco').'</div>',
				),
				// Second Footer Widget Area
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Second Footer Widget Area', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options to change settings for second footer widget area', 'moversco').'</small>',
				),
				array(
					'id'			=> 'second_footer_column_layout',
					'type' 			=> 'image_select',//themestek_pre_color_packages
					'title'			=> esc_html__('Footer Widget Columns', 'moversco'),
					'options'      	=> array(
						'12'      => get_template_directory_uri() . '/includes/images/footer_col_12.png',
						'6_6'     => get_template_directory_uri() . '/includes/images/footer_col_6_6.png',
						'4_4_4'   => get_template_directory_uri() . '/includes/images/footer_col_4_4_4.png',
						'3_3_3_3' => get_template_directory_uri() . '/includes/images/footer_col_3_3_3_3.png',
						'8_4'     => get_template_directory_uri() . '/includes/images/footer_col_8_4.png',
						'4_8'     => get_template_directory_uri() . '/includes/images/footer_col_4_8.png',
						'6_3_3'   => get_template_directory_uri() . '/includes/images/footer_col_6_3_3.png',
						'3_3_6'   => get_template_directory_uri() . '/includes/images/footer_col_3_3_6.png',
						'8_2_2'   => get_template_directory_uri() . '/includes/images/footer_col_8_2_2.png',
						'2_2_8'   => get_template_directory_uri() . '/includes/images/footer_col_2_2_8.png',
						'6_2_2_2' => get_template_directory_uri() . '/includes/images/footer_col_6_2_2_2.png',
						'2_2_2_6' => get_template_directory_uri() . '/includes/images/footer_col_2_2_2_6.png',
					),
					'default'		=> '3_3_3_3',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select Footer Column layout View for widgets.', 'moversco').'</div>',
					'radio'      	=> true,
				),
				array(
					'id'            => 'second_footer_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Footer Background Color', 'moversco'),
					'options'		=> array(
						'transparent' => esc_html__('Transparent', 'moversco'),
						'darkgrey'    => esc_html__('Dark grey', 'moversco'),
						'grey'        => esc_html__('Grey', 'moversco'),
						'white'       => esc_html__('White', 'moversco'),
						'skincolor'   => esc_html__('Skincolor', 'moversco'),
						'custom'      => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'transparent',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Footer background color', 'moversco').'</div>',
				),
				array(
					'id'      		=> 'second_footer_bg_all',
					'type'    		=> 'themestek_background',
					'title'  		=> esc_html__('Footer Background', 'moversco' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Footer background image', 'moversco').'</div>',
					'default'		=> array(
						'color'			=> '#191b1b',
					),
					'output' 	    => '.second-footer',
					'output_bglayer'    => true,  // apply color to bglayer class div inside this , default: true
					'color_dropdown_id' => 'second_footer_bg_color',   // color dropdown to decide which color
				),
				array(
					'id'           	=> 'second_footer_text_color',
					'type'         	=> 'select',
					'title'        	=>  esc_html__('Text Color', 'moversco'),
					'options'  		=> array(
						'white'  		=> esc_html__('White', 'moversco'),
						'dark'   		=> esc_html__('Dark', 'moversco'),
					),
					'default'      	=> 'white',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option', 'moversco').'</div>',
				),
				// Footer Text Area
				array(
					'type'       	 => 'heading',
					'content'    	 => esc_html__('Footer Text Area', 'moversco'),
					'after'  	  	 => '<small>'.esc_html__('Options to change settings for footer text area. This contains copyright info', 'moversco').'</small>',
				),
				array(
					'id'            => 'bottom_footer_bg_color',
					'type'          => 'select',
					'title'         =>  esc_html__('Footer Background Color', 'moversco'),
					'options'  => array(
						'transparent' => esc_html__('Transparent', 'moversco'),
						'darkgrey'    => esc_html__('Dark grey', 'moversco'),
						'grey'        => esc_html__('Grey', 'moversco'),
						'white'       => esc_html__('White', 'moversco'),
						'skincolor'   => esc_html__('Skincolor', 'moversco'),
						'custom'      => esc_html__('Custom Color', 'moversco'),
					),
					'default'       => 'transparent',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select predefined color for Footer background color', 'moversco').'</div>',
				),
				array(
					'id'      		=> 'bottom_footer_bg_all',
					'type'    		=> 'themestek_background',
					'title'  		=> esc_html__('Footer Background', 'moversco' ),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Footer background image', 'moversco').'</div>',
					'default'		=> array(
						'repeat'		=> 'no-repeat',
						'position'		=> 'center center',
						'attachment'	=> 'fixed',
						'color'			=> '#060604',
					),
					'output' 	    => '.bottom-footer-text',
					'output_bglayer'    => true,  // apply color to bglayer class div inside this , default: true
					'color_dropdown_id' => 'bottom_footer_bg_color',   // color dropdown to decide which color
				),
				array(
					'id'           	=> 'bottom_footer_text_color',
					'type'         	=> 'select',
					'title'        	=>  esc_html__('Text Color', 'moversco'),
					'options'  		=> array(
						'white'			=> esc_html__('White', 'moversco'),
						'dark'			=> esc_html__('Dark', 'moversco'),
					),
					'default'      	=> 'white',
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select "Dark" color if you are going to select light color in above option', 'moversco').'</div>',
				),
				array(
				  'id'				=> 'footer_copyright_left',
				  'type'			=> 'wysiwyg',
				  'title'			=>  esc_html__('Footer Text Left', 'moversco'),
				  'after'			=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('You can use the following shortcodes in your footer text:', 'moversco')
				  . '<br>   <code>[themestek-site-url]</code> <code>[themestek-site-title]</code> <code>[themestek-site-tagline]</code> <code>[themestek-current-year]</code> <code>[themestek-footermenu]</code> <br><br> '
				  . sprintf( esc_html__('%1$s Click here to know more%2$s  about details for each shortcode.','moversco') , '<a href="'. esc_url('http://moversco.themestekthemes.com/documentation/shortcodes.html') .'" target="_blank">' , '</a>'  ) .'</div>',
				  'default'         => themestek_wp_kses('Copyright &copy; ' . date('Y') . ' <a href="' . site_url() . '">' . get_bloginfo('name') . '</a>. All rights reserved.'),
				),
				array(
				  'id'       		=> 'footer_copyright_right',
				  'type'     		=> 'wysiwyg',
				  'title'   		=>  esc_html__('Footer Text Right', 'moversco'),
				  'after'  			=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('You can use the following shortcodes in your footer text:', 'moversco')
				  . '<br>   <code>[themestek-site-url]</code> <code>[themestek-site-title]</code> <code>[themestek-site-tagline]</code> <code>[themestek-current-year]</code> <code>[themestek-footermenu]</code> <br><br> '
				  . sprintf( esc_html__('%1$s Click here to know more%2$s about details for each shortcode.','moversco') , '<a href="'. esc_url('http://moversco.themestekthemes.com/documentation/shortcodes.html') .'" target="_blank">' , '</a>'  ) .'</div>',
				  'default'         => '',
				),
			)
		)
	),
);
// hide_demo_content_option
$hide_demo_content_option = false;
if( isset($moversco_theme_options['hide_demo_content_option']) ){
	$hide_demo_content_option = $moversco_theme_options['hide_demo_content_option'];
}
if( $hide_demo_content_option == true ){
	// Removing one click demo setup option
	if( !empty($themestek_framework_options[0]["sections"][0]["fields"]) ){
		foreach( $themestek_framework_options[0]["sections"][0]["fields"] as $index => $option ){
			if( !empty($option['type']) && $option['type'] == 'themestek_one_click_demo_import' ){
				unset($themestek_framework_options[0]["sections"][0]["fields"][$index]);
			}
		}
	}
}
// Typography Settings
$themestek_framework_options[] = array(
	'name'   => 'typography_settings', // like ID
	'title'  => esc_html__('Typography Settings', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'    	=> 'heading',
			'content'	=> esc_html__('Typography Settings', 'moversco'),
			'after'  	=> '<small>'.esc_html__('General Element Fonts/Typography', 'moversco').'</small>',
        ),
		array(
			'id'             => 'general_font',
			'type'           => 'themestek_typography',
			'title'          => esc_html__('General Font', 'moversco'),
			'chosen'         => false,
			'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'backup-family'  => true, // Select a backup non-google font in addition to a google font
			'font-size'      => true,
			'color'          => true,
			'variant'        => true, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-align'     => false,  // This is still not available
			'text-transform' => true,
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => true,
			'output'         => 'body', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px - Currently not working
			'subtitle'       => esc_html__('Select font family, size etc. for H2 heading tag.', 'moversco'),
			'default'        => array (
				'family' => 'Nunito Sans',
				'backup-family' => 'Tahoma, Geneva, sans-serif',
				'variant' => 'regular',
				'text-transform' => '',
				'font-size' => '16',
				'line-height' => '24',
				'letter-spacing' => '0',
				'color' => '#777777',
				'all-varients' => 'on',
				'font' => 'google',
			),
		),
		array(
			'id'        => 'link-color',
			'type'      => 'radio',
			'title'     => esc_html__('Select Link Color', 'moversco'),
			'options'  	=> array(
				'default'   => esc_html__('Dark color as normal color and Skin color as hover color', 'moversco'),
				'darkhover' => esc_html__('Skin color as normal color and Dark color as hover color', 'moversco'),
				'custom'    => esc_html__('Custom color (select below)', 'moversco'),
			),
			'default'   => 'default',
			'std'       => 'darkhover',
			'after'   	=> '<div class="cs-text-muted cs-text-desc">' . esc_html__('Select normal link color effect. This will change normal text link color and hover color', 'moversco') . '</div>',
        ),
		array(
			'id'         => 'link-color-regular',
			'type'       => 'color_picker',
			'title'      => esc_html__( 'Links Color Option (Regular)', 'moversco' ),
			'default'    => '#000',
			'dependency' => array( 'link-color_custom', '==', 'true' ),
        ),
		array(
			'id'         => 'link-color-hover',
			'type'       => 'color_picker',
			'title'      => esc_html__( 'Links Color Option (Hover)', 'moversco' ),
			'default'    => '#b1c903',
			'dependency' => array( 'link-color_custom', '==', 'true' ),
        ),
		array(
			'id'             => 'h1_heading_font',
			'type'           => 'themestek_typography',
			'title'          => esc_html__('H1 Heading Font', 'moversco'),
			'chosen'         => false,
			'text-align'     => false,
			'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup'    => true, // Select a backup non-google font in addition to a google font
			'subsets'        => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'         => 'h1', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => '',
				'font-size' => '32',
				'line-height' => '42',
				'letter-spacing' => '0',
				'color' => '#313437',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for H1 heading tag.', 'moversco').'</div>',
		),
		array(
			'id'          => 'h2_heading_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('H2 Heading Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'      => 'h2', // An array of CSS selectors to apply this font style to dynamically
			'units'       => 'px', // Defaults to px
			'default'     => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => '',
				'font-size' => '28',
				'line-height' => '38',
				'letter-spacing' => '0',
				'color' => '#313437',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for H2 heading tag.', 'moversco').'</div>',
		),
		array(
			'id'          => 'h3_heading_font',
			'type'        => 'themestek_typography',
			'chosen'      => false,
			'title'       => esc_html__('H3 Heading Font', 'moversco'),
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'         => 'h3', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => '',
				'font-size' => '24',
				'line-height' => '34',
				'letter-spacing' => '0',
				'color' => '#313437',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for H3 heading tag.', 'moversco').'</div>',
		),
		array(
			'id'          => 'h4_heading_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('H4 Heading Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'      => 'h4', // An array of CSS selectors to apply this font style to dynamically
			'units'       => 'px', // Defaults to px
			'default'     => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => '',
				'font-size' => '20',
				'line-height' => '30',
				'letter-spacing' => '0',
				'color' => '#313437',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for H4 heading tag.', 'moversco').'</div>',
		),
		array(
			'id'          => 'h5_heading_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('H5 Heading Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'      => 'h5', // An array of CSS selectors to apply this font style to dynamically
			'units'       => 'px', // Defaults to px
			'default'     => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => '',
				'font-size' => '16',
				'line-height' => '26',
				'letter-spacing' => '0',
				'color' => '#313437',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for H5 heading tag.', 'moversco').'</div>',
		),
		array(
			'id'          => 'h6_heading_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('H6 Heading Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'      => 'h6', // An array of CSS selectors to apply this font style to dynamically
			'units'       => 'px', // Defaults to px
			'default'     => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => '',
				'font-size' => '12',
				'line-height' => '22',
				'letter-spacing' => '0',
				'color' => '#313437',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for H6 heading tag.', 'moversco').'</div>',
		),
		array(
			'type'        => 'heading',
			'content'     => esc_html__('Heading and Subheading Font Settings', 'moversco'),
			'after'  	  => '<small>'.esc_html__('Select font settings for Heading and subheading of different title elements like Blog Box, Project Box etc', 'moversco').'</small>',
		),
		array(
			'id'          => 'heading_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('Heading Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => true,
			'output'         => '.themestek-element-heading-wrapper .themestek-vc_general .themestek-vc_cta3_content-container .themestek-vc_cta3-content .themestek-vc_cta3-content-header h2', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => 'regular',
				'text-transform' => '',
				'font-size' => '40',
				'line-height' => '55',
				'letter-spacing' => '0',
				'color' => '#313437',
				'all-varients' => 'on',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for heading title', 'moversco').'</div>',
		),
		array(
			'id'          => 'subheading_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('Subheading Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => true,
			'output'         => '.themestek-element-heading-wrapper .themestek-vc_general .themestek-vc_cta3_content-container .themestek-vc_cta3-content .themestek-vc_cta3-content-header h4, .themestek-vc_general.themestek-vc_cta3.themestek-vc_cta3-color-transparent.themestek-cta3-only .themestek-vc_cta3-content .themestek-vc_cta3-headers h4', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
			    'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => 'uppercase',
				'font-size' => '14',
				'line-height' => '20',
				'letter-spacing' => '2',
				'color' => '#e22222',
				'all-varients' => 'on',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for heading title', 'moversco').'</div>',
		),
		array(
			'id'          => 'content_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('Content Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'         => '.themestek-element-heading-wrapper .themestek-vc_general.themestek-vc_cta3 .themestek-vc_cta3-content p', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
				'family' => 'Nunito Sans',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => 'regular',
				'text-transform' => '',
				'font-size' => '18',
				'line-height' => '24',
				'letter-spacing' => '0',
				'color' => '#666666',
				'font' => 'google',
			),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for content', 'moversco').'</div>',
		),
		array(
			'type'        => 'heading',
			'content'     => esc_html__('Specific Element Fonts', 'moversco'),
			'after'  	  => '<small>'.esc_html__('Select Font for specific elements', 'moversco').'</small>',
		),
		array(
			'id'          => 'widget_font',
			'type'        => 'themestek_typography',
			'title'       => esc_html__('Widget Title Font', 'moversco'),
			'chosen'      => false,
			'text-align'  => false,
			'google'      => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup' => true, // Select a backup non-google font in addition to a google font
			'subsets'     => false, // Only appears if google is true and subsets not set to false
			'line-height'    => true,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'         => 'body .widget .widget-title, body .widget .widgettitle, #site-header-menu #site-navigation .mega-menu-wrap .mega-menu.mega-menu-horizontal .mega-sub-menu > li.mega-menu-item > h4.mega-block-title, .portfolio-description h2, .themestek-portfolio-details h2, .themestek-portfolio-related h2', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => '700',
				'text-transform' => '',
				'font-size' => '18',
				'line-height' => '24',
				'letter-spacing' => '0',
				'color' => '#313437',
				'font' => 'google',
			),
			'after'  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select font family, size etc. for widget title', 'moversco').'</div>',
		),
		array(
			'id'             => 'button_font',
			'type'           => 'themestek_typography',
			'title'          => esc_html__('Button Font', 'moversco'),
			'chosen'         => false,
			'text-align'     => false,
			'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup'    => true, // Select a backup non-google font in addition to a google font
			'subsets'        => false, // Only appears if google is true and subsets not set to false
			'font-size'      => false,
			'line-height'    => false,
			'text-transform' => true,
			'color'          => false,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => true, // Defaults to false
			'all-varients'   => false,
			'output'         => '.woocommerce button.button, .woocommerce-page button.button, .themestek-vc_btn, .themestek-vc_btn3, .woocommerce-page a.button, .button, .wpb_button, button, .woocommerce input.button, .woocommerce-page input.button, .tp-button.big, .woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .themestek-post-readmore a', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
				'family' => 'Nunito Sans',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => 'regular',
				'text-transform' => '',
				'letter-spacing' => '0',
				'font' => 'google',
			),
			'after'  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This fonts will be applied to all buttons in this site', 'moversco').'</div>',
		),
		array(
			'id'             => 'element_title',
			'type'           => 'themestek_typography',
			'title'          => esc_html__('Element Title Font', 'moversco'),
			'chosen'         => false,
			'text-align'     => false,
			'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
			'font-backup'    => true, // Select a backup non-google font in addition to a google font
			'subsets'        => false, // Only appears if google is true and subsets not set to false
			'line-height'    => false,
			'text-transform' => true,
			'word-spacing'   => false, // Defaults to false
			'letter-spacing' => false, // Defaults to false
			'color'          => false,
			'all-varients'   => false,
			'output'         => '.wpb_tabs_nav a.ui-tabs-anchor, body .wpb_accordion .wpb_accordion_wrapper .wpb_accordion_header a, .vc_progress_bar .vc_label, .vc_tta.vc_general .vc_tta-tab > a, .vc_toggle_title > h4', // An array of CSS selectors to apply this font style to dynamically
			'units'          => 'px', // Defaults to px
			'default'        => array(
				'family' => 'Biryani',
				'backup-family' => 'Arial, Helvetica, sans-serif',
				'variant' => 'regular',
				'text-transform' => 'uppercase',
				'font-size' => '14',
				'font' => 'google',
			),
			'after'  	=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This fonts will be applied to Tab title, Accordion Title and Progress Bar title text', 'moversco').'</div>',
		),
	)
);
// Blog Settings
$themestek_framework_options[] = array(
	'name'   => 'blog_settings', // like ID
	'title'  => esc_html__('Blog Settings', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Blog Settings', 'moversco'),
			'after'  		=> '<small>'.esc_html__('Settings for Blog section', 'moversco').'</small>',
		),
		array(
			'id'            => 'blog_limit_enabled',
			'type'          => 'select',
			'title'         =>  esc_attr__('Auto Limit Blog content?', 'moversco'),
			'options'		=> array(
				'no'			=> esc_attr__('No', 'moversco'),
				'yes'			=> esc_attr__('Yes', 'moversco'),
			),
			'default'       => 'no',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_attr__('If you like to show limited Blog content on Blog list page (Blogroll page) only. This will not effect on single Blog post and single Blog will show full content.', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'blog_text_limit',
			'type'   		=> 'number',
			'title'         => esc_html__('Blog Excerpt Limit (in words)', 'moversco' ),
			'default'		=> '0',
			'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>' . esc_attr__('Set auto limit for content. Select how many words you like to show from content.', 'moversco') . '<br><strong>' . esc_attr__('NOTE:', 'moversco') . '</strong> ' . esc_attr__('This will also work on EXCERPT content too. Also this will remove all text formatting like paragraph, bold, italic etc. ', 'moversco') . '</div>',
			'dependency'    => array( 'blog_limit_enabled', '==', 'yes' ),
		),
		array(
			'id'            => 'blog_classic_excerpt_enable',
			'type'          => 'select',
			'title'         =>  esc_attr__('Show Excerpt in Classic view too?', 'moversco'),
			'options'		=> array(
				'no'			=> esc_attr__('No', 'moversco'),
				'yes'			=> esc_attr__('Yes', 'moversco'),
			),
			'default'       => 'yes',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_attr__('This will show Excerpt content (if set) instead of main content in Classic View too. By default, this is diabled.', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'blog_readmore_text',
			'type'    		=> 'text',
			'title'   		=> esc_html__('"Read More" Link Text', 'moversco'),
			'default' 		=> esc_html__('Read More', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Text for the Read More link on the Blog page', 'moversco').'</div>',
		),
		array(
			'id'           	=> 'blog_view',
			'type'         	=> 'image_select',
			'title'        	=>  esc_html__('Blog view', 'moversco'),
			'options'  		=> $blog_styles,
			'default'      	=> 'classic',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select blog view. The default view is classic list view. Also we have total three differnt look for classic view. Select them in this option and see your BLOG page. For "Box view", you can select two, three or four columns box view too.', 'moversco').'</div>',
			'radio'      	=> true,
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Blogbox Settings', 'moversco'),
			'after'  		=> '<small>'.esc_html__('Blog box style view settings. This is because you selected "BOX VIEW" in above option.', 'moversco').'</small>',
			'dependency'    => array( 'blog_view_classic', '!=', 'true' ),
		),
		array(
			'id'           	=> 'blogbox_column',
			'type'         	=> 'select',
			'title'        	=>  esc_html__('Blog box column', 'moversco'),
			'options'  		=> array(
				'one'			=> esc_html__('One Column View', 'moversco'),
				'two'			=> esc_html__('Two Column view', 'moversco'),
				'three'			=> esc_html__('Three Column view (default)', 'moversco'),
				'four'			=> esc_html__('Four Column view', 'moversco'),
			),
			'default'      	=> 'three',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select blog view. The default view is classic list view. You can select two, three or four column blog view from here', 'moversco').'</div>',
			'dependency'    => array( 'blog_view_classic', '!=', 'true' ),
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Blog Single Settings', 'moversco'),
			'after'  		=> '<small>'.esc_html__('Settings for single view of blog post.', 'moversco').'</small>',
		),
		array(
			'id'     		=> 'post_social_share_title',
			'type'    		=> 'text',
			'title'   		=> esc_html__('Social Share Title', 'moversco'),
			'default' 		=> esc_html__('Share this post', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This text will appear in the social share box as title', 'moversco').'</div>',
			'dependency'    => array( 'portfolio_show_social_share', '==', 'true' ),
		),
		array(
			'id'        => 'post_social_share_services',
			'type'      => 'checkbox',
			'title'     => esc_html__('Select Social Share Service', 'moversco'),
			'options'   => array(
				'facebook'    => esc_html__('Facebook', 'moversco'),
				'twitter'     => esc_html__('Twitter', 'moversco'),
				'gplus'       => esc_html__('Google Plus', 'moversco'),
				'pinterest'   => esc_html__('Pinterest', 'moversco'),
				'linkedin'    => esc_html__('LinkedIn', 'moversco'),
				'stumbleupon' => esc_html__('Stumbleupon', 'moversco'),
				'tumblr'      => esc_html__('Tumblr', 'moversco'),
				'reddit'      => esc_html__('Reddit', 'moversco'),
				'digg'        => esc_html__('Digg', 'moversco'),
			),
			'default'	 => array( 'facebook','twitter', 'reddit', 'digg' ),
			'after'    	 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('The selected social service icon will be visible on single Post so user can share on social sites.', 'moversco').'</div>',
		),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Blog Classic Meta Settings', 'moversco'),
			'after'  		=> '<small>'.esc_html__('Settings for meta data for Blog classic view.', 'moversco').'</small>',
		),
		array(
			'id'      => 'blogclassic_meta_list',
			'type'    => 'sorter',
			'title'   => esc_html__('Classic Blog - Meta Details','moversco'),
			'after'   => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select which data you like to show in post meta details', 'moversco').'</div>',
			'default' => array(
				'enabled' => array(
					'date'    => esc_html__('Date', 'moversco'),
					'cat'     => esc_html__('Categories', 'moversco'),
					'author'  => esc_html__('Author', 'moversco'),
					'comment' => esc_html__('Comments', 'moversco'),
				),
				'disabled' => array(
					'tag'     => esc_html__('Tags', 'moversco'),
				),
			),
			'enabled_title'  => esc_html__('Active Meta Details', 'moversco'),
			'disabled_title' => esc_html__('Hidden Meta Details', 'moversco'),
		),
		array(
			'id'     		=> 'blogclassic_meta_dateformat',
			'type'    		=> 'text',
			'title'   		=> esc_html__('Date Meta - format', 'moversco'),
			'default' 		=> '',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('By default, this is empty and it will get settings from "Settings > General > Date Format" option. You can write your own custom date format here.', 'moversco'). ' <a href="' . esc_url('https://codex.wordpress.org/Formatting_Date_and_Time') . '" target="_blank">' . esc_html__('Documentation on date and time formatting.', 'moversco') . '</a></div>',
		),
		array(
			'id'     		=> 'blogclassic_meta_taglink',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Tag list - Add link?', 'moversco'),
			'default' 		=> true,
			'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Add link in tags', 'moversco').'</div>',
        ),
		array(
			'id'     		=> 'blogclassic_meta_catlink',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Category list - Add link?', 'moversco'),
			'default' 		=> true,
			'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Add link in categories', 'moversco').'</div>',
        ),
		array(
			'id'     		=> 'blogclassic_meta_authorlink',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Author Name - Add link?', 'moversco'),
			'default' 		=> true,
			'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Add link in author name', 'moversco').'</div>',
        ),
	)
);
// Project Settings
$themestek_framework_options[] = array(
	'name'   => 'portfolio_settings', // like ID
	'title'  => sprintf( esc_html__('%s Settings', 'moversco'), $pf_title_singular ),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('Single %s Settings', 'moversco'), $pf_title_singular ),
			'after'  		=> '<small>' . sprintf( esc_html__('Options to change settings for single %s', 'moversco'), $pf_title_singular ) . '</small>',
		),
		array(
			'id'     		=> 'portfolio_project_details',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('%s Details Box Title', 'moversco'), $pf_title_singular ),
			'default' 		=> esc_html__('PROJECT DETAILS', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Title for the list styled "%1$s Details" area. (For single %1$s only)', 'moversco'), $pf_title_singular ) . '</div>',
		),
		array(
			'id'           	=> 'portfolio_viewstyle',
			'type'         	=> 'image_select',
			'title'        	=> sprintf( esc_html__('Single %s View Style', 'moversco'), $pf_title ),
			'options'       => themestek_global_template_list( 'portfolio-single', true ),
			'default'      	=> 'style-4',
			'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select view for single %s', 'moversco'), $pf_title_singular ) . '</div>',
			'radio'      	=> true,
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('Related %1$s (on single %2$s) Settings', 'moversco'), $pf_title, $pf_title_singular ),
			'after'  		=> '<small>' . sprintf( esc_html__('Options to change settings for related %1$s section on single %2$s page.', 'moversco'), $pf_title, $pf_title_singular ) . '</small>',
		),
		array(
			'id'     		=> 'portfolio_show_related',
			'type'   		=> 'switcher',
			'title'   		=> sprintf( esc_html__('Show Related %s', 'moversco'), $pf_title ),
			'default' 		=> true,
			'label'  		=> '<div class="cs-text-muted cs-text-desc">' . sprintf( esc_html__('Select ON to show related %1$s on single %2$s page', 'moversco'), $pf_title, $pf_title_singular ) . '</div>',
        ),
		array(
			'id'     		=> 'portfolio_related_title',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Related %s Title', 'moversco'), $pf_title ),
			'default' 		=> esc_html__('RELATED PROJECTS', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Title for the Releated %1$s area. (For single %2$s only)', 'moversco'), $pf_title, $pf_title_singular ) . '</div>',
			'dependency'    => array( 'portfolio_show_related', '==', 'true' ),
		),
		array(
			'id'           	=> 'portfolio_related_view',
			'type'         	=> 'image_select',
			'title'        	=> sprintf( esc_html__('Related %s Boxes template', 'moversco'), $pf_title ),
			'options'       => themestek_global_template_list( 'portfolio', true ),
			'default'      	=> 'style-2',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select column to show in Related %s area.', 'moversco'), $pf_title ) . '</div>',
			'dependency'    => array( 'portfolio_show_related', '==', 'true' ),
			'radio'      	=> true,
        ),
		array(
			'id'           	=> 'portfolio_related_column',
			'type'         	=> 'select',
			'title'        	=> esc_html__('Select column', 'moversco'),
			'options'		=> array(
				'two'			=> esc_html__('Two column', 'moversco'),
				'three'			=> esc_html__('Three column', 'moversco'),
				'four'			=> esc_html__('Four column', 'moversco'),
				'five'			=> esc_html__('Five column', 'moversco'),
				'six'			=> esc_html__('Six column', 'moversco'),
			),
			'default'		=> 'three',
			'after'			=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select column to show in Related %s area.', 'moversco'), $pf_title ) . '</div>',
			'dependency'	=> array( 'portfolio_show_related', '==', 'true' ),
        ),
		array(
			'id'     		=> 'portfolio_related_show',
			'type'   		=> 'number',
			'title'         => sprintf( esc_html__('Show %s', 'moversco'), $pf_title ),
			'default'		=> '3',
			'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('How many %2$s Boxes you like to show in Related %1$s area.', 'moversco'), $pf_title, $pf_title_singular ) . '</div>',
			'dependency'    => array( 'portfolio_show_related', '==', 'true' ),
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('Single %s List Details Settings', 'moversco'), $pf_title_singular ),
			'after'  		=> '<small>' . sprintf( esc_html__('Options to change each line of list details for single %1$s. Here you can select how many lines will be appear in the details of a single %1$s', 'moversco'), $pf_title_singular ) . '</small>',
		),
		array(
			'id'              => 'pf_details_line',
			'type'            => 'group',
			'title'           => esc_html__('Line Details', 'moversco'),
			'info'            => sprintf( esc_html__('This will be added a new line in DETAILS box on single %s view.', 'moversco'), $pf_title_singular ),
			'button_title'    => esc_html__('Add New Line', 'moversco'),
			'accordion_title' => esc_html__('Details for the line', 'moversco'),
			'default'		 => array (
				array (
					'pf_details_line_title' => esc_html__('Client', 'moversco'),
					'pf_details_line_icon' 	=> array (
						'library' => 'fontawesome',
						'library_fontawesome' => 'empty',
						'library_themify' => 'ti-location-pin',
						'library_sgicon' => 'sgicon sgicon-WorldWide',
						'library_vc_linecons' => 'li_star',
						'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
				  	),
				  	'data' => 'custom',
				),
				array (
					'pf_details_line_title' => esc_html__('Live Tracking', 'moversco'),
					'pf_details_line_icon' 	=> array (
						'library' => 'fontawesome',
						'library_fontawesome' => 'empty',
						'library_themify' => 'ti-location-pin',
						'library_sgicon' => 'sgicon sgicon-WorldWide',
						'library_vc_linecons' => 'li_star',
						'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
					),
					'data' => 'category',
				),
				array (
					'pf_details_line_title' => esc_html__('Deliverables', 'moversco'),
					'pf_details_line_icon' 	=> array (
						'library' => 'fontawesome',
						'library_fontawesome' => 'empty',
						'library_themify' => 'ti-location-pin',
						'library_sgicon' => 'sgicon sgicon-WorldWide',
						'library_vc_linecons' => 'li_star',
						'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
					),
				  	'data' => 'custom',
				),
				array (
					'pf_details_line_title' => esc_html__('Date', 'moversco'),
					'pf_details_line_icon'  => array (
						'library' => 'fontawesome',
						'library_fontawesome' => 'empty',
						'library_themify' => 'ti-location-pin',
						'library_sgicon' => 'sgicon sgicon-WorldWide',
						'library_vc_linecons' => 'li_star',
						'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
					),
					'data' => 'date',
				),
				array (
					'pf_details_line_title' => esc_html__('Location', 'moversco'),
					'pf_details_line_icon'  => array (
						'library' => 'fontawesome',
						'library_fontawesome' => 'empty',
						'library_themify' => 'ti-location-pin',
						'library_sgicon' => 'sgicon sgicon-WorldWide',
						'library_vc_linecons' => 'li_star',
						'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
					),
					'data' => 'custom',
				),
				array (
					'pf_details_line_title' => esc_html__('Surface', 'moversco'),
					'pf_details_line_icon'  => array (
						'library' => 'fontawesome',
						'library_fontawesome' => 'empty',
						'library_themify' => 'ti-location-pin',
						'library_sgicon' => 'sgicon sgicon-WorldWide',
						'library_vc_linecons' => 'li_star',
						'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
					),
					'data' => 'custom',
				),
			  ),
			'fields'          => array(
				array(
					'id'     		=> 'pf_details_line_title',
					'type'    		=> 'text',
					'title'   		=> esc_html__('Line Title', 'moversco'),
					'default' 		=> esc_html__('Line Title will be here', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Title for the first line of the details in single %s', 'moversco'), $pf_title_singular ) . '<br> ' . esc_html__('Leave this field empty to remove the line.', 'moversco').'</div>',
				),
				array(
					'id'      => 'pf_details_line_icon',
					'type'    => 'themestek_iconpicker',
					'title'  		=> esc_html__('Line Icon', 'moversco' ),
					'default' => array(
						'library'             => 'fontawesome',
						'library_fontawesome' => 'fa fa-map-marker',
					),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select icon for the first Line of the details in single %s', 'moversco'), $pf_title_singular ) . '</div>',
				),
				array(
					'id'      		=> 'data',
					'type'   		=> 'select',
					'title'   		=> esc_html__('Line Input Type', 'moversco'),
					'options' 		=> array(
							'custom'        => esc_html__('Custom text (single line)', 'moversco'),
							'multiline'     => esc_html__('Custom text with multiline', 'moversco'),
							'date'          => sprintf( esc_html__('Show date of the %s', 'moversco'), $pf_title_singular ),
							'category'      => sprintf( esc_html__('Show Category (without link) of the %s', 'moversco'), $pf_title_singular ),
							'category_link' => sprintf( esc_html__('Show Category (with link) of the %s', 'moversco'), $pf_title_singular ),
					),
					'default'		=> 'custom',
					'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select view for single %s', 'moversco'), $pf_title_singular ) . '</div>',
				),
			)
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('Select social sharing service for single %s', 'moversco'), $pf_title_singular ),
			'after'  		=> '<small>' . sprintf( esc_html__('Select social service so site visitors can share the single %s on different social services', 'moversco'), $pf_title_singular ) . '</small>',
		),
		array(
			'id'     		=> 'portfolio_show_social_share',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Show Social Share box', 'moversco'),
			'default' 		=> true,
			'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Show or hide social share box.', 'moversco').'</div>',
        ),
		array(
			'id'     		=> 'portfolio_social_share_title',
			'type'    		=> 'text',
			'title'   		=> esc_html__('Social Share Title', 'moversco'),
			'default' 		=> '',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This text will appear in the social share box as title', 'moversco').'</div>',
			'dependency'    => array( 'portfolio_show_social_share', '==', 'true' ),
		),
		array(
			'id'        => 'portfolio_social_share_services',
			'type'      => 'checkbox',
			'title'     => esc_html__('Select Social Share Service', 'moversco'),
			'options'   => array(
					'facebook'    => esc_html__('Facebook', 'moversco'),
					'twitter'     => esc_html__('Twitter', 'moversco'),
					'gplus'       => esc_html__('Google Plus', 'moversco'),
					'pinterest'   => esc_html__('Pinterest', 'moversco'),
					'linkedin'    => esc_html__('LinkedIn', 'moversco'),
					'stumbleupon' => esc_html__('Stumbleupon', 'moversco'),
					'tumblr'      => esc_html__('Tumblr', 'moversco'),
					'reddit'      => esc_html__('Reddit', 'moversco'),
					'digg'        => esc_html__('Digg', 'moversco'),
			),
			'after'    	 => '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('The selected social service icon will be visible on single %s so user can share on social sites.', 'moversco'), $pf_title_singular ) . '</div>',
			'dependency' => array( 'portfolio_show_social_share', '==', 'true' ),
		),
		array(
			'id'     		=> 'portfolio_single_top_btn_title',
			'type'    		=> 'text',
			'title'   		=> esc_html__('Button Title', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This button will appear after the social share links.', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'portfolio_single_top_btn_link',
			'type'    		=> 'text',
			'title'   		=> esc_html__('Button Link', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('This button will appear after the social share links.', 'moversco').'</div>',
		),
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('%s Settings', 'moversco'), $pf_cat_title ),
			'after'  		=> '<small>' . sprintf( esc_html__('Settings for %s', 'moversco'), $pf_cat_title ) . '</small>',
		),
		array(
			'id'           	=> 'pfcat_view',
			'type'         	=> 'image_select',
			'title'        	=> sprintf( esc_html__('%s Boxes template', 'moversco'), $pf_title_singular ),
			'options'       => themestek_global_template_list( 'portfolio', true ),
			'default'      	=> 'style-1',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select %1$s Box view on single %2$s page.', 'moversco'), $pf_title_singular, $pf_cat_title_singular ) . '</div>',
			'radio'      	=> true,
        ),
		array(
			'id'           	=> 'pfcat_column',
			'type'         	=> 'select',
			'title'        	=>  esc_html__('Select column', 'moversco'),
			'options'  => array(
				'two'     => esc_html__('Two column', 'moversco'),
				'three'   => esc_html__('Three column', 'moversco'),
				'four'    => esc_html__('Four column', 'moversco'),
				'five'    => esc_html__('Five column', 'moversco'),
				'six'     => esc_html__('Six column', 'moversco'),
			),
			'default'      	=> 'three',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select column to show on %s page.', 'moversco'), $pf_cat_title_singular ) . '</div>',
        ),
		array(
			'id'     		=> 'pfcat_show',
			'type'   		=> 'number',
			'title'         => sprintf( esc_html__('%s to show', 'moversco' ), $pf_title_singular ),
			'default'		=> '9',
			'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('How many %1$s you like to show on %2$s page', 'moversco'), $pf_title_singular, $pf_cat_title_singular ) . '</div>',
        ),
	)
);
// Service CPT Settings
$themestek_framework_options[] = array(
	'name'   => 'service_settings', // like ID
	'title'  => sprintf( esc_html__('%s Settings', 'moversco'), $service_title_singular ),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('%s Settings', 'moversco'), $service_cat_title ),
			'after'  		=> '<small>' . sprintf( esc_html__('Settings for %s', 'moversco'), $service_cat_title ) . '</small>',
		),
		array(
			'id'           	=> 'services_cat_view',
			'type'         	=> 'image_select',
			'title'        	=> sprintf( esc_html__('%s Boxes template', 'moversco'), $service_title_singular ),
			'options'       => themestek_global_template_list( 'service', true ),
			'default'      	=> 'style-2',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select %1$s Box view on single %2$s page.', 'moversco'), $service_title_singular, $service_cat_title_singular ) . '</div>',
			'radio'      	=> true,
        ),
		array(
			'id'           	=> 'services_cat_column',
			'type'         	=> 'select',
			'title'        	=>  esc_html__('Select column', 'moversco'),
			'options'  => array(
				'two'     => esc_html__('Two column', 'moversco'),
				'three'   => esc_html__('Three column', 'moversco'),
				'four'    => esc_html__('Four column', 'moversco'),
				'five'    => esc_html__('Five column', 'moversco'),
				'six'     => esc_html__('Six column', 'moversco'),
			),
			'default'      	=> 'two',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select column to show on %s page.', 'moversco'), $service_cat_title_singular ) . '</div>',
        ),
		array(
			'id'     		=> 'services_cat_show',
			'type'   		=> 'number',
			'title'         => sprintf( esc_html__('%s to show', 'moversco' ), $service_title_singular ),
			'default'		=> '9',
			'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('How many %1$s you like to show on %2$s page', 'moversco'), $service_title_singular, $service_cat_title_singular ) . '</div>',
        ),
	)
);
// Team Member Settings
$themestek_framework_options[] = array(
	'name'   => 'team_member_settings', // like ID
	'title'  => sprintf( esc_html__('%s Settings', 'moversco'), $team_member_title_singular ),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html_x('%s\'s Extra Details Settings', 'Team Member', 'moversco'), $team_member_title_singular ),
			'after'  		=> '<small>'.sprintf( esc_html_x('You can fill this extra details and the details will be available on single %s page only. This will be shown as LIST with title and value design.', 'Team Member', 'moversco'), $team_member_title_singular ) . '</small>',
		),
		array(
			'id'              => 'team_extra_details_lines',
			'type'            => 'group',
			'title'           => esc_html__('Line Details', 'moversco'),
			'info'            => sprintf( esc_html_x('This will be added a new line in DETAILS box on single %s.', 'Team Member', 'moversco'), $team_member_title_singular ),
			'button_title'    => esc_html__('Add New Line', 'moversco'),
			'accordion_title' => esc_html__('Details for the line', 'moversco'),
			'fields'          => array(
				array(
					'id'     		=> 'team_extra_details_line_title',
					'type'    		=> 'text',
					'title'   		=> esc_html__('Line Title', 'moversco'),
					'default' 		=> esc_html__('Experience', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. sprintf( esc_html_x('Title for the first line in the DETAILS box in single %s', 'Team Member', 'moversco'), $team_member_title_singular ) . '<br> ' . esc_html__('Leave this field empty to remove the line.', 'moversco').'</div>',
				),
				array(
					'id'      		=> 'data',
					'type'   		=> 'radio',
					'title'   		=> esc_html__('Line Data Type', 'moversco'),
					'options' 		=> array(
						'custom'  => esc_html__('Custom text (add anything)', 'moversco'),
						'url'     => esc_html__('URL link', 'moversco'),
						'email'   => esc_html__('Email address', 'moversco'),
						'phone'   => esc_html__('Phone number', 'moversco'),
					),
					'default'		=> 'custom',
					'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>'.sprintf( esc_html_x('Select view for single %s', 'Team Member', 'moversco'), $team_member_title_singular ).'</div>',
				),
			),
			'default' => array (
				array (
					'team_extra_details_line_title' => 'Address Info',
					'data' => 'custom',
				),
				array (
					'team_extra_details_line_title' => 'Occupation',
					'data' => 'custom',
				),
				array (
					'team_extra_details_line_title' => 'Experience',
					'data' => 'custom',
				),
				array (
					'team_extra_details_line_title' => 'Core Skills',
					'data' => 'custom',
				),
				array (
					'team_extra_details_line_title' => 'Certificates',
					'data' => 'custom',
				),
				array (
					'team_extra_details_line_title' => 'Education',
					'data' => 'custom',
				),
			),
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('%s Settings', 'moversco'), $team_group_title_singular),
			'after'  		=> '<small>' . sprintf( esc_html__('Settings for %s page', 'moversco'), $team_group_title_singular) . '</small>',
		),
		array(
			'id'           	=> 'teamcat_view',
			'type'         	=> 'image_select',
			'title'        	=> sprintf( esc_html__('%s Boxes template', 'moversco'), $team_member_title_singular ),
			'options'       => themestek_global_template_list( 'team', true ),
			'default'      	=> 'style-1',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select %1$s\'s Box view on %2$s page.', 'moversco'), $team_member_title_singular, $team_group_title_singular ) . '</div>',
			'radio'      	=> true,
        ),
		array(
			'id'           	=> 'teamcat_column',
			'type'         	=> 'select',
			'title'        	=>  esc_html__('Select column', 'moversco'),
			'options'  => array(
				'two'   => esc_html__('Two column', 'moversco'),
				'three' => esc_html__('Three column', 'moversco'),
				'four'  => esc_html__('Four column', 'moversco'),
			),
			'default'      	=> 'three',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf(esc_html__('Select column to show %s', 'moversco'), $team_member_title ) . '</div>',
        ),
		array(
			'id'     		=> 'teamcat_show',
			'type'   		=> 'number',
			'title'         => sprintf( esc_html__('%s to Show', 'moversco' ), $team_member_title  ),
			'default'		=> '9',
			'after'  	  	=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('How many %s you like to show on category page', 'moversco'), $team_member_title  ) . '</div>',
        ),
	)
);
// Creating Client Groups array
$client_groups = array();
if( isset($moversco_theme_options['client_groups']) && is_array($moversco_theme_options['client_groups']) ){
foreach( $moversco_theme_options['client_groups'] as $key => $val ){
	$name = $val['client_group_name'];
	$slug = str_replace(' ', '_', strtolower($name));
	$client_groups[$slug] = $name;
}
}
// Error 404 Page Settings
$themestek_framework_options[] = array(
	'name'   => 'error404_page_settings', // like ID
	'title'  => esc_html__('Error 404 Page Settings', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Error 404 Page Settings', 'moversco'),
			'after'  		=> '<small>'.esc_html__('Settings that determine how the error page will be looking', 'moversco').'</small>',
		),
		array(
			'id'      		=> '404_background',
			'type'    		=> 'themestek_background',
			'title'  		=> esc_html__('Content area background for 404 page only', 'moversco' ),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set background for 404 page content area only.', 'moversco').'</div>',
			'default'		=> array(
				'image'			=> get_template_directory_uri() . '/images/404-bg.jpg',
				'repeat'		=> 'no-repeat',
				'position'		=> 'center top',
				'size'			=> 'cover',
				'color'			=> 'rgba(227,34,34,0.9)',
			),
			'output' 	    => '.error404 .site-content-wrapper',
		),
		array(
			'id'       		 => 'error404_big_image',
			'type'     		 => 'themestek_image',
			'title'    		 => esc_html__('Big Image', 'moversco'),
			'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Upload image that will be used as big image on 404 page.', 'moversco')  . '</div>',
			'add_title'		 => esc_html__('Upload Image','moversco'),
			'default'		 => array(
				'thumb-url'	=> get_template_directory_uri() . '/images/404-big-image.png',
				'full-url'	=> get_template_directory_uri() . '/images/404-big-image.png',
			),
		),
		array(
			'id'      => 'error404_big_icon',
			'type'    => 'themestek_iconpicker',
			'title'  		=> esc_html__('Big Icon', 'moversco' ),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select icon that appear in top with big size', 'moversco').'</div>',
			'default' =>  array (
				'library'				=> 'themify',
				'library_fontawesome'	=> 'fa fa-thumbs-o-down',
				'library_themify'		=> 'empty',
				'library_sgicon'		=> 'sgicon sgicon-WorldWide',
				'library_vc_linecons'	=> 'li_star',
				'library_themestek_moversco_business_icon' => 'themestek-moversco-business-icon-nuclear',
			),
		),
		array(
			'id'     		=> 'error404_big_text',
			'type'    		=> 'text',
			'title'   		=> esc_html__('Big heading text', 'moversco'),
			'default' 		=> esc_html__('404', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This text will be shown with big font size below icon', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'error404_medium_text',
			'type'    		=> 'textarea',
			'title'   		=> esc_html__('Description text', 'moversco'),
			'default' 		=> esc_html__('OOPS! THE PAGE YOU WERE LOOKING FOR, COULDN\'T BE FOUND.', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This file may have been moved or deleted. Be sure to check your spelling', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'error404_search',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Show Search Form', 'moversco'),
			'default' 		=> true,
			'label'  		=> '<div class="cs-text-muted cs-text-desc">'.esc_html__('Set this option "YES" to show search form on the 404 page', 'moversco').'</div>',
        ),
	)
);
// Search Page Settings
$themestek_framework_options[] = array(
	'name'   => 'search_page_settings', // like ID
	'title'  => esc_html__('Search Page Settings', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Search Page Settings', 'moversco'),
		),
		array(
			'id'       		 => 'searchnoresult',
			'type'     		 => 'textarea',
			'title'    		 =>  esc_html__('Content of the search page if no results found', 'moversco'),
			'shortcode'		 => true,
			'after'  	     => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Specify the content of the page that will be displayed if while search no results found', 'moversco') . '<br> ' . esc_html__('html tags and shortcodes are allowed', 'moversco').'</div>',
			'default'  		 => themestek_wp_kses( '<h3>Nothing found</h3><p>Sorry, but nothing matched your search terms. Please try again with some different keywords.</p>' ),
        ),
	)
);
// Sidebar Settings
$themestek_framework_options[] = array(
	'name'   => 'sidebar_settings', // like ID
	'title'  => esc_html__('Sidebar Settings', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Sidebar Settings', 'moversco'),
		),
		array(
			'id'              => 'custom_sidebars',
			'type'            => 'group',
			'title'           => esc_html__('Custom Sidebars', 'moversco'),
			'info'            => esc_html__('Specify the custom sidebars that can be used in the pages for a widgets', 'moversco'),
			'button_title'    => esc_html__('Add New Sidebar', 'moversco'),
			'accordion_title' => esc_html__('Custom Sidebar Properties', 'moversco'),
			'fields'          => array(
				array(
					'id'     		=> 'custom_sidebar',
					'type'    		=> 'text',
					'title'   		=> esc_html__('Custom Sidebar Name', 'moversco'),
					'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Write custom sidebar name here', 'moversco').'</div>',
				),
			)
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Sidebar Position', 'moversco'),
			'after'  		=> '<small>'.esc_html__('Select sidebar position for different sections', 'moversco').'</small>',
		),
		array(
			'id'           	=> 'sidebar_post',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('Blog Post/Category Sidebar', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'right',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select one of layouts for blog post. Also for Category, Tag and Archive view too. Technically, related to all blog post view.', 'moversco').'</div>',
        ),
		array(
			'id'           	=> 'sidebar_page',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('Standard Pages Sidebar', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'right',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select one of layouts for standard pages', 'moversco').'</div>',
        ),
		array(
			'id'           	=> 'sidebar_team_member',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('Team member Sidebar', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'left',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select one of layouts for Team Member single and Team Member Group.', 'moversco').'</div>',
        ),
		array(
			'id'           	=> 'sidebar_team_member_group',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('Team member Group Sidebar', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'left',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select one of layouts for Team Member single and Team Member Group.', 'moversco').'</div>',
        ),
		array(
			'id'           	=> 'sidebar_portfolio',
			'type'        	=> 'image_select',
			'title'       	=> sprintf( esc_html__('%s Sidebar', 'moversco'), $pf_title_singular ),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'no',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select one of layouts for %s single pages.', 'moversco'), $pf_title_singular ) . '</div>',
        ),
		array(
			'id'           	=> 'sidebar_portfolio_category',
			'type'        	=> 'image_select',
			'title'       	=> sprintf( esc_html__('%s Sidebar', 'moversco'), $pf_cat_title_singular ),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'right',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select one of layouts for %s view.', 'moversco'), $pf_cat_title_singular ) . '</div>',
        ),
		// Service
		array(
			'id'           	=> 'sidebar_service',
			'type'        	=> 'image_select',
			'title'       	=> sprintf( esc_html__('%s Sidebar', 'moversco'), $service_title_singular ),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'left',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select one of layouts for %s single pages.', 'moversco'), $service_title_singular ) . '</div>',
        ),
		array(
			'id'           	=> 'sidebar_service_category',
			'type'        	=> 'image_select',
			'title'       	=> sprintf( esc_html__('%s Sidebar', 'moversco'), $service_cat_title_singular ),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'left',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>' . sprintf( esc_html__('Select one of layouts for %s view.', 'moversco'), $service_cat_title_singular ) . '</div>',
        ),
		array(
			'id'           	=> 'sidebar_search',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('Search Page Sidebar', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'no',
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select one of layouts for search page', 'moversco').'</div>',
		),
		array(
			'id'           	=> 'sidebar_woocommerce',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('WooCommerce Sidebar', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'right',
			'after'  		=> '<div class="cs-text-muted"><br>'.esc_html__('Select sidebar position for WooCommerce Shop page', 'moversco').'</div>',
        ),
		array(
			'id'           	=> 'sidebar_woocommerce_single',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('WooCommerce Sidebar for Single Product page', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'no',
			'after'  		=> '<div class="cs-text-muted"><br>'.esc_html__('Select sidebar position for WooCommerce Single product view page', 'moversco').'</div>',
        ),
		array(
			'id'           	=> 'sidebar_bbpress',
			'type'        	=> 'image_select',
			'title'       	=> esc_html__('BBPress Sidebar', 'moversco'),
			'options'     	=> array(
				'no'          => get_template_directory_uri() . '/includes/images/layout_no_side.png',
				'left'        => get_template_directory_uri() . '/includes/images/layout_left.png',
				'right'       => get_template_directory_uri() . '/includes/images/layout_right.png',
				'both'        => get_template_directory_uri() . '/includes/images/layout_both.png',
				'bothleft'    => get_template_directory_uri() . '/includes/images/layout_left_both.png',
				'bothright'   => get_template_directory_uri() . '/includes/images/layout_right_both.png',
			),
			'radio'       	=> true,
			'default'      	=> 'right',
			'after'  		=> '<div class="cs-text-muted"><br>'.esc_html__('Select sidebar position for BBPress pages', 'moversco').'</div>',
        ),
	)
);
// Getting social list
$global_social_list = themestek_shared_social_list();
// social service list
$sociallist = array_merge(
	$global_social_list,
	array('rss'     => 'Rss Feed')
);
// Social Links
$themestek_framework_options[] = array(
	'name'   => 'social_links', // like ID
	'title'  => esc_html__('Social Links', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Social Links', 'moversco'),
			'after'			=> '<small>' . sprintf(__('You can use %1$s[themestek-social-links]%2$s shortcode to show social links.', 'moversco'), '<code>' , '</code>' ) . '</small>',
		),
		array(
			'id'              => 'social_icons_list',
			'type'            => 'group',
			'title'           => esc_html__('Social Links', 'moversco'),
			'info'            => esc_html__('Add your social services here. Also you can reorder the Social Links as per your choice. Just drag and drop items to reorder as per your choice', 'moversco'),
			'button_title'    => esc_html__('Add New Social Service', 'moversco'),
			'accordion_title' => esc_html__('Social Service Properties', 'moversco'),
			'fields'          => array(
					array(
						'id'            => 'social_service_name',
						'type'          => 'select',
						'title'         =>  esc_html__('Social Service', 'moversco'),
						'options'  		=> $sociallist,
						'default'       => 'twitter',
						'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Select Social icon from here', 'moversco').'</div>',
					),
					array(
						'id'     		=> 'social_service_link',
						'type'    		=> 'text',
						'title'   		=> esc_html__('Link to Social icon selected above', 'moversco'),
						'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Paste URL only', 'moversco').'</div>',
						'dependency' 	=> array( 'social_service_name', '!=', 'rss' ),
					),
			),
			'default' => array (
				array (
					'social_service_name' => 'facebook',
					'social_service_link' => '#',
				),
				array (
					'social_service_name' => 'twitter',
					'social_service_link' => '#',
				),
				array (
					'social_service_name' => 'flickr',
					'social_service_link' => '#',
				),
				array (
					'social_service_name' => 'linkedin',
					'social_service_link' => '',
				),
			),
        ),
	),
);
// WooCommerce Settings
if( function_exists('is_woocommerce') ){
	$themestek_framework_options[] = array(
		'name'   => 'woocommerce_settings', // like ID
		'title'  => esc_html__('WooCommerce Settings', 'moversco'),
		'icon'   => 'fa fa-shopping-cart',
		'fields' => array( // begin: fields
			array(
				'type'       	=> 'heading',
				'content'    	=> esc_html__('WooCommerce Settings', 'moversco'),
				'after'  		=> '<small>'. esc_html__('Setup for WooCommerce shop section. Please make sure you installed WooCommerce plugin', 'moversco').'</small>',
			),
			array(
				'id'     		=> 'wc-header-icon',
				'type'   		=> 'switcher',
				'title'   		=> esc_html__('Show Cart Icon in Header', 'moversco'),
				'default' 		=> false,
				'label'  		=> '<div class="cs-text-muted">'.esc_html__('Select "On" to show the cart icon in header. Select "OFF" to hide the cart icon.', 'moversco') . ' <br><br> ' . '<strong>' . esc_html__('NOTE:','moversco') . '</strong> ' . esc_html__('Please note that if you haven\'t installed "WooCommerce" plugin than the icon will not appear even if you selected "ON" in this option.', 'moversco').'</div>',
			),
			array(
				'id'     		=> 'woocommerce-column',
				'type'   		=> 'radio',
				'title'  		=> esc_html__('WooCommerce Product List Column', 'moversco'),
				'options'  		=> array(
					'1'				=> esc_html__('One Column', 'moversco'),
					'2'				=> esc_html__('Two Columns', 'moversco'),
					'3'				=> esc_html__('Three Columns', 'moversco'),
					'4'				=> esc_html__('Four Columns', 'moversco'),
				),
				'default'  		 => '3',
				'after'   		 => '<div class="cs-text-muted">'.esc_html__('Select how many column you want to show for product list view', 'moversco').'</div>',
			),
			array(
				'id'     		=> 'woocommerce-product-per-page',
				'type'   		=> 'number',
				'title'         => esc_html__('Products Per Page', 'moversco' ),
				'default'		=> '12',
				'after'  	  	=> '<div class="cs-text-muted"><br>'.esc_html__('Select how many product you want to show on SHOP page', 'moversco').'</div>',
			),
			array(
				'type'       	=> 'heading',
				'content'    	=> esc_html__('Single Product Page Settings', 'moversco'),
				'after'  		=> '<small>'. esc_html__('Options for Single product page', 'moversco').'</small>',
			),
			array(
				'id'     		=> 'wc-single-show-related',
				'type'   		=> 'switcher',
				'title'   		=> esc_html__('Show Related Products', 'moversco'),
				'default' 		=> true,
				'label'  		=> '<div class="cs-text-muted">'.esc_html__('Select "ON" to show Related Products below the product description on single page', 'moversco').'</div>',
			),
			array(
				'id'     		=> 'wc-single-related-column',
				'type'   		=> 'radio',
				'title'  		=> esc_html__('Column for Related Products', 'moversco'),
				'options'  		=> array(
					'1'				=> esc_html__('One Column', 'moversco'),
					'2'				=> esc_html__('Two Columns', 'moversco'),
					'3'				=> esc_html__('Three Columns', 'moversco'),
					'4'				=> esc_html__('Four Columns', 'moversco'),
				),
				'default'  		 => '3',
				'after'   		 => '<div class="cs-text-muted">'.esc_html__('Select how many column you want to show for product list of related products', 'moversco').'</div>',
				'dependency'     => array( 'wc-single-show-related', '==', 'true' ),
			),
			array(
				'id'     		=> 'wc-single-related-count',
				'type'   		=> 'number',
				'title'         => esc_html__('Related Products Show', 'moversco' ),
				'default'		=> '3',
				'after'  	  	=> '<div class="cs-text-muted"><br>'.esc_html__('Select how many products you want to show in the Related prodcuts area on single product page', 'moversco').'</div>',
				'dependency'    => array( 'wc-single-show-related', '==', 'true' ),
			),
		)
	);
}
// Under Construction
$themestek_framework_options[] = array(
	'name'   => 'under_construction', // like ID
	'title'  => esc_html__('Under Construction', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Under Construction', 'moversco'),
			'after'  		=> '<small>'. esc_html__('You can set your site in Under Construciton mode during development of your site. Please note that only logged in users like admin can view the site when this mode is activated', 'moversco').'</small>',
		),
		array(
			'id'     		=> 'uconstruction',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Show Under Construciton Message', 'moversco'),
			'default' 		=> false,
			'label'  		=> esc_html__('You can acitvate this during development of your site. So site visitor will see Under Construction message.', 'moversco'). '<br>' . esc_html__('Please note that admin (when logged in) can view live site and not Under Construction message.', 'moversco'),
        ),
		array(
			'id'     		=> 'uconstruction_title',
			'type'    		=> 'text',
			'title'   		=> esc_html__('Title for Under Construction page', 'moversco'),
			'default'  		=> esc_html__('This site is Under Construction', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Write TITLE for the Under Construction page', 'moversco').'</div>',
			'dependency'	=> array('uconstruction','==','true'),
		),
		array(
			'id'       		 => 'uconstruction_html',
			'type'     		 => 'textarea',
			'title'    		 =>  esc_html__('Page Content', 'moversco'),
			'shortcode'		 => true,
			'dependency'	 => array('uconstruction','==','true'),
			'default' 		 => themestek_wp_kses( '<div class="un-main-page-content">
			<div class="un-page-content">
			<div>[themestek-logo]</div>
			<div class="sepline"></div>
			<h1 class="heading">UNDER CONSTRUCTION</h1>
			<h4 class="subheading">Something awesome this way comes. Stay tuned!</h4>
			</div>
			</div>' ),
			'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Write your html code for Under Construction page body content', 'moversco').'</div>',
        ),
		array(
			'id'      		=> 'uconstruction_background',
			'type'    		=> 'themestek_background',
			'title'  		=> esc_html__('Background Properties', 'moversco' ),
			'dependency'	 => array('uconstruction','==','true'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'.esc_html__('Set background options. This is for main body background', 'moversco').'</div>',
			'default'		=> array(
				'image'			=> get_template_directory_uri() . '/images/uconstruction-bg.jpg',
				'repeat'		=> 'no-repeat',
				'position'		=> 'center top',
				'attachment'	=> 'fixed',
				'size'			=> 'cover',
				'color'			=> '#ffffff',
			),
			'output'      	=> '.uconstruction_background',
        ),
		array(
			'id'       		 => 'uconstruction_css_code',
			'type'     		 => 'textarea',
			'title'    		 =>  esc_html__('CSS Code for Under Construction page', 'moversco'),
			'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Write your custom CSS code here', 'moversco').'</div>',
			'dependency'	 => array('uconstruction','==','true'),
			'default' 		 => urldecode('%40import+url%28%27https%3A%2F%2Ffonts.googleapis.com%2Fcss%3Ffamily%3DBiryani%3A200%2C300%2C400%2C500%2C600%2C700%27%29%3B%0D%0A%0D%0A.un-main-page-content%3Abefore%7B%0D%0Acontent%3A%27%27%3B%0D%0Aposition%3A+absolute%3B%0D%0Aleft%3A0%3B%0D%0Atop%3A0%3B%0D%0A+background-color%3A+rgba%28255%2C+255%2C+255%2C+0.90%29%3B%0D%0Awidth%3A100%25%3B%0D%0Aheight%3A100%25%3B%0D%0A%7D%0D%0A.un-page-content%7B%0D%0A%09position%3A+absolute%3B%0D%0A++++top%3A+50%25%3B%0D%0A++++left%3A+50%25%3B%0D%0A++++-khtml-transform%3A+translateX%280%25%29+translateY%28-50%25%29%3B%0D%0A++++-moz-transform%3A+translateX%280%25%29+translateY%28-50%25%29%3B%0D%0A++++-ms-transform%3A+translateX%280%25%29+translateY%28-50%25%29%3B%0D%0A++++-o-transform%3A+translateX%280%25%29+translateY%28-50%25%29%3B%0D%0A++++transform%3A+translateX%28-50%25%29+translateY%28-50%25%29%3B%0D%0A%7D%0D%0A.ts-sc-logo+img%7B%0D%0A%09max-height%3A+72px%3B%0D%0A%7D%0D%0Ah1.heading%2C%0D%0Ah4.subheading%7B%0D%0A%09margin%3A0%3B%0D%0A%09padding%3A0%3B%0D%0Afont-family%3A+%22Biryani%22%2C+Arial%2C+Helvetica%2C+sans-serif%3B%0D%0A%7D%0D%0Ah1.heading%7B%0D%0A++++font-size%3A+90px%3B%0D%0A++++line-height%3A+90px%3B%0D%0A++++font-weight%3A+700%3B%0D%0A++++margin-top%3A+50px%3B%0D%0A++++margin-bottom%3A+5px%3B%0D%0Afont-family%3A+%22Biryani%22%2C+Arial%2C+Helvetica%2C+sans-serif%3B%0D%0Acolor%3A+%23313437%0D%0A%7D%0D%0Ah4.subheading%7B%09%0D%0A%0D%0Amargin-top%3A+29px%3B%0D%0A++++color%3A+%23313437%3B%0D%0A++++font-size%3A+22px%3B%0D%0A++++line-height%3A+32px%3B%0D%0A%7D'),
        ),
	)
);
// One page website
$themestek_framework_options[] = array(
	'name'   => 'one_page_site', // like ID
	'title'  => esc_html__('One Page Site option', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'      => 'heading',
			'content'   => esc_html__('One Page Website', 'moversco'),
			'after'  	=> '<small>'.esc_html__('Options for One Page website', 'moversco').'</small>',
		),
		array(
			'type'    		=> 'notice',
			'class'   		=> 'info',
			'content'		=> '<p><strong>' . esc_html__('More information about how to set one page site', 'moversco') . '</strong> <br> <a href="#" target="_blank"> ' . esc_html__('Please read our documentation for how to set one-page website by clicking here.', 'moversco') . '</a> </p>',
		),
		array(
			'id'      	=> 'one_page_site',
			'type'    	=> 'switcher',
			'title'   	=> esc_html__('One Page Site', 'moversco'),
			'default' 	=> false,
			'label'   	=> '<br><div class="cs-text-muted cs-text-desc">'.esc_html__('Set this option "ON" if your site is one page website', 'moversco').' <a target="_blank" href="#">'.esc_html__('Click here to know more about how to setup one-page site.', 'moversco').'</a></div>',
		),
	)
);
// Seperator
$themestek_framework_options[] = array(
	'name'   => 'themestek_seperator_1',
	'title'  => esc_html__('Advanced', 'moversco'),
	'icon'   => 'fa fa-gear',
);
$cssfile = (is_multisite()) ? 'php' : 'css' ;
// Advanced Settings
$themestek_framework_options[] = array(
	'name'   => 'advanced_settings', // like ID
	'title'  => esc_html__('Advanced Settings', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('Custom Post Type : %s (Portfolio) Settings', 'moversco'), $pf_title_singular ),
			'after'  		=> '<small>'. esc_html__('Advanced settings for Portfolio custom post type', 'moversco').'</small>',
		),
		array(
			'id'     		=> 'pf_type_title',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Title for %s (Portfolio) Post Type', 'moversco'), $pf_title_singular ),
			'default'  		=> esc_html__('Projects', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the Title for Portfolio post type section', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'pf_type_title_singular',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Singular title for %s (Portfolio) Post Type', 'moversco'), $pf_title_singular ),
			'default'  		=> esc_html__('Project', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the Title for Portfolio post type section. Only for singular title.', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'pf_type_slug',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('URL Slug for %s (Portfolio) Post Type', 'moversco'), $pf_title_singular ),
			'default'  		=> esc_html('project'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the URL slug for Portfolio post type section', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'pf_cat_title',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Title for %s (Portfolio Category) List', 'moversco'), $pf_cat_title_singular ),
			'default'  		=> esc_html__('Project Categories', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Title for Portfolio Category list for group page. This will appear at left sidebar', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'pf_cat_title_singular',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Singular Title for %s (Portfolio Category) List', 'moversco'), $pf_cat_title_singular ),
			'default'  		=> esc_html__('Project Category', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Title for Portfolio Category list for group page. This will appear at left sidebar', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'pf_cat_slug',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('URL Slug for %s (Portfolio Category) Link', 'moversco'), $pf_cat_title_singular ),
			'default'  		=> esc_html__('project-category', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the URL slug for Portfolio Category link', 'moversco').'</div>',
		),
		// Service CPT
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('Custom Post Type : %s (Service) Settings', 'moversco'), $service_title_singular ),
			'after'  		=> '<small>'. esc_html__('Advanced settings for Service custom post type', 'moversco').'</small>',
		),
		array(
			'id'     		=> 'service_type_title',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Title for %s (Service) Post Type', 'moversco'), $service_title_singular ),
			'default'  		=> esc_html__('Services', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the Title for Service post type section', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'service_type_title_singular',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Singular title for %s (Service) Post Type', 'moversco'), $service_title_singular ),
			'default'  		=> esc_html__('Service', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the Title for Service post type section. Only for singular title.', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'service_type_slug',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('URL Slug for %s (Service) Post Type', 'moversco'), $service_title_singular ),
			'default'  		=> esc_html('service'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the URL slug for Service post type section', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'service_cat_title',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Title for %s (Service Category) List', 'moversco'), $service_cat_title_singular ),
			'default'  		=> esc_html__('Service Categories', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Title for Service Category list for group page. This will appear at left sidebar', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'service_cat_title_singular',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Singular Title for %s (Service Category) List', 'moversco'), $service_cat_title_singular ),
			'default'  		=> esc_html__('Service Category', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Title for Service Category list for group page. This will appear at left sidebar', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'service_cat_slug',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('URL Slug for %s (Service Category) Link', 'moversco'), $service_cat_title_singular ),
			'default'  		=> esc_html__('service-category', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the URL slug for Service Category link', 'moversco').'</div>',
		),
		array(
			'type'       	=> 'heading',
			'content'    	=> sprintf( esc_html__('Custom Post Type : %s (Team member) Settings', 'moversco'), $team_member_title_singular ),
			'after'  		=> '<small>'. esc_html__('Advanced settings for Team Member custom post type', 'moversco').'</small>',
		),
		array(
			'id'     		=> 'team_type_title',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Title for %s (Team Member) Post Type', 'moversco'), $team_member_title_singular ),
			'default'  		=> esc_html__('Team', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the Title for Team Member post type section', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'team_type_title_singular',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Singular title for %s (Team Member) Post Type', 'moversco'), $team_member_title_singular ),
			'default'  		=> esc_html__('Team', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the Title for Team Member post type section. Only for singular title.', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'team_type_slug',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('URL Slug for %s (Team Member) Post Type', 'moversco'), $team_member_title_singular ),
			'default'  		=> esc_html__('team', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the URL slug for Team Member post type section', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'team_group_title',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Title for %s (Team Group) List', 'moversco'), $team_group_title_singular ),
			'default'  		=> esc_html__('Team Groups', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Title for Team Group list for group page. This will appear at left sidebar', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'team_group_title_singular',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('Singular Title for %s (Team Group) List', 'moversco'), $team_group_title_singular ),
			'default'  		=> esc_html__('Team Group', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Title for Team Group list for group page. This will appear at left sidebar', 'moversco').'</div>',
		),
		array(
			'id'     		=> 'team_group_slug',
			'type'    		=> 'text',
			'title'   		=> sprintf( esc_html__('URL Slug for %s (Team Group) Link', 'moversco'), $team_group_title_singular ),
			'default'  		=> esc_html__('team-group', 'moversco'),
			'after'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will change the URL slug for Team Group link', 'moversco').'</div>',
		),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Minify Options', 'moversco'),
			'after'  		=> '<small>'. esc_html__('Options to minify html/JS/CSS files', 'moversco').'</small>',
		),
		array(
			'id'     		=> 'minify',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Minify JS and CSS files', 'moversco'),
			'default' 		=> true,
			'label'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This will generate MIN version of all CSS and JS files. This will help you to lower the page load time. You can use this if the Theme Options are not working', 'moversco').'</div>',
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Show or hide Demo Content Setup option', 'moversco'),
			'after'  		=> '<small>'. esc_html__('Show or hide "Demo Content Setup" option under "Layout Settings" tab', 'moversco').'</small>',
		),
		array(
			'id'     		=> 'hide_demo_content_option',
			'type'   		=> 'switcher',
			'title'   		=> esc_html__('Hide "Demo Content Setup" option', 'moversco'),
			'default' 		=> false,
			'label'  		=> '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Show or hide "Demo Content Setup" option under "Layout Settings" tab', 'moversco').'</div>',
        ),
	)
);
// CSS/JS Code
$themestek_framework_options[] = array(
	'name'   => 'custom_code', // like ID
	'title'  => esc_html__('CSS/JS Code', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields' => array( // begin: fields
		// Custom Code
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Custom CSS or JS Code', 'moversco'),
			'after'  		=> '<small>'. esc_html__('Add custom JS and CSS code', 'moversco').'</small>',
		),
		array(
			'id'       		 => 'custom_css_code',
			'type'     		 => 'textarea',
			'title'    		 =>  esc_html__('CSS Code', 'moversco'),
			'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Add custom CSS code here. This code will be appear at bottom of the dynamic css file so you can override any existing style', 'moversco').'</div>',
        ),
		array(
			'id'       => 'custom_js_code',
			'type'     => 'wysiwyg',
			'title'    => esc_html__('JS Code', 'moversco'),
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'       => false,
				'media_buttons' => false,
				'quicktags'     => false,
			),
			'after'    => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Paste your JS code here', 'moversco').'</div>',
		),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Custom html Code', 'moversco'),
			'after'  		=> '<small>'. sprintf(__('Custom html Code for different areas. You can paste <strong>Google Analytics</strong> or any tracking code here', 'moversco'),'<strong>', '</strong>').'</small>',
		),
		array(
			'id'       => 'customhtml_head',
			'type'     => 'wysiwyg',
			'title'    => esc_html__('Custom Code for &lt;head&gt; tag', 'moversco'),
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'       => false,
				'media_buttons' => false,
				'quicktags'     => false,
			),
			'after'    => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This code will appear in &lt;head&gt; tag. You can add your custom tracking code here', 'moversco').'</div>',
		),
		array(
			'id'       => 'customhtml_bodystart',
			'type'     => 'wysiwyg',
			'title'    => esc_html__('Custom Code after &lt;body&gt; tag', 'moversco'),
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'       => false,
				'media_buttons' => false,
				'quicktags'     => false,
			),
			'after'    => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This code will appear after &lt;body&gt; tag. You can add your custom tracking code here', 'moversco').'</div>',
		),
		array(
			'id'       => 'customhtml_bodyend',
			'type'     => 'wysiwyg',
			'title'    => esc_html__('Custom Code before &lt;/body&gt; tag', 'moversco'),
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'       => false,
				'media_buttons' => false,
				'quicktags'     => false,
			),
			'after'    => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('This code will appear before &lt;/body&gt; tag. You can add your custom tracking code here', 'moversco').'</div>',
		),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Custom Code for Login page', 'moversco'),
			'after'  		=> '<small>'. esc_html__('Custom Code for Login pLogin page only. This will effect only login page and not effect any other pages or admin section', 'moversco').'</small>',
		),
		array(
			'id'       		 => 'login_custom_css_code',
			'type'     		 => 'textarea',
			'title'    		 =>  esc_html__('CSS Code for Login Page', 'moversco'),
			'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Write your custom CSS code here', 'moversco').'</div>',
        ),
		array(
			'type'       	=> 'heading',
			'content'    	=> esc_html__('Advanced Custom CSS Code Option', 'moversco'),
		),
		array(
			'id'       		 => 'custom_css_code_top',
			'type'     		 => 'textarea',
			'title'    		 =>  esc_html__('CSS Code (at top of the file)', 'moversco'),
			'after'  		 => '<div class="cs-text-muted cs-text-desc"><br>'. esc_html__('Add custom CSS code here. This code will be appear at top of the css code. specially for "@import" style tag.', 'moversco').'</div>',
        ),
	)
);
// Backup
$themestek_framework_options[]   = array(
	'name'     => 'backup_section',
	'title'    => esc_html__('Backup / Restore', 'moversco'),
	'icon'   => 'fa fa-gear',
	'fields'   => array(
		array(
			'type'    => 'notice',
			'class'   => 'warning',
			'content' => esc_html__('You can save your current options. Download a Backup and Import', 'moversco'),
		),
		array(
			'type'    => 'backup',
		),
	)
);
