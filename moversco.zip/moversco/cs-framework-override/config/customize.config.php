<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// Customizer options - Coming soon with MoversCO theme
$options            = array();
CSFramework_Customize::instance( $options );
