<article class="themestek-box themestek-box-blog themestek-blogbox-style-4 themestek-box-style4 themestek-blogbox-format-<?php echo get_post_format() ?> <?php echo themestek_sanitize_html_classes(themestek_post_class()); ?>">
	<div class="post-item">
		<div class="themestek-blog-image-with-meta">
			<?php echo themestek_wp_kses( themestek_get_featured_media( '', 'themestek-img-800x740' ) ); // Featured content ?>
		</div>
 		<div class="themestek-meta-date-wrapper"><span class="themestek-meta-date"><?php echo get_the_date( 'd' ); ?></span><span class="themestek-meta-month"><?php echo get_the_date( 'M' ); ?></span></div>
		<div class="themestek-box-content">
	 		<?php
			// Category list
			$categories_list = get_the_category_list( ', ' );
			if ( !empty($categories_list) ) { ?>
				<span class="ts-meta-line cat-links"><?php echo themestek_wp_kses($categories_list); ?></span>
			<?php } ?>
			<?php echo themestek_box_title(); ?>
			<div class="ts-blogbox-readmore">
				<?php echo themestek_blogbox_readmore(); ?>
			</div>
		</div>
	</div>
</article>
