<article class="themestek-box themestek-box-blog themestek-blogbox-style-2 themestek-blogbox-format-<?php echo get_post_format() ?> <?php echo themestek_sanitize_html_classes(themestek_post_class()); ?> themestek-blog-box-lr">
	<div class="post-item clearfix">
        <div class="col-md-4 col-sm-4 themestek-box-img-left">
			<?php echo themestek_get_featured_media( '', 'themestek-img-800x740' ); // Featured content ?>
		</div>
        <div class="themestek-box-content col-md-8 col-sm-8">
			<div class="themestek-box-content-inner">
				<div class="ts-featured-meta-wrapper ts-featured-overlay">
					<div class="themestek-meta-date"><span><?php echo get_the_date( 'M' ); ?></span><?php echo get_the_date( 'd' ); ?></div>
				</div>
				<?php echo themestek_box_title(); ?>
				<div class="ts-blogbox-readmore">
					<?php echo themestek_blogbox_readmore(); ?>
				</div>
            </div>
        </div>
	</div>
</article>
