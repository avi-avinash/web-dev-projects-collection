<article class="themestek-box themestek-box-blog themestek-blogbox-style-5 themestek-blogbox-format-<?php echo get_post_format() ?> <?php echo themestek_sanitize_html_classes(themestek_post_class()); ?>">
	<div class="post-item">
		<div class="themestek-blog-image-with-meta">
			<?php echo themestek_wp_kses( themestek_get_featured_media( '', 'themestek-img-800x650' ) ); // Featured content ?>
		</div>
		<div class="themestek-box-content">
	 		<?php
			// Category list
			$categories_list = get_the_category_list( ', ' );
			if ( !empty($categories_list) ) { ?>
				<span class="ts-meta-line cat-links"><?php echo themestek_wp_kses($categories_list); ?></span>
			<?php } ?>
			<?php echo themestek_box_title(); ?>
			<div class="themestek-meta-date">
				<i class="themestek-moversco-icon-calendar"></i> <span><?php echo get_the_date( 'M d, Y' ); ?></span>
			</div>
			<div class="themestek-blogbox-footer-commnent">
					<span class="ts-blogbox-comment-w">
						<a href="<?php echo get_permalink();?>">
							<?php 
							$num_comments    = get_comments_number();			
							$comments_code = '';
							if( !is_sticky() && comments_open() && ($num_comments>=0) ){
								?>
								<i class="themestek-moversco-icon-comment-1"></i>
								<span class="comments"><?php echo esc_attr($num_comments); ?> Comments </span>
								<?php
							 } ?>
						</a>
					</span>
				</div>
		</div>
	</div>
</article>
