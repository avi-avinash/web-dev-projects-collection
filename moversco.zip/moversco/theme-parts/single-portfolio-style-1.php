<?php
/*
 *
 *  Single Portfolio - Left
 *
 */
?>
<div class="themestek-pf-single-content-wrapper themestek-pf-single-style-1">
	<div class="themestek-common-box-shadow themestek-pf-single-content-wrapper-innerbox">
		<div class="row">
			<div class="themestek-pf-single-featured-area col-xs-12 col-sm-8 col-md-8 col-lg-8">
				<?php echo themestek_get_featured_media(); ?>	
			</div><!-- .themestek-pf-single-featured-area -->
			<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
				<div class="themestek-pf-single-details-area">
					<div class="project-details-top">
					<?php $project_details = themestek_get_option('portfolio_project_details');  ?> 
					<?php if( !empty($project_details) ){ ?>
						<h3><?php echo esc_attr($project_details); ?></h3>
					<?php } ?>
					</div>
					<?php echo themestek_portfolio_detailsbox(); ?>
				</div><!-- .themestek-pf-single-content-area -->
			</div><!-- .themestek-pf-single-content-area -->
		</div>
		<div class="themestek-pf-single-content-area">
			<?php echo themestek_portfolio_description(); ?>
		</div><!-- .themestek-pf-single-content-area -->
		<div class="themestek-pf-single-content-bottom container">
			<?php
			// Portfolio Category
			$row_value = get_the_term_list( get_the_ID(), 'themestek-portfolio-category', '', ' ', '' );
			if( !empty($row_value) ){ ?>
				<div class="themestek-pf-single-category-w">
					<?php echo themestek_wp_kses($row_value); ?>
				</div>
			<?php } ?>
		</div>
	</div>
	<div class="themestek-pf-single-np-nav"><?php echo themestek_portfolio_next_prev_btn(); /* Next/Prev button */ ?></div>
</div>
<?php edit_post_link( esc_html__( 'Edit', 'moversco' ), '<footer class="entry-footer"><span class="edit-link">', '</span></footer><!-- .entry-footer -->' ); ?>
