<?php
	// jquery circle progress bar library
	wp_enqueue_script('jquery-circle-progress');
	// Getting data of the  Facts in Digits box
	global $themestek_global_fid_element_values;
	if( is_array($themestek_global_fid_element_values) ) :
		// Getting skin color
		global $moversco_theme_options;
		$skincolor = ( !empty($moversco_theme_options['skincolor']) ) ? $moversco_theme_options['skincolor'] : '#78c63e' ;
?>
<div class="themestek-fid inside themestek-fid-boxstyle-style1 <?php echo themestek_sanitize_html_classes($themestek_global_fid_element_values['main-class']); ?>">
	<div class="themestek-fld-contents">
		<div class="themestek-circle-outer"
			data-digit			= "<?php echo esc_html($themestek_global_fid_element_values['digit']); ?>"
			data-fill			= "<?php echo esc_html($skincolor); ?>"
			data-before			= "<?php echo esc_html($themestek_global_fid_element_values['before_text']); ?>"
			data-before-type	= "<?php echo esc_html($themestek_global_fid_element_values['beforetextstyle']); ?>"
			data-after			= "<?php echo esc_html($themestek_global_fid_element_values['after_text']); ?>"
			data-after-type		= "<?php echo esc_html($themestek_global_fid_element_values['aftertextstyle']); ?>"
			data-size			= "160"
			data-emptyfill		= "#f3f3f3"
			data-thickness		= "7"
			data-gradient		= ""
			>
			<div class="themestek-circle-w">
				<div class="themestek-circle"></div>
				<div class="themestek-circle-overlay">
					<div class="themestek-circle-number"></div>
				</div>
			</div>
			<div class="themestek-fid-title-w">
				<h3 class="themestek-fid-title"><span><?php echo esc_html($themestek_global_fid_element_values['title']); ?><br></span></h3>
				<?php if( !empty($themestek_global_fid_element_values['desc']) ) : ?>
				<div class="themestek-fid-desc"><?php echo esc_html($themestek_global_fid_element_values['desc']); ?></div>
				<?php endif; ?>
			</div>
		</div>
	</div><!-- .themestek-fld-contents -->
</div>
<?php
	endif;
	// Resetting data of the Facts in Digits box
	$themestek_global_fid_element_values = '';
?>