<article class="themestek-box themestek-box-team themestek-teambox-style-1">
	<div class="themestek-post-item">
		<?php echo themestek_wp_kses(themestek_featured_image('themestek-img-800x800')); ?>
		<div class="themestek-box-content">
            <div class="themestek-box-content-inner">		  
				<div class="themestek-box-team-position themestek-skincolor">
					<?php echo themestek_get_meta( 'themestek_team_member_details', 'themestek_team_info' , 'team_details_line_position' ); ?>
				</div>
				<div class="themestek-pf-box-title">
					<?php echo themestek_box_title(); ?>
				</div> 
			</div>		
		</div>
	</div>
</article>