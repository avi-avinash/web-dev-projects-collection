<article class="themestek-box themestek-box-team themestek-teambox-style-4 themestek-box-team-style4">
	<div class="themestek-post-item">
		<div class="themestek-team-image-box themestek-bgcolor-skincolor">
			<?php echo themestek_wp_kses(themestek_featured_image('themestek-img-600x785')); ?>
			<div class="themestek-box-content">
				<div class="themestek-box-desc">
					<?php echo themestek_box_title(); ?>
				<div class="themestek-box-team-position">
					<?php echo themestek_get_meta( 'themestek_team_member_details', 'themestek_team_info' , 'team_details_line_position' ); ?>
				</div>
					<div class="themestek-box-social-links"><?php echo themestek_box_team_social_links(); ?></div>
				</div>
			</div>
		</div>
	</div>
</article>
