<?php
global $moversco_theme_options;
$search_input     = ( !empty($moversco_theme_options['search_input']) ) ? esc_html($moversco_theme_options['search_input']) :  esc_html_x("WRITE SEARCH WORD...", 'Search placeholder word', 'moversco');
$searchform_title = ( isset($moversco_theme_options['searchform_title']) ) ? esc_html($moversco_theme_options['searchform_title']) :  esc_html_x("Hi, How Can We Help You?", 'Search form title word', 'moversco');
$search_logo = ( !empty($moversco_theme_options['logoimg_search']['full-url']) ) ? '<div class="themestek-search-logo"><img src="' . esc_url($moversco_theme_options['logoimg_search']['full-url']) . '" alt="' . esc_attr(get_bloginfo('name')) . '" /></div>' : '' ;
if( !empty($searchform_title) ){
	$searchform_title = '<div class="themestek-form-title">' . $searchform_title . '</div>';
}
if( !empty( $moversco_theme_options['header_search'] ) && $moversco_theme_options['header_search'] == true ){
	?>
<div class="themestek-search-overlay">
		<?php echo themestek_wp_kses($searchform_title); ?>
		<div class="themestek-icon-close"></div>
	<div class="themestek-search-outer">
		<?php echo themestek_wp_kses($search_logo); ?>
		<form method="get" class="themestek-site-searchform" action="<?php echo esc_url( home_url() ); ?>">
			<input type="search" class="field searchform-s" name="s" placeholder="<?php echo esc_attr($search_input); ?>" />
			<button type="submit"><span class="themestek-moversco-icon-search"></span></button>
		</form>
	</div>
</div>
<?php } ?>
