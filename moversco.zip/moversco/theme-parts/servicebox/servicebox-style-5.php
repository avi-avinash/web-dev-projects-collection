<article class="themestek-box themestek-box-service themestek-servicebox-style-5 themestek-service-hover-style">
	<div class="themestek-post-item">
		<?php echo themestek_featured_image('themestek-img-800x700'); ?>
		<div class="ts-ihbox-icon">
			<?php themestek_service_icon(); ?>
		</div>	
		<div class="themestek-box-content">
            <div class="themestek-box-content-inner">
				<div class="themestek-box-category"><?php echo themestek_service_category(true); ?></div>		  
				<div class="themestek-pf-box-title">
					<h3><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h3>
				</div>
			</div>		
		</div>
	</div>
</article>
