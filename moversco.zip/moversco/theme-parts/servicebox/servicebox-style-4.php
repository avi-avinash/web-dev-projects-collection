<article class="themestek-box themestek-box-service themestek-servicebox-style-4">
	<div class="themestek-post-item">
		<div class="ts-ihbox-icon">
			<?php themestek_service_icon(); ?>
		</div>	
		<div class="themestek-box-content">
            <div class="themestek-box-content-inner">
				<div class="themestek-box-category"><?php echo themestek_service_category(true); ?></div>		  
				<div class="themestek-pf-box-title">
					<h3><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h3>
				</div>
				<div class="themestek-service-content"><?php the_excerpt(); ?></div>
				<div class="themestek-box-link"><a href="<?php echo get_permalink(); ?>"><i class=" themestek-moversco-icon-angle-right"></i></a></div>
			</div>		
		</div>
	</div>
</article>
