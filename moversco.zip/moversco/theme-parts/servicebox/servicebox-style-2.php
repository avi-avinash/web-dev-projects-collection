<article class="themestek-box themestek-box-service themestek-servicebox-style-2">
	<div class="themestek-post-item">
		<?php echo themestek_featured_image('themestek-img-600x700'); ?>
		<div class="themestek-box-content">
            <div class="themestek-box-content-inner">
				<div class="themestek-pf-box-title">					
					<h3><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h3>		
					<div class="themestek-box-link"><a href="<?php echo get_permalink(); ?>"><?php esc_attr_e('See Details', 'moversco'); ?></a></div>			
				</div> 
			</div>		
		</div>
	</div>
</article>