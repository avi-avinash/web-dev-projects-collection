<article class="themestek-box themestek-box-testimonial themestek-reviewsbox-style-2">
	<div class="themestek-post-item">
		<div class="themestek-box-img"><?php echo themestek_testimonial_featured_image('thumbnail') ?></div>
		<div class="themestek-box-content">			
			<div class="themestek-box-desc"><blockquote class="themestek-reviews-text"><?php echo themestek_blogbox_description('full'); ?></blockquote></div>
			<div class="themestek-box-author">				
				<div class="themestek-box-title"><?php echo themestek_testimonial_title(); ?></div>
			</div>
		</div>
	</div>
</article>