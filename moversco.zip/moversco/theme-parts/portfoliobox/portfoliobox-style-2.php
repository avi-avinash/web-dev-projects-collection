<article class="themestek-box themestek-box-portfolio themestek-portfoliobox-style-2">
	<div class="themestek-post-item">
		<?php echo themestek_featured_image('themestek-img-800x715'); ?>
		<div class="themestek-box-content themestek-overlay">
			<div class="themestek-box-content-inner">
				<div class="themestek-pf-box-title">
					<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				</div>
				<div class="themestek-view-details">
					<a alt="<?php the_title_attribute( 'echo=0' ); ?>" href="<?php the_permalink(); ?>"><?php esc_html_e('Details','moversco'); ?></a>				
				</div>
            </div>
		</div>
	</div>
</article>
