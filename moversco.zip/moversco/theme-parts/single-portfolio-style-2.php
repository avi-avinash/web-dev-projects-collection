<?php
/*
 *
 *  Single Portfolio - Top image
 *
 */
?>
<div class="themestek-pf-single-content-wrapper themestek-pf-single-style-2">
	<div class="themestek-common-box-shadow themestek-pf-single-content-wrapper-innerbox">
		<div class="themestek-pf-top-content">
			<div class="themestek-row wpb_row vc_row-fluid vc_row container themestek-bgimage-position-center_center">
				<div class="themestek-pf-single-featured-area col-xs-12 col-sm-8 col-md-8 col-lg-8">
					<h4 style="text-align:left;" class="themestek-custom-heading "><?php esc_attr_e('PROJECT OVERVIEW','moversco'); ?></h4>
					<?php echo themestek_portfolio_shortdesc(); ?>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div class="themestek-pf-single-details-area">
							<div class="project-details-top">
							<?php $project_details = themestek_get_option('portfolio_project_details');  ?> 
							<?php if( !empty($project_details) ){ ?>
								<h3><?php echo esc_attr($project_details); ?></h3>
							<?php } ?>
							</div>
							<?php echo themestek_portfolio_detailsbox(); ?>
						</div><!-- .themestek-pf-single-content-area -->
				</div>
			</div>
			<div class="themestek-row wpb_row vc_row-fluid">
				<div class="vc_row container">
					<div class="themestek-column wpb_column vc_column_container vc_col-sm-12 themestek-overlap-row">
						<div class="vc_column-inner">
							<div class="wpb_wrapper">
								<?php echo themestek_get_featured_media('', 'themestek-img-1170x575'); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> <!-- .themestek-pf-top-content -->
		<?php echo themestek_portfolio_description(); ?>
		<!-- =============================================================== -->
		<div class="themestek-pf-single-content-bottom container">
			<?php
			// Portfolio Category
			$row_value = get_the_term_list( get_the_ID(), 'themestek-portfolio-category', '', ' ', '' );
			if( !empty($row_value) ){ ?>
				<div class="themestek-pf-single-category-w">
					<?php echo themestek_wp_kses($row_value); ?>
				</div>
			<?php } ?>
			<?php echo themestek_social_share_box('portfolio');  // Social share ?>
		</div>
	</div><!-- .themestek-common-box-shadow -->
	<div class="container">
		<div class="themestek-pf-single-np-nav"><?php echo themestek_portfolio_next_prev_btn(); // Next/Prev button ?></div>
		<?php edit_post_link( esc_attr__( 'Edit', 'moversco' ), '<footer class="entry-footer"><span class="edit-link">', '</span></footer><!-- .entry-footer -->' ); ?>
	</div>
</div><!-- .themestek-pf-single-content-wrapper -->
